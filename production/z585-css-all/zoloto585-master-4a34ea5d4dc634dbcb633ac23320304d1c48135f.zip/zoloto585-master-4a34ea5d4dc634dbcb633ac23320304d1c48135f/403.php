<?
include_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/urlrewrite.php');

CHTTP::SetStatus("403 Forbidden");
@define("ERROR_403","Y");

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");

$APPLICATION->SetTitle("Доступ запрещен");?>

<section class="content">
<div class="wrp clearfix">
	<h1>Доступ к этой странице запрещен</h1>
	<p>Нам очень жаль,но доступ к этой странице запрещен. Пожалуйста, воспользуйтесь меню или формой поиска по каталогу</p>
</div>
</section> 

<?/*
<section class="filter">
<div class="wrp">
	<?$APPLICATION->IncludeFile(
		SITE_DIR."/include/filter_index.php",
		Array(),
		Array("MODE"=>"html")
	);?>
</div>
</section> 
*/?>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>