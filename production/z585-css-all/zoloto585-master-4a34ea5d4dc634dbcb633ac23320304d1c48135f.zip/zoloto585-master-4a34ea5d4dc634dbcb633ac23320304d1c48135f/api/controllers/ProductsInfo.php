<?php

class ProductsInfoController extends Controller
{
	public function actionIndex()
	{
		CModule::IncludeModule("highloadblock");
		CModule::IncludeModule("catalog");

		$JSON_ARRAY = Array();
		$arProductID = $this->prepareProductID();

		if (count($arProductID) > 0)
		{
			$arProductsInfo = $this->getProductInfo($arProductID, $_REQUEST["SELECT"]);

			if (count($arProductsInfo)>0)
			{
				$arProductsInfo = $this->getPrices($arProductsInfo, $_REQUEST["SELECT"]);
				$JSON_ARRAY = $this->prepareJSON($arProductsInfo);
			}
			else
			{
				$JSON_ARRAY['error']='no card for this product ID';
			}
		}
		else
		{
			$JSON_ARRAY['error']='no real product id';
		}

		echo json_encode($JSON_ARRAY, JSON_UNESCAPED_UNICODE);
	}

	private function prepareProductID()
	{
		$arProductID = $_REQUEST["ID"];

		foreach ($arProductID as $key=>$val)
		{
			if(!preg_match("#^\d+$#",$val))
				unset($arProductID[$key]);
		}

		return $arProductID;
	}

	private function getProductInfo($arProductID, $arSelectRequest)
	{
		$arProducts = Array();

		$arInserts = Array();
		$arMetal = $this->loadHL("metal");
		$arWearType = $this->loadHL("weartype");

		$arSelect = Array("ID", "NAME", "PROPERTY_fotogallery", "PROPERTY_VIDEO", "PROPERTY_WEAR_TYPE", "PROPERTY_METAL","DETAIL_PAGE_URL");

		if(count($arSelectRequest)>0)
		{
			foreach ($arSelectRequest as $select)
			{
				switch ($select)
				{
					case "IMAGE" : $arSelect[] = "DETAIL_PICTURE"; break;
					case "INSERT" : $arSelect[] = "PROPERTY_MAIN_INSERT"; $arInserts = $this->loadHL("maininsert"); break;
				}
			}
		}

		$res = CIBlockElement::GetList(Array(), Array("IBLOCK_ID" => 4,"ID"=>$arProductID), false, Array(), $arSelect);

		while($arProduct = $res->GetNext()){
			if(empty($arProducts[$arProduct["ID"]]))
			{
				$arProduct["PROPERTY_WEAR_TYPE_VALUE"] = $arWearType[$arProduct["PROPERTY_WEAR_TYPE_VALUE"]];
				$arProduct["PROPERTY_METAL_VALUE"] = $arMetal[$arProduct["PROPERTY_METAL_VALUE"]];
				$arProduct["PROPERTY_MAIN_INSERT_VALUE"] = $arInserts[$arProduct["PROPERTY_MAIN_INSERT_VALUE"]];
				$arProduct["URL"] = $arProduct["DETAIL_PAGE_URL"];

				$arProducts[$arProduct["ID"]] = $arProduct;
			}

			$arProducts[$arProduct["ID"]]["PROPERTY_FOTOGALLERY"][] =  $arProduct["PROPERTY_FOTOGALLERY_VALUE"];
		}

		return $arProducts;
	}

	private function getPrices($arProductInfo, $arSelectRequest)
	{

		$arProductsID = array_keys($arProductInfo);

		$arSelect = Array("ID","PROPERTY_CML2_LINK","CATALOG_GROUP_5");

		if (array_search("BASE_PRICE",$arSelectRequest)!==false)
			$arSelect[] = "CATALOG_GROUP_1";

		$dbOffers = CIBlockElement::GetList(
			Array("CATALOG_PRICE_5"=>"ASC"),
			Array("IBLOCK_ID" => 29,"PROPERTY_CML2_LINK"=>$arProductsID,">CATALOG_PRICE_5"=>0,"ACTIVE"=>"Y"),
			false,
			Array(),
			$arSelect
		);

		while ($arOffer = $dbOffers->Fetch())
		{
			$arProductID = $arOffer["PROPERTY_CML2_LINK_VALUE"];
			if(!isset($arProductInfo[$arProductID]["INTERNET_PRICE"]))
			{
				$arProductInfo[$arProductID]["INTERNET_PRICE"] = round($arOffer["CATALOG_PRICE_5"]);
				$arProductInfo[$arProductID]["BASE_PRICE"] = round($arOffer["CATALOG_PRICE_1"]);
			}
		}
		return $arProductInfo;
	}

	private function loadHL($TABLE_NAME)
	{
		$arResult = Array();
		$highloadBlockCursor = Bitrix\Highloadblock\HighloadBlockTable::getList(
			array(
				"filter" => array(
					"TABLE_NAME" => $TABLE_NAME
				),
				"select" => array("ID","NAME","TABLE_NAME"),
			)
		)->fetch();

		$entity =  Bitrix\Highloadblock\HighloadBlockTable::compileEntity( $highloadBlockCursor );
		$entityDataClass = $entity->getDataClass();

		$EntityCursor = $entityDataClass::getList(
			array(
				"select" => array("UF_XML_ID", "UF_NAME"),
			)
		);

		while ($ar = $EntityCursor->Fetch())
		{
			$arResult[$ar["UF_XML_ID"]] = $ar["UF_NAME"];
		}

		return $arResult;
	}

	private function prepareJSON($arProductsInfo)
	{
		$arJsonData = Array();

		foreach ($arProductsInfo as $productID => $arProduct)
		{
			$arResult = Array();

			$arResult['Name']=$arProduct["NAME"];

			if(!empty($arProduct['DETAIL_PICTURE']))
				$arResult['MainPhoto'] = CFile::GetPath($arProduct['DETAIL_PICTURE']);

			if(!empty($arProduct['PROPERTY_VIDEO_VALUE']))
				$arResult['YouTubeID']=$arProduct['PROPERTY_VIDEO_VALUE'];

			foreach ($arProduct["PROPERTY_FOTOGALLERY"] as $photoID)
			{
				$arResult['Photos'][] = CFile::GetPath($photoID);
			}

			if(!empty($arProduct['PROPERTY_MAIN_INSERT_VALUE']))
				$arResult['Insert'] = $arProduct['PROPERTY_MAIN_INSERT_VALUE'];

			if(!empty($arProduct['PROPERTY_WEAR_TYPE_VALUE']))
				$arResult['WearType'] = $arProduct['PROPERTY_WEAR_TYPE_VALUE'];

			if(!empty($arProduct['PROPERTY_METAL_VALUE']))
				$arResult['Metal'] = $arProduct['PROPERTY_METAL_VALUE'];

			if(!empty($arProduct['BASE_PRICE']))
				$arResult['BasePrice'] = $arProduct['BASE_PRICE'];

			if(!empty($arProduct['URL']))
				$arResult['Url'] = "https://zoloto585.ru".$arProduct['URL'];

			$arResult["InternetPrice"] = $arProduct['INTERNET_PRICE'];

			$arJsonData[$productID] = $arResult;
		}
		return $arJsonData;
	}

}


?>

