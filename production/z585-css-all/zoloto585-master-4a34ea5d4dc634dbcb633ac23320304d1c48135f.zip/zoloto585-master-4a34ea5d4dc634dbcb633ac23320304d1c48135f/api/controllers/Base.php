<?php

class BaseController extends Controller {

    public function actionIndex($id = null) {
        die("ok");
    }

    public function actionTest($id = null) {
        $this->render("1", array("tututu" => "manamana"));
        //die("ok" . $id);
    }

}

?>