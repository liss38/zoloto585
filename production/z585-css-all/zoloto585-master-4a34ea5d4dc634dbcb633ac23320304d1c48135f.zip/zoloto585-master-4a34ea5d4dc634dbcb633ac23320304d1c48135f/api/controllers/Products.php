<?php

class ProductsController extends Controller
{

    public function actionIndex($sapCode)
    {
        $JSON_ARRAY=array();
        //получаем карточку товара
        $t_pred = CIBlockElement::GetList(Array(), Array("IBLOCK_ID" => 29,"%XML_ID"=>intval($sapCode)), false, Array(), array("PROPERTY_CML2_LINK"))->fetch();
        //получаем свойства карточки товара
        if(!empty($t_pred["PROPERTY_CML2_LINK_VALUE"])):
            $res = CIBlockElement::GetList(Array(), Array("IBLOCK_ID" => 4,"ID"=>$t_pred["PROPERTY_CML2_LINK_VALUE"]), false, Array(), array("NAME","DETAIL_PICTURE","PROPERTY_fotogallery","PROPERTY_VIDEO"));
            while($ar_props = $res->fetch()){
                if(empty($JSON_ARRAY['Name']))
                    $JSON_ARRAY['Name']=$ar_props["NAME"];
                if(empty($JSON_ARRAY['MainPhoto']))
                    $JSON_ARRAY['MainPhoto']=CFile::GetPath($ar_props['DETAIL_PICTURE']);
                if(empty($JSON_ARRAY['YouTubeID']))
                    $JSON_ARRAY['YouTubeID']=$ar_props['PROPERTY_VIDEO_VALUE'];
                $JSON_ARRAY['Photos'][]=CFile::GetPath($ar_props["PROPERTY_FOTOGALLERY_VALUE"]);
            }
        else:
            $JSON_ARRAY['error']='no card for this sap code';
        endif;
        echo json_encode($JSON_ARRAY, JSON_UNESCAPED_UNICODE);

    }


    /*
	private function getOfferInfo($arSapCode,$arSelectRequest)
	{
		$arProductID = Array();
		$arSelect = Array("ID","PROPERTY_CML2_LINK","XML_ID");

		if (array_search("BASE_PRICE",$arSelectRequest)!==false)
			$arSelect[] = "CATALOG_GROUP_1";

		$dbOffers = CIBlockElement::GetList(Array(), Array("IBLOCK_ID" => 29,"%XML_ID"=>$arSapCode), false, Array(), $arSelect);

		while ($arOffer = $dbOffers->Fetch())
		{
			$arPrice = CCatalogProduct::GetOptimalPrice($arOffer["ID"]);

			$arProductID[$arOffer["PROPERTY_CML2_LINK_VALUE"]] = Array(
				"ID" => $arOffer["ID"],
				"XML_ID" => intval($arOffer["XML_ID"]),
				"INTERNET_PRICE" => $arPrice["DISCOUNT_PRICE"],
				"BASE_PRICE" => round($arOffer["CATALOG_PRICE_1"])
			);
		}

		return $arProductID;
	}

	private function getAmount($arOfferInfo,$cityRequest)
	{
		$cityRequest = trim(strtolower($cityRequest));

		if (empty($cityRequest))
			return $arOfferInfo;

		$curCity = "";
		$arCity = Zoloto585Store::getCities();

		foreach ($arCity as $city)
		{
			if (trim(strtolower($city)) == $cityRequest)
			{
				$curCity = $city;
				break;
			}
		}

		if (empty($curCity))
			return $arOfferInfo;

		$arStore = Zoloto585Store::getStores(Array("UF_CITY"=>$curCity));

		$arStoreID = Array();
		foreach ($arStore as $store)
			$arStoreID[] = $store["ID"];


		$arOfferID = Array();

		foreach ($arOfferInfo as $key=>$arOffer)
		{
			$arOfferInfo[$key]["AMOUNT"] = 0;
			$arOfferID[$key] = $arOffer["ID"];
		}

		$arProductIdBySapCode = array_flip($arOfferID);

		$rsStore = CCatalogStoreProduct::GetList(array(), array('PRODUCT_ID' => $arOfferID, "STORE_ID"=>$arStoreID), false, false, array("PRODUCT_ID","AMOUNT"));

		while ($arStore = $rsStore->Fetch())
		{
			$arOfferInfo[$arProductIdBySapCode[$arStore["PRODUCT_ID"]]]["AMOUNT"] += $arStore["AMOUNT"];
		}

		return $arOfferInfo;
	}*/
}

?>