<?php

class ProductbalanceController extends Controller
{
	public function actionIndex($productID)
	{
		$JSON_ARRAY=array();

		if (!empty($productID) && !empty($_REQUEST["city"]) && preg_match("/^\d+$/",$_REQUEST["count"]))
		{
			$arOffersID = $this->getOffers($productID);

			if(count($arOffersID)>0)
			{
				$amount = $this->getAmount($arOffersID,$_REQUEST["city"]);

				if(is_int($amount))
				{
					if ($amount>=$_REQUEST["count"])
						$JSON_ARRAY["result"] = true;
					else
						$JSON_ARRAY["result"] = false;
				}
				else
				{
					$JSON_ARRAY['error'] = $amount;
				}
			}
			else
			{
				$JSON_ARRAY['error'] = 'Products not found';
			}
		}
		else
		{
			$JSON_ARRAY['error'] = 'No correct data in request';
		}

		echo json_encode($JSON_ARRAY, JSON_UNESCAPED_UNICODE);
	}

	private function getOffers($productID)
	{
		$arResult = [];

		$res = CIBlockElement::GetList(Array(), Array("IBLOCK_ID" => 29, "PROPERTY_CML2_LINK"=>$productID, "ACTIVE"=>"Y"), false, Array(), array("ID"));

		while ($ar = $res->Fetch())
			$arResult[]=$ar["ID"];

		return $arResult;
	}

	private function getAmount($arOfferID,$cityRequest)
	{
		$resultAmount = 0;
		$cityRequest = trim(strtolower($cityRequest));

		$curCity = "";
		$arCity = Zoloto585Store::getCities();

		foreach ($arCity as $city)
		{
			if (trim(strtolower($city)) == $cityRequest)
			{
				$curCity = $city;
				break;
			}
		}

		if (empty($curCity))
			return "City not found";

		$arStore = Zoloto585Store::getStores(Array("UF_CITY"=>$curCity));

		$arStoreID = Array();
		foreach ($arStore as $store)
			$arStoreID[] = $store["ID"];

		if (count($arStoreID)==0)
			return "Shops not found";

		$rsStore = CCatalogStoreProduct::GetList(array(), array('PRODUCT_ID' => $arOfferID, "STORE_ID"=>$arStoreID), false, false, array("AMOUNT"));

		while ($arStore = $rsStore->Fetch())
			$resultAmount += $arStore["AMOUNT"];

		return $resultAmount;
	}
}

?>