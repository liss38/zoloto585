<?php

function includeDir($folder) {
    foreach (glob("$folder/*.php") as $filename) {
        include $filename;
    }
}

?>