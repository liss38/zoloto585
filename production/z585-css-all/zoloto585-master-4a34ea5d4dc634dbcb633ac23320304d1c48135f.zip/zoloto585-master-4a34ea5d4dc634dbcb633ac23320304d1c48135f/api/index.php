<?php

if (!file_exists("nbproject")) {
    require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
    CModule::IncludeModule('catalog');
    CModule::IncludeModule('iblock');
    CModule::IncludeModule('sale');
}

define("BASE_URL", substr($_SERVER['SCRIPT_NAME'], 0, strrpos($_SERVER['SCRIPT_NAME'], "/")));

include "helper.php";

includeDir("classes");
includeDir("libs");
includeDir("controllers");
includeDir("models");
includeDir("ext");

$controllerName = "BaseController";
$actionName = "actionIndex";
$actionParam = null;

if (isset($_GET['item'])) {

    $elems = explode("/", $_GET['item']);
    $controllerName = ucfirst($elems[0]) . "Controller";
    if (sizeof($elems) > 1)
    {
        if(!preg_match("#^\d+$#",$elems[1])){
            $actionName = "action" . ucfirst($elems[1]);
        }else{
            $actionParam = (int) $elems[1];
        }

    }
    if (sizeof($elems) > 2)
        $actionParam = (int) $elems[2];
}

if (!class_exists($controllerName)) {
    die("{'error': 'resource not found'}");
    //die("Ошибка! Контроллер $controllerName не существует");
}

$controller = new $controllerName;

if (!method_exists($controller, $actionName)) {
    die("{'error': 'resource not found'}");
    //die("Ошибка! Метод $actionName не найден");
}

preg_match("#^(.*?)Controller$#", $controllerName, $matches);
$controller->folder = strtolower($matches[1]);

$controller->$actionName($actionParam);
?>