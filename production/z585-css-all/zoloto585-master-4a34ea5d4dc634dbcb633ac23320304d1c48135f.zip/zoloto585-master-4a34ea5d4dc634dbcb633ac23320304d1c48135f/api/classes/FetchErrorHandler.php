<?php

class FetchErrorHandler{
    
public static function fetchMain($code, $message, $file, $line) {    
throw new Exception($message, $code);        
}


}

?>