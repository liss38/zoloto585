<?php

class Controller {

    public $folder;
	public $key="1E522957D2F342CF825BCD962276C68F";

    public function __construct() {
        header('Content-Type: text/html; charset=utf-8');
		//$USER = new CUser;
		//$ar = $USER->Login("api", $_GET["key"], "Y");
		//if(is_array($ar))die("Ключ неправильный.");
        if(!isset($_GET['api_key'])){
            $data = json_encode(array("error"=>"authentication required"));
            die($data);
        }

        if($_GET['api_key']!=$this->key){
            $data = json_encode(array("error"=>"access denied"));
            die($data);
        }

    }

    public function actionIndex() {
        echo "index";
    }

    public function render($viewName, $params = array()) {
        $view = "views/" . $this->folder . "/$viewName.tpl";
        if (!file_exists($view))
            die("Вид $viewName не найден!");

        $smarty = new Smarty();
        $smarty->setTemplateDir("tmp/tmp");
        $smarty->setCacheDir("tmp/cache");
        $smarty->setCompileDir("tmp/compile");
        $smarty->assign($params);
        $smarty->display($view);
    }

}

?>