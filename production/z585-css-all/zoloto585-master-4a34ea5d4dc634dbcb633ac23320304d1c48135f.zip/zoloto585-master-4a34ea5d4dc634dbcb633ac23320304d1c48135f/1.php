<!DOCTYPE html>
<html>
<head>
</head>
<body>

<script src="https://yastatic.net/pcode/adfox/loader.js"></script>

<div id="adfox_149077809985411721"></div>
<script>
	window.Ya.adfoxCode.createAdaptive({
		ownerId: 255634,
		containerId: 'adfox_149077809985411721',
		params: {
			pp: 'jyj',
			ps: 'clpy',
			p2: 'fota'
		}
	}, ['desktop'], {
		tabletWidth: 1024,
		phoneWidth: 1024,
		isAutoReloads: false
	});
</script>

<!--Расположение: верхний слайдер - первый баннер - mobile-->
<div id="adfox_149077818179721679"></div>
<script>
	window.Ya.adfoxCode.createAdaptive({
		ownerId: 255634,
		containerId: 'adfox_149077818179721679',
		params: {
			pp: 'jyq',
			ps: 'clpy',
			p2: 'fota'
		}
	}, ['tablet', 'phone'], {
		tabletWidth: 830,
		phoneWidth: 480,
		isAutoReloads: false
	});
</script>


</body>
</html>
