<?
$sSectionName="skidki-do-70";
?>