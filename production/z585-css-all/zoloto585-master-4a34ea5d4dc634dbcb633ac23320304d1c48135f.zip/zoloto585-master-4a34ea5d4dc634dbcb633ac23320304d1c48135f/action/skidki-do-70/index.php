<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("15 лет Делаем золото доступным.");
?>

<div class="action_landpage">
  <div class="wrp">
    <div class="banner">
      <img src="<?=SITE_TEMPLATE_PATH?>/images/land/banner.jpg" alt="">
    </div>

    <article class="info_action">
      <header class="clearfix">
        <div class="left">
          <div>
            <p>Сроки проведения акции</p>
            <span class="date">С 1 июня по 31 августа 2015 г.</span>
          </div>
        </div>
        <span class="gerb"></span>
        <div class="right">
          <div>
            <p>Прочитать</p>
            <a href="/action/15-let-delaem-zoloto-dostupnym-skidki-do-70-/">Условия акции</a>
          </div>
        </div>
      </header>

      <div class="text clearfix">
        <div class="box">
          <p>Наступило лето  и хочется  тепла и яркого солнца, позитивных эмоций и событий, которые будут вспоминаться еще долгое время?</p>
          <p>Мы хотим, чтобы ваши желания сбывались! <br>Особенно в наш День Рождения! В этом году Ювелирной сети 585GOLD исполняется 15 лет, и мы дарим ВАМ невероятные скидки!</p>
        </div>

        <div class="box">
          <p>С 1 июня по 31 августа 2015 года вы можете купить серьги и кольца с бриллиантами, золотые цепи и бусины-шармы  со скидкой 70%.</p>
          <p><strong>Внимание: данные товары являются товарами с фиксированной ценой и скидки по Бонусным картам и другим акциям на них не распространяются.</strong></p>
        </div>
      </div>

      <footer>Желаем всем <strong>сияющего лета!</strong></footer>
    </article>

    <div class="section section1 clearfix">
      <div class="box">
        <a href="/catalog/kolca/638908/" class="item colco"><img src="<?=SITE_TEMPLATE_PATH?>/images/land/colco.png" alt=""></a>
        <a href="/catalog/sergi/638904/" class="item sergi"><img src="<?=SITE_TEMPLATE_PATH?>/images/land/sergi.png" alt=""></a>

        <div class="text">
          <p>Современные, модные серебряные украшения с бриллиантами «Бесконечность» — хорошо дополнят легкий летний образ и подойдут к любому случаю и настроению. Успейте купить эти замечательные украшения по цене  от 690 руб.</p>
          <a href="/catalog/index.php?SECTION_CODE=all&TYPE=all&set_filter=y&arrFilter_2_3308380389=Y&arrFilter_11_MAX=112820&arrFilter_11_MIN=63" class="btn">Перейти к серебряным изделиям</a>
        </div>
      </div>
    </div>

    <div class="section section2 clearfix">
      <div class="box">
        <a href="/catalog/cepi/index.php?set_filter=y&arrFilter_2_3678868925=Y&arrFilter_11_MAX=64420&arrFilter_11_MIN=388&arrFilter_20_MAX=70&arrFilter_20_MIN=40#top" class="item"><img src="<?=SITE_TEMPLATE_PATH?>/images/land/cep.png" alt=""></a>
        <div class="text">
          <p>Цепочки — всегда актуальный ювелирный аксессуар, который прекрасно подчеркнет как красоту молодой девушки, так и изящность более взрослой женщины. Только сейчас в 585GOLD вы можете купить золотые цепочки по цене от 1890 руб. за грамм.</p>
          <a href="/catalog/cepi/" class="btn">Перейти к цепям</a>
        </div>
      </div>
    </div>

    <div class="section section3 clearfix">
      <div class="box">
        <a href="/catalog/busini-sharm/638472/" class="item"><img src="<?=SITE_TEMPLATE_PATH?>/images/land/braslet.png" alt=""></a>

        <div class="text">
          <p>Шармы — очень популярные и универсальные украшения. Носите их на специальных браслетах, на шейной цепочке или шнурке. Эти модные аксессуары еще никогда не были так доступны. В 585 GOLD бусинка из муранского стекла стоит всего 290 рублей.</p>
          <a href="/catalog/busini-sharm/" class="btn">Перейти к бусинам-шармам</a>
        </div>
      </div>
    </div>

    <div class="banner_bottom">
      <a href="/catalog/index.php?arrFilter_11_MIN=63&arrFilter_11_MAX=112820&arrFilter_14_MIN=70&arrFilter_14_MAX=100&set_filter=%D0%9F%D0%BE%D0%BA%D0%B0%D0%B7%D0%B0%D1%82%D1%8C" class="btn">Смотреть все товары со скидкой 70%</a>
    </div>

    <div class="footer_info">
      <p>Еще больше украшений со скидкой 70% в магазинах Ювелирной сети 585GOLD</p>
      <a href="/about/address/">Найти ближайший магазин</a>
    </div>
  </div>
</div>

</div>
<div id="back-top-wrapper"><p id="back-top"><a href="#top"><span></span></a></p></div>
<!-- close div.container from footer -->
