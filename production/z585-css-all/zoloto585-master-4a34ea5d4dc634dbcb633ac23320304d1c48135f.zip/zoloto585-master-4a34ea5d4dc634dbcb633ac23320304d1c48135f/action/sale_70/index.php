<?php
//require_once($_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php");
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("СПЕЦИАЛЬНОЕ ЛЕТНЕЕ ПРЕДЛОЖЕНИЕ. SALE до 70%");
?>

        <link rel="stylesheet" href="css/favorites-items-list.css">
        <link rel="stylesheet" href="css/jquery.bxslider.css">
        <link rel="stylesheet" href="css/style.css">


        <script src="js/jquery.bxslider.min.js"></script>
        <script src="js/script.js"></script>
    </head>
    <body>
        <div>
            <div class="container header-slider-wrapper" style="">
                <div class="header_slider_wrapper">
                    <ul class="landing-header-slider">
                        <!--li class="">
                            <div class="header-slider-slide-70"></div>
    
                        </li-->
                        <li style="">
                            <div class="landing-right-block">
                                <div class="landing-timer">
                                    <div class="timer-title">
                                        До конца акции
                                    </div>
                                    <div class="timer-time">
                                        <div class="timer-cell">

                                        </div>
                                        <div class="delimiter"></div>
                                        <div class="timer-cell">

                                        </div>
                                        <div class="delimiter"></div>
                                        <div class="timer-cell">

                                        </div>
                                    </div>
                                    <div class="timer-names">
                                        <div class="name-cell">дней</div>
                                        <div class="delimiter"></div>
                                        <div class="name-cell">часов</div>
                                        <div class="delimiter"></div>
                                        <div class="name-cell">минут</div>
                                        <div class="delimiter"></div>
                                    </div>
                                </div>
                                <div class="landing-info">
                                    <div class="timer-desc-title">
                                        <img src="img/calendar.png"> с 31 мая по 14 августа 2016 г.
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="landing-slider-pages-area">
            <div class="container" id="main-slider-pager">
                <a class="landing-slider-pages-item bx-pager-link active" data-slide-index="0">
                    СЕРЕБРО 925 С БИРЮЗОЙ
                    <div class="border"></div>
                </a>
                <a class="landing-slider-pages-item bx-pager-link" data-slide-index="1">
                    СЕРЕБРО 925 С ЖЕМЧУГОМ
                    <div class="border"></div>
                </a>
                <a class="landing-slider-pages-item bx-pager-link" data-slide-index="2">
                    ЗОЛОТО 585 С БРИЛЛИАНТАМИ
                    <div class="border"></div>
                </a>            
            </div>
        </div>
        <div class="landing-slider-content-area">
            <div class="container">
                <div class="left_arrow" id="main-slider-control-prev">
                </div>
                <div class="right_arrow" id="main-slider-control-next">
                </div>
                <div class="medium-slider-wrapper">
                    <ul class="landing-main-slider">
                        <li class="landing-slide-content">
                            <div class="landing-slide-image">
                                <img src="img/slider/1_serebro.png">
                            </div>
                            <div class="landing-slide-text-area">
                                <div class="landing-slide-text-title">
                                    СЕРЕБРЯНЫЕ УКРАШЕНИЯ С БИРЮЗОЙ <br> И ЮВЕЛИРНЫМИ КРИСТАЛЛАМИ
                                </div>
                                <div class="landing-slide-text-subtitle">
                                    Для изящных и непосредственных
                                </div>
                                <div class="landing-slide-text-desc">
                                    Расцветайте вместе с весной с помощью красивых и оригинальных украшений! Нежный небесно-травяной оттенок бирюзы излучает прохладную свежесть только что распустившихся цветов, <br> а ослепительные ювелирные кристаллы в свете ярких солнечных лучей сияют подобно настоящим бриллиантам.
                                </div>
                            </div>
                        </li>
                        <li class="landing-slide-content">
                            <div class="landing-slide-image">
                                <img src="img/slider/2_zoloto.png">
                            </div>
                            <div class="landing-slide-text-area">
                                <div class="landing-slide-text-title">
                                    СЕРЕБРЯНЫЕ КОЛЬЦА И СЕРЬГИ С ЖЕМЧУГОМ
                                </div>
                                <div class="landing-slide-text-subtitle">
                                    Украшения для истинных леди
                                </div>
                                <div class="landing-slide-text-desc">
                                    Жемчуг – олицетворение совершенства, женственности и верности. Необычный дизайн, благородное лунное сияние серебра 925 пробы и мягкое перламутровое свечение жемчуга подчеркивают природную красоту и способны украсить любую женщину.
                                </div>
                            </div>
                        </li>
                        <li class="landing-slide-content">
                            <div class="landing-slide-image">
                                <img src="img/slider/3_zoloto.png">
                            </div>
                            <div class="landing-slide-text-area">
                                <div class="landing-slide-text-title">
                                    ЗОЛОТЫЕ КОЛЬЦА С БРИЛЛИАНТАМИ
                                </div>
                                <div class="landing-slide-text-subtitle">
                                    Ослепительное великолепие алмазов
                                </div>
                                <div class="landing-slide-text-desc">
                                    Когда бриллианты оправлены в роскошное красное золото 585 пробы, их блеск кажется еще более ярким и завораживающим. Позвольте солнечным лучам играть в бесчисленных гранях драгоценных камней ваших украшений и сияйте вместе <br> с ювелирными изделиями, которые на вас надеты.
                                </div>
                            </div>

                    </ul>
                </div>
            </div>
        </div>
        <div class="shadow"><img src="img/shadow.png"></div>
        <div class="landing-cards">
            <div class="container nofilter">
                <div class="cards-title">
                    Каталог ювелирных изделий
                </div>
                <div class="cards-line"></div>
                <div class="cards-subtitle">По привлекательным ценам</div>
                <div class="favorites-items-list">
				 <?global $arrFilter;
                 $arrFilter = array("PROPERTY_RUBRICS"=>13886050);
                 $APPLICATION->IncludeComponent(
                     "bitrix:catalog.section",
                     "",
                     Array(
                         "GTM_TYPE" => Zoloto585Ecommerce::TYPE_ACTION,
                         "GTM_ACTION" => "action_sale_70",
                         "TEMPLATE_THEME" => "blue",
                         "PRODUCT_DISPLAY_MODE" => "N",
                         "ADD_PICT_PROP" => "MORE_PHOTO",
                         "LABEL_PROP" => "NEW_BOOK",
                         "OFFER_ADD_PICT_PROP" => "FILE",
                         "OFFER_TREE_PROPS" => array("-"),
                         "PRODUCT_SUBSCRIPTION" => "N",
                         "SHOW_DISCOUNT_PERCENT" => "N",
                         "SHOW_OLD_PRICE" => "N",
                         "SHOW_CLOSE_POPUP" => "Y",
                         "MESS_BTN_BUY" => "Купить",
                         "MESS_BTN_ADD_TO_BASKET" => "В корзину",
                         "MESS_BTN_SUBSCRIBE" => "Подписаться",
                         "MESS_BTN_DETAIL" => "Подробнее",
                         "MESS_NOT_AVAILABLE" => "Нет в наличии",
                         "AJAX_MODE" => "N",
                         "SEF_MODE" => "N",
                         "IBLOCK_TYPE" => "catalog",
                         "IBLOCK_ID" => "4",
                         "SECTION_ID" => "",
                         "SECTION_CODE" => "",
                         "SECTION_USER_FIELDS" => array(),
                         "ELEMENT_SORT_FIELD" => "sort",
                         "ELEMENT_SORT_ORDER" => "asc",
                         "ELEMENT_SORT_FIELD2" => "name",
                         "ELEMENT_SORT_ORDER2" => "asc",
                         "FILTER_NAME" => "arrFilter",
                         "INCLUDE_SUBSECTIONS" => "Y",
                         "SHOW_ALL_WO_SECTION" => "Y",
                         "SECTION_URL" => "",
                         "DETAIL_URL" => "",
                         "BASKET_URL" => "/personal/basket.php",
                         "ACTION_VARIABLE" => "action",
                         "PRODUCT_ID_VARIABLE" => "id",
                         "PRODUCT_QUANTITY_VARIABLE" => "quantity",
                         "ADD_PROPERTIES_TO_BASKET" => "Y",
                         "PRODUCT_PROPS_VARIABLE" => "prop",
                         "PARTIAL_PRODUCT_PROPERTIES" => "N",
                         "SECTION_ID_VARIABLE" => "SECTION_ID",
                         "ADD_SECTIONS_CHAIN" => "Y",
                         "DISPLAY_COMPARE" => "N",
                         "SET_TITLE" => "Y",
                         "SET_BROWSER_TITLE" => "Y",
                         "BROWSER_TITLE" => "-",
                         "SET_META_KEYWORDS" => "Y",
                         "META_KEYWORDS" => "",
                         "SET_META_DESCRIPTION" => "Y",
                         "META_DESCRIPTION" => "",
                         "SET_LAST_MODIFIED" => "Y",
                         "USE_MAIN_ELEMENT_SECTION" => "Y",
                         "SET_STATUS_404" => "N",
                         "PAGE_ELEMENT_COUNT" => "36",
                         "LINE_ELEMENT_COUNT" => "4",
                         "PROPERTY_CODE" => array("type","VIDEO","brend","vstavka","collection","materials","rubrics","MIN_PRICE","WEAR_TYPE","STYLISTIC_GROUP","METAL","PROBA","METALCOLOR","CATEGORY","FOR_SOMEONE","MAIN_INSERT","MAIN_COLOR_INSERT","COLLECTION_NEW","TOP_DESIGN_585","DIAMOND_CUT","LASER_ENGRAVING","COVER","MANUFACTURING_TECH","SECOND_LEVEL_DESIGN","JEWEL_NUMBER","CLIP","SHINKA_PROFILE","EMPTINESS","SNAP","COLLECTION_FUTL","COLOR_FUTL","PURPOSE_METAL_FUTL","TRADEMARK_CHEM","DENSITY_WEAVING","WEAVING","COMPLETE_WATCH","MECHANISM_WATCH","BRAND_WATCH","ADD_INSERT","TYPE_MAIN_INSERTS","MANUFACTURER","NUMBER_NONPRECIOUS_PRODUCT","NUMBER_PDK_PRODUCT","NUMBER_DK_PRODUCT","NOMINAL","DIAMETER_WEAVING","SHINKA_WIDTH","WIDTH_TUBE","CAPACITY_ML_CHEM","BRAND_ID","KOMPLEKT",""),
                         "OFFERS_FIELD_CODE" => array("ID","CODE","XML_ID","NAME","TAGS","SORT","PREVIEW_TEXT","PREVIEW_PICTURE","DETAIL_TEXT","DETAIL_PICTURE","DATE_ACTIVE_FROM","ACTIVE_FROM","DATE_ACTIVE_TO","ACTIVE_TO","SHOW_COUNTER","SHOW_COUNTER_START","IBLOCK_TYPE_ID","IBLOCK_ID","IBLOCK_CODE","IBLOCK_NAME","IBLOCK_EXTERNAL_ID","DATE_CREATE","CREATED_BY","CREATED_USER_NAME","TIMESTAMP_X","MODIFIED_BY","USER_NAME",""),
                         "OFFERS_PROPERTY_CODE" => array("SUPPLIER_CODE","SPECIAL_PRICE","SIZE_RING_PEND","WEIGHT_NO_INSERTS","WEIGHT_WITH_INSERTS","DATE_INSERT_SAP","SIZE_CB",""),
                         "OFFERS_SORT_FIELD" => "sort",
                         "OFFERS_SORT_ORDER" => "asc",
                         "OFFERS_SORT_FIELD2" => "active_from",
                         "OFFERS_SORT_ORDER2" => "desc",
                         "OFFERS_LIMIT" => "10",
                         "BACKGROUND_IMAGE" => "-",
                         "PRICE_CODE" => array("base_price","rozn_price","stock_price","minimal_price","Internet_price"),
                         "USE_PRICE_COUNT" => "Y",
                         "SHOW_PRICE_COUNT" => "1",
                         "PRICE_VAT_INCLUDE" => "Y",
                         "PRODUCT_PROPERTIES" => array("type","VIDEO","brend","vstavka","collection","materials","rubrics","MIN_PRICE","WEAR_TYPE","STYLISTIC_GROUP","METAL","PROBA","METALCOLOR","CATEGORY","FOR_SOMEONE","MAIN_INSERT","MAIN_COLOR_INSERT","COLLECTION_NEW","TOP_DESIGN_585","DIAMOND_CUT","LASER_ENGRAVING","COVER","MANUFACTURING_TECH","SECOND_LEVEL_DESIGN","JEWEL_NUMBER","CLIP","SHINKA_PROFILE","EMPTINESS","SNAP","COLLECTION_FUTL","COLOR_FUTL","PURPOSE_METAL_FUTL","TRADEMARK_CHEM","DENSITY_WEAVING","WEAVING","COMPLETE_WATCH","MECHANISM_WATCH","BRAND_WATCH","ADD_INSERT","TYPE_MAIN_INSERTS","MANUFACTURER","NUMBER_NONPRECIOUS_PRODUCT","NUMBER_PDK_PRODUCT","NUMBER_DK_PRODUCT","NOMINAL","DIAMETER_WEAVING","SHINKA_WIDTH","WIDTH_TUBE","CAPACITY_ML_CHEM","BRAND_ID","KOMPLEKT",""),
                         "USE_PRODUCT_QUANTITY" => "Y",
                         "CACHE_TYPE" => "A",
                         "CACHE_TIME" => "36000000",
                         "CACHE_FILTER" => "Y",
                         "CACHE_GROUPS" => "Y",
                         "DISPLAY_TOP_PAGER" => "Y",
                         "DISPLAY_BOTTOM_PAGER" => "Y",
                         "PAGER_TITLE" => "Товары",
                         "PAGER_SHOW_ALWAYS" => "N",
                         "PAGER_TEMPLATE" => "",
                         "PAGER_DESC_NUMBERING" => "N",
                         "PAGER_DESC_NUMBERING_CACHE_TIME" => "36000",
                         "PAGER_SHOW_ALL" => "Y",
                         "HIDE_NOT_AVAILABLE" => "Y",
                         "OFFERS_CART_PROPERTIES" => array(),
                         "AJAX_OPTION_JUMP" => "N",
                         "AJAX_OPTION_STYLE" => "Y",
                         "AJAX_OPTION_HISTORY" => "N",
                         "CONVERT_CURRENCY" => "Y",
                         "CURRENCY_ID" => "RUB",
                         "ADD_TO_BASKET_ACTION" => "ADD",
                         "PAGER_BASE_LINK_ENABLE" => "Y",
                         "SET_STATUS_404" => "Y",
                         "SHOW_404" => "Y",
                         "MESSAGE_404" => "",
                         "PAGER_BASE_LINK" => "",
                         "PAGER_PARAMS_NAME" => "arrPager"
                     )
                 );?>
                    <a href="/catalog/yuvelirnye_izdeliya/so-skidkoj-50-60-70-procentov/" target="_blank" class="no_line"><div class="print-button">смотреть еще ></div></a>
                </div>
            </div>
            <div class="shadow"><img src="img/shadow_invert.png"></div>
        </div>
        <div style="padding-bottom: 55px; background-color: #f5f5f5;">
            <div class="container">
                <div class="landing-rules">
                    <div class="rules-title">
                        Условия акции
                    </div>
                    <div class="rules-desc">
                        Акция «Скидки до 70%» действует с 31 мая по 14 августа 2016 г. Акция суммируется со скидками по бонусным картам, купонам и другим акциям. Механизм суммирования акций и итоговую цену товара можно уточнить в магазинах ювелирной сети «585GOLD» и на сайте в разделе «Акции». Стоимость изделий, используемых в рекламных макетах, является финальной. На них не распространяются скидки по бонусным картам, купонам и другим акциям. Изображение изделий может отличаться от фактического вида товара. Количество изделий, участвующих в акции, ограничено.
                    </div>
                </div>
                <a href="/action/skidki-do-70-na-yuvelirnye-izdeliya/" target="_blank" class="no_line"><div class="print-button">подробнее ></div></a>

            </div>
        </div>

<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");
?>
