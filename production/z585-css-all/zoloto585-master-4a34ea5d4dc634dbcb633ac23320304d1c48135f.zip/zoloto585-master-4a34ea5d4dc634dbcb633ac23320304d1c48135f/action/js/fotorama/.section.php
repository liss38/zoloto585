<?
$sSectionName="fotorama";
?>