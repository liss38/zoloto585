$(document).ready(function(){
  var city=0, address=0;
  
  if ($("#timer-sale").length ){
    var date = new Date(2015, 11-1, 1);
    $("#timer-sale").countdown({until: date, format: 'DHMS',description: ''});
  }else if ($("#timer-sale2").length)  {
    var date2 = new Date(2015, 12-1, 1);
    $("#timer-sale2").countdown({until: date2, format: 'DHMS',description: ''});
  }  
  $('.shops-link a').on('click', function(){
    $("body").animate({
      scrollTop: $("#shops-link").offset().top
    }, 2000);
    return false;
  });

  $('.sel-city span').on('click', function(){
    $('#overlay').fadeIn(400, function(){
      $('#modal_form') 
      .css('display', 'block') 
      .animate({opacity: 1, top: '50%'}, 200); 
    });
    return false;
  });
  
// "use strict";
$('#region_id option:selected').removeClass('non');

$('#region_id').change(function(){
  var city = $('#region_id option:selected').text();
  var href = $('#region_id option:selected').attr('data-href');
  var name = $('#region_id option:selected').data('name');
  var coords = $('#region_id option:selected').attr('value').split(',');
  $('.shop').addClass('non');
  $('.shop.'+href).removeClass('non');
});

salePage();

  // if($('.promo-catalog').length){
  //   $('.sale-content .catalog .catalog_list.promo-catalog .item .name').blockHeight(498);    
  // }
  // $('.sale-content .catalog .catalog_list.main-catalog .item .name').blockHeight(498);
  $('.sale-content.sale2 .catalog .catalog_list .item .price .old').prepend('<div></div>')
})
function salePage(){
  var logoSrc = $('.logo a img').attr('src');
  var newLogoSrc = logoSrc.replace("/logo.png","/sale-m-logo.png");
  $('.sale-content .catalog_list').addClass('main-catalog')
  $('.sale-content .catalog_list.promo-catalog').removeClass('main-catalog')
  function salePageFunc(){
    $('.navigation').addClass('sale-nav');
    var logo = $('.logo');
    var btn_text = $('.sale-show-all').eq(0).text();
    var new_btn_text = "Смотреть еще";
    $('.search_m,.map_m,.filter_m').hide();
    if($(window).width()<=983){
      $('.sale-show-all').text(new_btn_text);
      $('.catalog_m').after(logo)
      $('header#header .top').hide(); 
      $('.btn_mobile_menu a').addClass('sale-head')
      if($('.btn_mobile_menu .logo a img').length){
        $('.btn_mobile_menu .logo a img').attr('src',newLogoSrc)      
      }
      $('.sale-billboard .img-wrap').css('height','auto')
      $('.sale-billboard .sale-text .sale-desc').after($('.sale-billboard .img-wrap'))
    }else{
      $('.sale-billboard').prepend($('.sale-billboard .sale-text .img-wrap'))
      $('.sale-show-all').text(btn_text);
      $('header#header .top').show(); 
      $('header#header .top').prepend(logo)
      $('.logo a img').attr('src',logoSrc)
      $('.sale-billboard .img-wrap').height($('.sale-billboard .sale-text').height())
    }
    if($(window).width()<480){
      if(!$('.sale-content .catalog_list.main-catalog').hasClass('owl-carousel')){
        $('.sale-content .catalog_list.main-catalog').owlCarousel({
          slideSpeed : 300,
          paginationSpeed : 400,
          items:2
        })
      }
    }else{
      if($('.sale-content .catalog_list.main-catalog').hasClass('owl-carousel')){
        $('.sale-content .catalog_list.main-catalog').data('owlCarousel').destroy()
      }
    }
  }
  salePageFunc();
  $(window).resize(function(){
    salePageFunc();
  })
}
function initMap(city, address){
  if((!city.length) || (!address.length)){
    $('.sale-map').hide();
    return false;
  }
  $('.sale-map').show();  
  var length = address.length,
  myLocate = new Array(),
  map,
  w = Math.max(document.documentElement.clientWidth, window.innerWidth || 0),
  isDraggable = w > 480 ? true : false,
  shops="";
  map = new google.maps.Map(document.getElementById('map'), {
    zoom: 10,
    scrollwheel:false,
    draggable: isDraggable,
  });
  var geocoder = new google.maps.Geocoder();
  for (var i=0;i<length;i++){
    geocodeAddress(geocoder,map,address[i]+", "+city,i)
  }
  intervalID = setInterval(function(){
    if(myLocate.length == length){
      clearInterval(intervalID);
    }                      
  },1)
  var image = {
    url: 'images/shoping.png'
  }
      // var image = 'images/shoping.png';
      function geocodeAddress(geocoder, resultsMap,address, count) {
        geocoder.geocode({'address': address}, function(results, status) {
          if (status === google.maps.GeocoderStatus.OK) {
            myLocate[count] = results[0].geometry.location;
            var marker = new google.maps.Marker({
              map: resultsMap,
              icon: image,
              title: "585 золото",
              position: results[0].geometry.location
            });
            if((count+1) == length){
              var center = {lat: 0, lng: 0},newLength = 0;
              for ( var i=0; i<length; i++ ){
                if(myLocate[i]){
                  newLength++;
                  center['lat'] = myLocate[i]['G']+center['lat'];
                  center['lng'] = myLocate[i]['K']+center['lng'];                                
                }
              }
              center['lat'] = parseFloat((center['lat']/newLength).toFixed(6))
              center['lng'] = parseFloat((center['lng']/newLength).toFixed(6))
              map.setCenter(center);
            }
          } else {
            alert('Geocode was not successful for the following reason: ' + status);
          }
        });
}
for(var i=0;i<length;i++){
  shops += "<div class=\"shop\"><a href=\"#\">"+address[i]+"</a></div>";
}
$('.sale-map .sale-shops').empty();                     
$('.sale-map .sale-shops').html(shops);                     
}
(function($) {
  $.fn.blockHeight = function(wWidth){
    var block = $(this)
    var defaults = 750
    if(wWidth){
      minWidth = wWidth-17
    }else{
      minWidth = defaults
    }
    if($(window).width()>minWidth){
      var maxH = 0;
      block.each(function(){
        if($(this).height()>maxH){
          maxH = $(this).height()
        }
      })
      block.height(maxH)    
    }else{
      block.css('height','auto')
    }
    $(window).resize(function(){
      if($(window).width()>minWidth){
        var maxH = 0;
        block.each(function(){
          $(this).css('height','auto')
          if($(this).height()>maxH){
            maxH = $(this).height()
          }
        })
        block.height(maxH)    
      }else{
        block.css('height','auto')
      }
    })
  }
})(jQuery);