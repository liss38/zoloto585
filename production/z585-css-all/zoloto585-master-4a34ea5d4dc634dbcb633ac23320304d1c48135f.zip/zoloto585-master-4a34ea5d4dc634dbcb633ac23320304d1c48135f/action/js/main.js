﻿jQuery(document).ready(function($){
	
	//multilevel menu
	$(".nav > li:has('div')").each(function() {
		$(this).find("a:first").addClass("multilevel");
	});
	
	$(window).load(function(){
		$("[data-toggle]").click(function() {
			var toggle_el = $(this).data("toggle");
			
			if($(this).attr("id") == "sidebar-toggle"){
				$(toggle_el).toggleClass("open-sidebar");
			} else {
				$(toggle_el).toggleClass("open-sidebar-right");
			}
			$(toggle_el).parent().toggleClass("overflow");
			$(toggle_el).parent().parent().toggleClass("overflow");
		});
		 $(".swipe-area").swipe({
			swipeStatus:function(event, phase, direction, distance, duration, fingers){
				if (phase=="move" && direction =="right") {
					$(".container").addClass("open-sidebar");
					$(".container").parent().addClass("overflow");
					$(".container").parent().parent().addClass("overflow");
					return false;
				}
				if (phase=="move" && direction =="left") {
					$(".container").removeClass("open-sidebar");
					$(".container").removeClass("open-sidebar-right");
					$(".container").parent().removeClass("overflow");
					$(".container").parent().parent().removeClass("overflow");
					return false;
				}
			}
		}); 
	});
	
	//mobile search
	$(".search_m").on("click", function(){
		$(".search_mobile").slideToggle();
	});
	
	$(".select_drop").selectmenu();
	$(".toggle h3").click(function(){
		$(this).parent().toggleClass("open");
	});
	
	$(".dop h2").on("click", function(){
		$(".dop_inp").slideToggle();
		$(this).toggleClass('active');
	});
	
	//datepicker
	$(".dpicker").datepicker({
		defaultDate: "+1w",
		changeMonth: true,
		changeYear: true,
		numberOfMonths: 1,
		dateFormat: "dd/mm/yy",
		onClose: function( selectedDate ) {
			$( "#to_date" ).datepicker( "option", "minDate", selectedDate );
		}
	});
	
	$( ".slider-range" ).slider({
		range: true,
		min: 0,
		max: 500,
		values: [ 75, 300 ],
		slide:function(event,ui){
      $("#min").html(ui.values[3]);
      $("#max").html(ui.values[10]);
    }
	});
	$( "#min" ).html( $( ".slider-range" ).slider( "values", 0 ));
	$( "#max" ).html( $( ".slider-range" ).slider( "values", 1 ));
});