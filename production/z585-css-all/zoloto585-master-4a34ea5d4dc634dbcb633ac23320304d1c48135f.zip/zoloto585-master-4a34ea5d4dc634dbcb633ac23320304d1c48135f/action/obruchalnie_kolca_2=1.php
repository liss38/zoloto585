<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
for ($i=1; $i < 10; $i++) { 
	if ($_GET['PAGEN_3'] == $i){
		$seo_title = ', страница '.$i;
	}
}
$APPLICATION->SetPageProperty("keywords", "акции, скидки, сеть 585, gold, ювелирный магазин, ювелирная сеть, официальный сайт");
$APPLICATION->SetPageProperty("description", "Акции и скидки".$seo_title.". Сеть ювелирных магазинов 585 Gold.");
$APPLICATION->SetPageProperty("title", "Акции и скидки в ювелирных салонах".$seo_title." | Ювелирный магазин 585 Gold");
?>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<link rel="stylesheet" href="/action/css/sale.css" />
<script src="/action/js/sale.js"></script>

<section class="sale-billboard">
	<div class="wrp clearfix">
		<article class="sale-block-wrap">
			<div class="sale-block">
				<div class="img-wrap">
					<img src="//zoloto585.ru/images/korobka.png" alt="" />
				</div>
				<div class="sale-text">
					<div class="title">ОБРУЧАЛЬНЫЕ КОЛЬЦА</div>
					<div class="sale-desc-main">2 ПО ЦЕНЕ 1</div>
					<div class="sale-desc">Обручальные кольца – действительно особенные ювелирные украшения. В 585 GOLD вы можете не только выбрать подходящие именно вашей паре обручальные кольца, но и приобрести два кольца по цене одного.</div>
					<a href="/action/obruchalnye-koltsa-2-1/">ПОДРОБНЕЕ</a>
					<div class="shops-link">
						<a href="#shops-link">АДРЕСА МАГАЗИНОВ</a>
					</div>
				</div>
			</div>
		</article>
	</div>
</section>
<section class="sale-time">
	<div class="wrp clearfix">
		<article class="sale-timer">
			<div class="sale-time-in">
				<div class="title">
					ДО КОНЦА АКЦИИ ОСТАЛОСЬ:
				</div>
				<div class="times">
					<div id="timer-sale"></div>            
				</div>
			</div>
		</article>
	</div>
</section>
<section class="content sale-content">
	<div class="wrp clearfix nofilter">
		<article class="catalog main_cat" itemscope="" itemtype="http://schema.org/Product">
			<section class="catalog_main clearfix"><br/><br/></section>
			<div class="workarea grid2x1">
				<div class="catalog_list">
					<?
					//Магазины
					$CITY=$_COOKIE["city"];
					CModule::IncludeModule("iblock");
					global $arrFilter;
					$intSectionID = 0;
					$count = 12;
					$sort = 'rand';
					$SUBSECTIONS = 'Y';
					$arResult["VARIABLES"]["SECTION_CODE"] = '';

					$arrFilter[] = array("!PROPERTY_MIN_PRICE" => false);
					$arrFilter[] = array('PROPERTY_TOP_DESIGN_585' => array('7','25','41','21','20'));
					$arrFilter[] = array(
						"ID" => CIBlockElement::SubQuery("PROPERTY_CML2_LINK", array(
							"IBLOCK_ID" => 5,
							"<=PROPERTY_DISCOUNT_SPECIAL" => 50,
							)
						),
						"!ID"=> array(165779)
					);
					// $arrFilter[] = array("PROPERTY_CITY_YES" => $_COOKIE['city']);
					// $arrFilter = array( ["IBLOCK_ID"]=> "4", ["ACTIVE"]=> "Y", ["GLOBAL_ACTIVE"]=> "Y", ["=CODE"]=> "kolca" );

					$intSectionID = $APPLICATION->IncludeComponent(
						"bitrix:catalog.section",
						"",
						array(
							"IBLOCK_TYPE" => "catalog",
							"IBLOCK_ID" => "4",
							"ELEMENT_SORT_FIELD" => $sort,
							"ELEMENT_SORT_ORDER" => '',
							"PROPERTY_CODE" => array(
								0 => "",
								1 => "NEWPRODUCT",
								2 => "SALELEADER",
								3 => "SPECIALOFFER",
								4 => "",
							),
							"META_KEYWORDS" => '-',
							"META_DESCRIPTION" => '-',
							"BROWSER_TITLE" => '-',
							"INCLUDE_SUBSECTIONS" => $SUBSECTIONS,
							"SHOW_ALL_WO_SECTION" => "Y",
									"BASKET_URL" => "/personal/cart/",
							"ACTION_VARIABLE" => "action",
							"PRODUCT_ID_VARIABLE" => "id",
							"SECTION_ID_VARIABLE" => 'kolca',
							"PRODUCT_QUANTITY_VARIABLE" => "quantity",
							"PRODUCT_PROPS_VARIABLE" => 'prop',
							"FILTER_NAME" => "arrFilter",
							"CACHE_TYPE" => "A",
							"CACHE_TIME" => "36000000",
							"CACHE_FILTER" => "N",
							"CACHE_GROUPS" => "Y",
							"SET_STATUS_404" => "N",
							"SET_TITLE" => "Y",
							"DISPLAY_COMPARE" => 'N',
							"PAGE_ELEMENT_COUNT" => $count,
							"LINE_ELEMENT_COUNT" => 4,
							"PRICE_CODE" => array(),
							"USE_PRICE_COUNT" => 'N',
							"SHOW_PRICE_COUNT" => 1,

							"PRICE_VAT_INCLUDE" => 'Y',
							"USE_PRODUCT_QUANTITY" => 'Y',
							"ADD_PROPERTIES_TO_BASKET" => 'Y',
							"PARTIAL_PRODUCT_PROPERTIES" => "Y",
							"PRODUCT_PROPERTIES" => array(
							),
							"PAGER_TEMPLATE" => "blog_templ",
							"DISPLAY_TOP_PAGER" => "Y",
							"DISPLAY_BOTTOM_PAGER" => "N",
							"PAGER_TITLE" => "Товары",
							"PAGER_SHOW_ALWAYS" => "N",
							"PAGER_DESC_NUMBERING" => "N",
							"PAGER_DESC_NUMBERING_CACHE_TIME" => "36000000",
							"PAGER_SHOW_ALL" => "N",
							"OFFERS_CART_PROPERTIES" => array(
							),
							
							"OFFERS_FIELD_CODE" => array(
								0 => "",
								1 => "",
							),
							"OFFERS_PROPERTY_CODE" => Array(0=>"PROPERTY_PRICE_RETAIL", 1=>""),
							"OFFERS_SORT_FIELD" => "PROPERTY_PRICE_RETAIL",
							"OFFERS_SORT_ORDER" => "asc",
							"OFFERS_SORT_FIELD2" => "id",
							"OFFERS_SORT_ORDER2" => "desc",
							"OFFERS_LIMIT" => 1,

							// "SECTION_ID" => $arResult["VARIABLES"]["SECTION_ID"],
							"SECTION_ID" => 'kolca',
							"SECTION_CODE" => 'kolca',
							// "SECTION_URL" => "#SECTION_CODE#/obruchalnye/",
							// "DETAIL_URL" => "#SECTION_CODE#/#ELEMENT_ID#/",
							"CONVERT_CURRENCY" => "Y",
							"CURRENCY_ID" => "RUB",
							"HIDE_NOT_AVAILABLE" => "N",
							
							"ADD_PICT_PROP" => "-",
							"LABEL_PROP" => "-",
							"PRODUCT_DISPLAY_MODE" => "N",
							"OFFER_ADD_PICT_PROP" => "-",
							"OFFER_TREE_PROPS" => array(
								0 => "-",
							),
							"SHOW_DISCOUNT_PERCENT" => "Y",
							"SHOW_OLD_PRICE" => "Y",
							// 'PRODUCT_SUBSCRIPTION' => $SUBSECTIONS,
							"MESS_BTN_BUY" => "Купить",
							"MESS_BTN_ADD_TO_BASKET" => "В корзину",
							"MESS_BTN_COMPARE" => "Сравнение",
							"MESS_BTN_DETAIL" => "Подробнее",
							"MESS_NOT_AVAILABLE" => "Нет в наличии",
							
							"TEMPLATE_THEME" => "site",
							"ADD_SECTIONS_CHAIN" => "N",
							'ADD_TO_BASKET_ACTION' => 'ADD',
							'SHOW_CLOSE_POPUP' => 'N',
							'COMPARE_PATH' => 'compare/',
							"PRICE_CODE" => array("base_price","rozn_price","stock_price","minimal_price","Internet_price"),
						),
						$component
					);?>
      
      </div>
      <a href="/catalog/kolca/obruchalnye/" class="sale-show-all">Смотреть все обручальные кольца</a>
      <div style="clear: both;"></div>
  </div>
</article>
</div>
</section>    
<section id="shops-link" class="sale-map">
	<article class="map-wrap">
		<div class="map-in">
			<div class="title">
				<div class="wrp clearfix">
					<div class="name">БЛИЖАЙШИЕ К ВАМ МАГАЗИНЫ</div>
		             <div class="sel-city" style="text-align:center;margin-bottom:20px"><span style="border-bottom: 1px dotted;cursor:pointer">Сменить город</span></div>

			        <?
						function rus2translit($string) {
						    $converter = array(
						        'а' => 'a',   'б' => 'b',   'в' => 'v',
						        'г' => 'g',   'д' => 'd',   'е' => 'e',
						        'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
						        'и' => 'i',   'й' => 'y',   'к' => 'k',
						        'л' => 'l',   'м' => 'm',   'н' => 'n',
						        'о' => 'o',   'п' => 'p',   'р' => 'r',
						        'с' => 's',   'т' => 't',   'у' => 'u',
						        'ф' => 'f',   'х' => 'h',   'ц' => 'c',
						        'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
						        'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
						        'э' => 'e',   'ю' => 'yu',  'я' => 'ya',
						        
						        'А' => 'A',   'Б' => 'B',   'В' => 'V',
						        'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
						        'Ё' => 'E',   'Ж' => 'Zh',  'З' => 'Z',
						        'И' => 'I',   'Й' => 'Y',   'К' => 'K',
						        'Л' => 'L',   'М' => 'M',   'Н' => 'N',
						        'О' => 'O',   'П' => 'P',   'Р' => 'R',
						        'С' => 'S',   'Т' => 'T',   'У' => 'U',
						        'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
						        'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Sch',
						        'Ь' => '\'',  'Ы' => 'Y',   'Ъ' => '\'',
						        'Э' => 'E',   'Ю' => 'Yu',  'Я' => 'Ya',
						    );
						    return strtr($string, $converter);
						}
						function str2url($str) {
						    // переводим в транслит
						    $str = rus2translit($str);
						    // в нижний регистр
						    $str = strtolower($str);
						    // заменям все ненужное нам на "-"
						    $str = preg_replace('~[^-a-z0-9_]+~u', '-', $str);
						    // удаляем начальные и конечные '-'
						    $str = trim($str, "-");
						    return $str;
						}

						function getNewFormText($text, $numForm){
						    $urlXml = "http://export.yandex.ru/inflect.xml?name=".urlencode($text);
						    $result = @simplexml_load_file($urlXml);
						    if($result){
						        $arrData = array();
						        foreach ($result->inflection as $one) {
						           $arrData[] = (string) $one;
						        }
						        return $arrData[$numForm];
						    }
						    return false;
						}

						$CODE = str2url( $CITY );
						$j = 0;
						CModule::IncludeModule('iblock');
						$arSelect = Array("ID", "CODE", "PREVIEW_TEXT", "IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_*");//IBLOCK_ID и ID обязательно должны быть указаны, см. описание arSelectFields выше
						$arFilter = Array("IBLOCK_ID"=>13, "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y");
						$res = CIBlockElement::GetList(Array(), $arFilter, false, false, $arSelect);
						while($ob = $res->GetNextElement()){ 
							$arFields[$j] = $ob->GetFields();  
						 	$arProps[$j] = $ob->GetProperties();
						 	$arProps[$j]['coords123'] = $arFields[$j]['NAME'];
						 	$arProps[$j]['CODE'] = $arFields[$j]['CODE'];
						 	$j++;
						}

						foreach ($arProps as $key => $value) {
							$arCity[$value['city']['VALUE']] = $value;
						}
						ksort($arCity);

						$w=0;
						foreach ($arCity as $k => $val) {
							$w++;
							$citys[$k] = $val;
							$citys[$k]['NUM'] = $w;
							$citys[$k]['WORD'] = mb_substr($k,0,1,'UTF-8');
						}

						foreach ($arProps as $key => $value) {
							$arShop[$key]['coords'] = $value['coords123'];
							$arShop[$key]['address'] = $value['adress']['VALUE'];
						}?>
					<div class="sale-shops">
						<?for ($i = 0; $i< count($arFields); $i++) {?>
							<div class="shop non <?=$arFields[$i]['CODE']?>">
								<a href="/about/address/<?=str2url($arProps[$i]["city"]["VALUE"])?>/<?=str2url($arProps[$i]["adress"]["VALUE"])?>/">
									<?echo $arFields[$i]['PREVIEW_TEXT']?>, <?=nl2br( strip_tags( htmlspecialchars_decode( $arProps[$i]['adress']['VALUE']) ) )?>
								</a>
							</div>
						<?}?>
					</div>
				</div>
			</div>
			<div class="map">
				<script src="http://api-maps.yandex.ru/2.0/?load=package.full&lang=ru-RU" type="text/javascript"></script>
				<script type="text/javascript">
					var myMap;
					ymaps.ready(init); // Ожидание загрузки API с сервера Яндекса
					function init () {
						var geolocation = ymaps.geolocation,
        				coords = [geolocation.latitude, geolocation.longitude],
						myMap = new ymaps.Map("map", {
								center: coords, // Координаты центра карты
								zoom: 12 // Zoom
						});
						var coords = $('#region_id option:selected').attr('value').split(',');
						myMap.panTo([+coords[0],+coords[1]], {flying: true})
						
						$('#region_id').change(function(){
							var coords = $('#region_id option:selected').attr('value').split(',');
							// console.log(+coords[0]);
							myMap.panTo([+coords[0],+coords[1]], {flying: true})
						});
						
							myMap.controls.add(
					            new ymaps.control.ZoomControl()
					        );
					        houseCollection = new ymaps.GeoObjectCollection();
					        <?
					        foreach ($arShop as $key => $property) {?>
					        	var url = '/about/address/<?=str2url($arProps[$key]["city"]["VALUE"])?>/<?=str2url($arProps[$key]["adress"]["VALUE"])?>/';
					        	<?$coords = explode("~",$property['coords']);?>
		                        metroGeoObject = new ymaps.Placemark([<?=$coords[1]?>,<?=$coords[0]?>], {
					                hintContent: "<?=$property['address']?>",
					                balloonContent: '',
	                                url: url
	                            }, {
					                iconLayout: 'default#image',
					                iconImageHref: '/about/address/pointer.png', // картинка иконки
					                iconImageSize: [43, 62], // размеры картинки
					                iconImageOffset: [-3, -62]
					            });
					            houseCollection.add(metroGeoObject);
	                        <?}?>
						myMap.geoObjects.add(houseCollection);
                    }
				</script>
				<div id="map"></div>
				<select name="region_id" id="region_id" class=" non">
				<?foreach ($arCity as $key => $property) {
					if ($property['CODE'] == $CODE){
						$coords = explode("~",$property['coords123']);?>
						<option value="<?=$coords[1]?>,<?=$coords[0]?>" class="opt" code="<?=$property['CODE']?>" data-href="<?=$CODE?>" selected><?=$key?></option>
					<?}
					else{
						$coords = explode("~",$property['coords123']);?>
						<option value="<?=$coords[1]?>,<?=$coords[0]?>" data-href="<?=$property['CODE']?>" class="opt"><?=$key?></option>
					<?}?>
				<?}?>
				</select>
			</div>
		</div>
	</article>
</section>
<section class="sale-cond">
	<div class="wrp clearfix">
		<article>
			<div class="sale-cond-in">          
				<div class="title">УСЛОВИЯ АКЦИИ</div>
				<div class="desc">В основе рекламной кампании акции «Обручальные кольца: 2=1» лежит специальное предложение - при покупке обручального кольца из товарных групп "изделия с фианитами" и "изделия без камней" покупатель может выбрать второе украшение из части этого ассортимента, заплатив 50% от суммарной бирочной стоимости двух украшений (механизм расчета скидки 50% осуществляется суммированием бирочной стоимости двух изделий и их делением суммы пополам).<br>Обратите внимание, что акция распространяется только на часть товаров. <br>Товары, отмеченные желтыми ценниками, продаются по фиксированной цене. Цена на них включает в себя максимальную скидку и является окончательной.</div>
				<a href="/action/obruchalnye-koltsa-2-1/">Подробнее</a>
			</div>
			<a href="/catalog/kolca/obruchalnye/" class="sale-show-all">Смотреть все обручальные кольца</a>
		</article>
	</div>
</section>

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>