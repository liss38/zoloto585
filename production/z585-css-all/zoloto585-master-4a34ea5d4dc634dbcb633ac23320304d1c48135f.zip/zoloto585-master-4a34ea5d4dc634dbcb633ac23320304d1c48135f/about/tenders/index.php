<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("");
/*$APPLICATION->SetPageProperty("keywords", "тендеры, сеть 585, gold, ювелирный магазин, ювелирная сеть, официальный сайт");*/
$APPLICATION->SetPageProperty("description", "Тендеры. О компании. Сеть ювелирных магазинов 585 Gold.");
$APPLICATION->SetPageProperty("title", "Тендеры | О ювелирной сети | Ювелирный магазин 585 Gold");
?><section class="content">
<div class="wrp clearfix">
	<h1>Тендеры</h1>
 <article class="text_page tenders">
	<div class="atten_text">
		 На поставку торгового оборудования и светодиодной подсветки витрин.
	</div>
	<div class="mail">
		 Предложения отправляйте на электронную почту: <a href="mailto:Melehin.Stanislav@zoloto585.ru">Melehin.Stanislav@zoloto585.ru</a>
	</div>
	<div class="atten_text">
		 На поставку хозяйственных и канцелярских товаров по всей России.
	</div>
	<div class="mail">
		 Предложения отправляйте на электронную почту: <a href="mailto:baronina.valentina@zoloto585.ru">baronina.valentina@zoloto585.ru</a>
	</div>
	<div class="atten_text">
		 Для обслуживания магазинов в регионах Поволжье, Юг, Сибирь.
	</div>
	<div class="mail">
		 Предложения отправляйте на электронную почту Михаилу Кутасову:&nbsp;<a href="mailto:kutasov@zoloto585.ru">Kutasov@zoloto585.ru</a>
	</div>
	<div class="atten_text">
		 Для технического&nbsp;обслуживания магазинов в Санкт-Петербурге.
	</div>
	<div class="mail">
		 Предложения отправляйте на электронную почту Михаилу Кутасову: <a href="mailto:kutasov@zoloto585.ru">Kutasov@zoloto585.ru</a>&nbsp;или на почту Валентине Барониной:&nbsp;<a href="mailto:baronina.valentina@zoloto585.ru">baronina.valentina@zoloto585.ru</a>
	</div>
 </article>
</div>
 </section><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>