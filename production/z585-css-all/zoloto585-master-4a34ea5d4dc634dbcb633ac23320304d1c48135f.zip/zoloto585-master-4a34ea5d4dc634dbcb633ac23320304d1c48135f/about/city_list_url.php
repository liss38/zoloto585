<? require_once($_SERVER['DOCUMENT_ROOT'] . "/bitrix/modules/main/include/prolog_before.php");

function rus2translit($string) {
    $converter = array(
        'а' => 'a',   'б' => 'b',   'в' => 'v',
        'г' => 'g',   'д' => 'd',   'е' => 'e',
        'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
        'и' => 'i',   'й' => 'y',   'к' => 'k',
        'л' => 'l',   'м' => 'm',   'н' => 'n',
        'о' => 'o',   'п' => 'p',   'р' => 'r',
        'с' => 's',   'т' => 't',   'у' => 'u',
        'ф' => 'f',   'х' => 'h',   'ц' => 'c',
        'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
        'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
        'э' => 'e',   'ю' => 'yu',  'я' => 'ya',
        
        'А' => 'A',   'Б' => 'B',   'В' => 'V',
        'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
        'Ё' => 'E',   'Ж' => 'Zh',  'З' => 'Z',
        'И' => 'I',   'Й' => 'Y',   'К' => 'K',
        'Л' => 'L',   'М' => 'M',   'Н' => 'N',
        'О' => 'O',   'П' => 'P',   'Р' => 'R',
        'С' => 'S',   'Т' => 'T',   'У' => 'U',
        'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
        'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Sch',
        'Ь' => '\'',  'Ы' => 'Y',   'Ъ' => '\'',
        'Э' => 'E',   'Ю' => 'Yu',  'Я' => 'Ya',
    );
    return strtr($string, $converter);
}
function str2url($str) {
    // переводим в транслит
    $str = rus2translit($str);
    // в нижний регистр
    $str = strtolower($str);
    // заменям все ненужное нам на "-"
    $str = preg_replace('~[^-a-z0-9_]+~u', '-', $str);
    // удаляем начальные и конечные '-'
    $str = trim($str, "-");
    return $str;
}


if (CModule::IncludeModule("iblock")):
$i=0;
  $array_adress=array();
  $mytext='';
  $arFilter = Array('IBLOCK_ID'=>13, 'ACTIVE'=>'Y');
  $arSelect = Array("NAME","ID","IBLOCK_ID","PROPERTY_adress","PROPERTY_city");
  $db_list = CIBlockElement::GetList(Array("PROPERTY_city"=>"ASC"), $arFilter, false, Array("nTopCount"=>1000));
  while($ar_result = $db_list->GetNextElement())
  {
	 $arFields = $ar_result->GetFields();
	 $arProps = $ar_result->GetProperties();	 
	 $array_adress[$i]["koords"]=$arFields["NAME"];
	 $array_adress[$i]["city_ru"]=$arProps["city"]["VALUE"];
	 $array_adress[$i]["adress_ru"]=$arProps["adress"]["VALUE"];
    $array_adress[$i]["url"]='/about/address/'.str2url($arProps["city"]["VALUE"]).'/'.str2url($arProps["adress"]["VALUE"]).'/';
  $mytext.=$array_adress[$i]["city_ru"].';'.$array_adress[$i]["koords"].';'.$array_adress[$i]["adress_ru"].';'.$array_adress[$i]["url"]."\r\n"; // Исходная строка

  $i++;
  } 
endif;
print_r($i);

$fp = fopen("adress.txt", "a"); // Открываем файл в режиме записи 
$test = fwrite($fp, $mytext); // Запись в файл
if ($test) echo 'Данные в файл успешно занесены.';
else echo 'Ошибка при записи в файл.';
fclose($fp); //Закрытие файла

?>
