<?
$sSectionName = "Гарантия";
$arDirProperties = array(
);
?>