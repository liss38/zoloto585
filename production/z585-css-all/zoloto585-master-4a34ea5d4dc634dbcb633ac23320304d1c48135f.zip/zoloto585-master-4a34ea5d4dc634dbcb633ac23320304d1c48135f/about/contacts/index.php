<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("");
/*$APPLICATION->SetPageProperty("keywords", "контактная информация, контакты, сеть 585, gold, ювелирный магазин, ювелирная сеть, официальный сайт");*/
$APPLICATION->SetPageProperty("description", "Контактная информация. О компании. Сеть ювелирных магазинов 585 Gold.");
$APPLICATION->SetPageProperty("title", "Контакты | О ювелирной сети | Ювелирный магазин 585 Gold");
?><?

function rus2translit($string) {
    $converter = array(
        'а' => 'a',   'б' => 'b',   'в' => 'v',
        'г' => 'g',   'д' => 'd',   'е' => 'e',
        'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
        'и' => 'i',   'й' => 'y',   'к' => 'k',
        'л' => 'l',   'м' => 'm',   'н' => 'n',
        'о' => 'o',   'п' => 'p',   'р' => 'r',
        'с' => 's',   'т' => 't',   'у' => 'u',
        'ф' => 'f',   'х' => 'h',   'ц' => 'c',
        'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
        'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
        'э' => 'e',   'ю' => 'yu',  'я' => 'ya',
        
        'А' => 'A',   'Б' => 'B',   'В' => 'V',
        'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
        'Ё' => 'E',   'Ж' => 'Zh',  'З' => 'Z',
        'И' => 'I',   'Й' => 'Y',   'К' => 'K',
        'Л' => 'L',   'М' => 'M',   'Н' => 'N',
        'О' => 'O',   'П' => 'P',   'Р' => 'R',
        'С' => 'S',   'Т' => 'T',   'У' => 'U',
        'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
        'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Sch',
        'Ь' => '\'',  'Ы' => 'Y',   'Ъ' => '\'',
        'Э' => 'E',   'Ю' => 'Yu',  'Я' => 'Ya',
    );
    return strtr($string, $converter);
}
function str2url($str) {
    // переводим в транслит
    $str = rus2translit($str);
    // в нижний регистр
    $str = strtolower($str);
    // заменям все ненужное нам на "-"
    $str = preg_replace('~[^-a-z0-9_]+~u', '-', $str);
    // удаляем начальные и конечные '-'
    $str = trim($str, "-");
    return $str;
}

$j = 0;
CModule::IncludeModule('iblock');
$arSelect = Array("ID","CODE", "PREVIEW_TEXT", "IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_*");//IBLOCK_ID и ID обязательно должны быть указаны, см. описание arSelectFields выше
$arFilter = Array("IBLOCK_ID"=>13, "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y");
$res = CIBlockElement::GetList(Array(), $arFilter, false, false, $arSelect);
while($ob = $res->GetNextElement()){ 
	$arFields[$j] = $ob->GetFields();  
 	$arProps[$j] = $ob->GetProperties();
 	$arProps[$j]['coords123'] = $arFields[$j]['NAME'];
 	$j++;
}

foreach ($arProps as $key => $value) {
	$arCity[$value['city']['VALUE']] = $value;

}

ksort($arCity);
$w=0;
foreach ($arCity as $k => $val) {
	$w++;
	$citys[$k] = $val;
	$citys[$k]['NUM'] = $w;
	$citys[$k]['WORD'] = mb_substr($k,0,1,'UTF-8');

}


foreach ($arProps as $key => $value) {
	$arShop[$key]['coords'] = $value['coords123'];
	$arShop[$key]['address'] = $value['adress']['VALUE'];
}


?> <section class="content">
<div class="wrp clearfix">
	<h1>Контакты</h1>
 <article class="text_page contacts">
	<div class="atten_text">
		 Горячая линия: 8&nbsp;800&nbsp;555-1-585 по&nbsp;России звонок бесплатный
	</div>
	<p>
 <b>Центральный офис.</b>&nbsp;Телефон (812) 244-77-31; факс (812)244-10-32 <br>
 <b>Отдел рекламы.</b>&nbsp;Для коммерческих предложений рекламного характера:&nbsp;<a href="mailto:reklama@zoloto585.ru">reklama@zoloto585.ru</a>&nbsp;
	</p>
	<h3>Отделы персонала Территориальных дирекций <br>
	 по вопросам трудоустройства</h3>
	<p>
 <b>Юг</b> - Кондукова Вера +7 (961) 421-76-76;&nbsp;<a href="mailto:Kondukova.Vera@zoloto585.ru">Kondukova.Vera@zoloto585.ru</a><br>
 <b>Северо-Запад (СПб)</b> - Сильченко Марина +7(909) 585-85-15;&nbsp;<a href="mailto:marina.silchenko@zoloto585.ru">Marina.Silchenko@zoloto585.ru</a><br>
 <b>Поволжье</b> - Карташева Анастасия +7 (906) 125-85-07;&nbsp;<a href="mailto:kartasheva.nastya@zoloto585.ru">Kartasheva.Nastya@zoloto585.ru</a><br>
 <b>Урал, Сибирь</b> - Бадурдинова Ирина +7 (967) 859-94-79;&nbsp;<a href="mailto:badurdinova.irina@zoloto585.ru">Badurdinova.Irina@zoloto585.ru</a><br>
 <b>Общие номер телефона и&nbsp;e-mail:</b>&nbsp;(812) 244-77-31;&nbsp;<a href="mailto:kandidat2014@zoloto585.ru">Kandidat2014@zoloto585.ru</a>
	</p>
	<p>
 <b>Пресс-служба.</b> <a href="mailto:press2013@zoloto585.ru">press2013@zoloto585.ru</a><br>
 <b>Отдел развития (по вопросам аренды):</b> (812) 244-77-31, доб. 4241; e-mail: <a href="mailto:rent2013@zoloto585.ru">rent2013@zoloto585.ru</a>&nbsp;;&nbsp;<a href="mailto:mormina@zoloto585.ru">mormina@zoloto585.ru</a><br>
 <b>Отдел эксплуатации (для поставщиков):</b> (812) 244-77-31, доб. 4172
	</p>
 </article> <article class="vacancies" style="margin-top:20px;">
	<div class="vacancy_list">
		<div class="">
			<div class="desc text_page show_box clearfix" style="display:none;">
				<div class="column">
					 <?
				$count = count($citys)/3;
				foreach ($citys as $key => $property) {?> <?if ($property['NUM'] > 0 AND $property['NUM'] < $count){?>
					<div class="address-link">
 <span class="word"><?echo $property['WORD'];?></span><a style="display: inline-block" href="/about/address/<?=str2url($key)?>/"><?=$key?></a>
					</div>
					 <?}?> <?}?>
				</div>
				<div class="column">
					 <?foreach ($citys as $key => $property) {?> <?if ($property['NUM'] > $count AND $property['NUM'] < $count*2){?>
					<div class="address-link">
 <span class="word"><?echo $property['WORD'];?></span><a style="display: inline-block" href="/about/address/<?=str2url($key)?>/"><?=$key?></a>
					</div>
					 <?}?> <?}?>
				</div>
				<div class="column">
					 <?foreach ($citys as $key => $property) {?> <?if ($property['NUM'] > $count*2 && $property['NUM'] < $count*3+1){?>
					<div class="address-link">
 <span class="word"><?echo $property['WORD'];?></span><a style="display: inline-block" href="/about/address/<?=str2url($key)?>/"><?=$key?></a>
					</div>
					 <?}?> <?}?>
				</div>
			</div>
 <a href="/about/address/" class="show show-city">Адреса магазинов</a>
		</div>
	</div>
 </article>
</div>
 </section> <br>
<script>
jQuery(document).ready(function($){	
	for (var i = 86; i > 1; i--) {
		var word1 = $('.word')[i-2]; 
		var word2 = $('.word')[i-1]; 
   		if (word1.innerText == word2.innerText){
   			word2.innerText = '';	

   		}
  		   		   		
	}
});
</script><?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php")?>