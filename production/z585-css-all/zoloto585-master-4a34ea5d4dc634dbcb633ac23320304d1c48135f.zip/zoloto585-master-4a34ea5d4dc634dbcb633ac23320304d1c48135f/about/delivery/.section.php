<?
$sSectionName = "Доставка";
$arDirProperties = Array(

);
?>