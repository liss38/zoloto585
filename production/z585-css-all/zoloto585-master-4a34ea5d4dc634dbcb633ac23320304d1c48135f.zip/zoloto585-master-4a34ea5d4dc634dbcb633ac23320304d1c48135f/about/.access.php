<?
$PERM["address"]["8"]="W";
?>