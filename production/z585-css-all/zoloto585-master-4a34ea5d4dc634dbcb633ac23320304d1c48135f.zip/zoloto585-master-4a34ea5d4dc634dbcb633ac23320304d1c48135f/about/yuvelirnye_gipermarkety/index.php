<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
/*$APPLICATION->SetPageProperty("keywords", "адреса ювелирных гипермаркетов, сеть 585, gold, ювелирный магазин, ювелирная сеть, официальный сайт");*/
$APPLICATION->SetPageProperty("description", "Адреса гипермаркетов. О компании. Сеть ювелирных магазинов 585 Gold.");
$APPLICATION->SetPageProperty("title", "Адреса ювелирных гипермаркетов | О ювелирной сети | Ювелирный магазин 585 Gold");
?>
<?
$j = 0;
CModule::IncludeModule('iblock');
$arSelect = Array("ID", "PREVIEW_TEXT", "IBLOCK_ID", "NAME", "DATE_ACTIVE_FROM","PROPERTY_*");//IBLOCK_ID и ID обязательно должны быть указаны, см. описание arSelectFields выше
$arFilter = Array("IBLOCK_ID"=>13, "ACTIVE_DATE"=>"Y", "ACTIVE"=>"Y");
$res = CIBlockElement::GetList(Array(), $arFilter, false, false, $arSelect);
while($ob = $res->GetNextElement()){ 
	$arFields[$j] = $ob->GetFields();  
 	$arProps[$j] = $ob->GetProperties();
 	$arProps[$j]['coords123'] = $arFields[$j]['NAME'];
 	$j++;
}

foreach ($arProps as $key => $value) {
	$arCity[$value['city']['VALUE']] = $value;
}
ksort($arCity);
foreach ($arProps as $key => $value) {
    if(stristr($value['coords']['VALUE'], 'гипермаркет') == TRUE){
        $arShop[$key]['coords'] = $value['coords123'];
    $arShop[$key]['address'] = $value['adress']['VALUE'];
    }
}
//var_dump($arShop);
/*foreach ($arProps as $key => $property){
	if(stristr($property['coords']['VALUE'], 'гипермаркет') == TRUE){
		echo '<pre>';
		print_r($property['city']);
	}
}*/
?>
<script>
	jQuery(document).ready(function ($) {
		"use strict";
		$('#perfect_scroll').perfectScrollbar();
		var city = $('#region_id option:selected').text();
			$.ajax({
				url: "/about/address/city_ajax.php",
				data: {city: city, type: 'гипермаркет'},
				type: "post",
				success: function(html) {
					$('.list').html(html);
				}
			});
		$('#region_id').change(function(){
			var city = $('#region_id option:selected').text();
			$.ajax({
				url: "/about/address/city_ajax.php",
				data: {city: city, type: 'гипермаркет'},
				type: "post",
				success: function(html) {
					$('.list').html(html);
				}
			});

		});
	});
</script>
<section class="content">
<div class="wrp clearfix">
	<h1>Ювелирные гипермаркеты: <span>Еще больше украшений – еще больше низких цен!</span></h1>
	
	<article class="promo_detail">
		<div class="detail_img"><img src="<?=SITE_TEMPLATE_PATH?>/images/pic/giper_image.jpg" alt=""></div>
		
		<div class="descr">Ювелирные гипермаркеты 585 GOLD – это новый формат магазинов нашей ювелирной сети. Мы делаем гипермаркеты для Вас, чтобы выбирать украшения в ювелирной сети 585 GOLD было еще приятнее и удобнее! Мы уверены, что в гипермаркете 585 GOLD Вы найдете именно то, что нужно. Ведь у нас Вас всегда ждут самый большой выбор ювелирных украшений и самые приятные цены!</div>
		
		<div class="box_icon_info clearfix">
			<div class="col">
				<span class="icon design"></span>
				<h3>Новый дизайн</h3>
				<p>красивые магазины <br>площадью более 300 м2</p>
			</div>
			
			<div class="col">
				<span class="icon full"></span>
				<h3>Огромный выбор</h3>
				<p>свыше 17 500 украшений <br>в одном магазине</p>
			</div>
			
			<div class="col">
				<span class="icon grafik"></span>
				<h3>Низкие цены</h3>
				<p>средняя цена украшения всего <br>3 000 руб.</p>
			</div>
		</div>
		
		<h2>Адреса гипермаркетов 585 GOLD</h2>
		<div class="shops clearfix">					
			<div class="maps">
				<script src="http://api-maps.yandex.ru/2.0/?load=package.full&lang=ru-RU" type="text/javascript"></script>
				<script type="text/javascript">
					var myMap;
					ymaps.ready(init); // Ожидание загрузки API с сервера Яндекса
					function init () {
						var coords = $('#region_id option:selected').attr('value').split(',');
						myMap = new ymaps.Map("map", {
								center: [+coords[0],+coords[1]], // Координаты центра карты
								zoom: 16 // Zoom
						});
						$('#region_id').change(function(){
							var coords = $('#region_id option:selected').attr('value').split(',');
							console.log(+coords[0]);
							myMap.panTo([+coords[0],+coords[1]], {flying: true})
						});
						
						
							myMap.controls.add(
					            new ymaps.control.ZoomControl()
					        );
					        houseCollection = new ymaps.GeoObjectCollection();
					        <?foreach ($arShop as $key => $property) {?>
					        	<?$coords = explode("~",$property['coords']);?>
	                       		metroGeoObject = new ymaps.Placemark([<?=$coords[1]?>,<?=$coords[0]?>], {
				                hintContent: "<?=$property['address']?>",
                                    url: 'http://new.zoloto585.ru/about/address/details.php?ID=<?=$key?>',
				                balloonContent: ''}, {
				                iconLayout: 'default#image',
				                iconImageHref: 'pointer.png', // картинка иконки
				                iconImageSize: [43, 62], // размеры картинки
				                iconImageOffset: [-3, -62]
				            });
				            houseCollection.add(metroGeoObject);
	                                	
						<?}?>
						myMap.geoObjects.add(houseCollection);
                        myMap.geoObjects.events.add('click', function (e) {
                            window.location.href = e.get('target').properties.get('url');
                        });
					}
				</script>
				<div id="map" class="map"></div>
			</div>
		
			<div class="shop_list">
			<div class="select">
				<select name="region_id" id="region_id" class="">
				<?foreach ($arProps as $key => $property) {
				if(stristr($property['coords']['VALUE'], 'гипермаркет') == TRUE){	
					$coords = explode("~",$property['coords123']);?>
					<?if ($property['city']['VALUE'] == 'Владимир'){?>
					<option value="<?=$coords[1]?>,<?=$coords[0]?>" class="opt" selected><?=$property['city']['VALUE']?></option>
					<?} else{?>
					<option value="<?=$coords[1]?>,<?=$coords[0]?>" class="opt"><?=$property['city']['VALUE']?></option>
					<?}?>
				<?}
				}?>
				</select>
			</div>

				<div id="perfect_scroll" class="perfect-scroll">
					<div class="list">
					<?for ($i = 0; $i<count($arFields); $i++) {

						if(stristr($arProps[$i]['coords']['VALUE'], 'гипермаркет') == TRUE) {?>
						<figure class="item">
							<figcaption><a href="/about/address/details.php?ID=<?=$i?>"><?echo $arProps[$i]['coords']['VALUE']?></a></figcaption>
							<address><?=htmlspecialchars_decode($arProps[$i]['content']['VALUE']['TEXT'])?></address>
						</figure>
					<?}
					}?>
					</div>
				</div>
			</div>
		</div>
	</article>
</div>
 </section>
 <?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>