<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/sale/services/ajax/sale/location/index.php");
?>