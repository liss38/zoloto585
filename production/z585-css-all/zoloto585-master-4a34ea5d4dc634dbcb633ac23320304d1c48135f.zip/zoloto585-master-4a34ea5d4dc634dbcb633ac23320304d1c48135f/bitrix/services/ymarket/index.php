<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/sale/services/ymarket/index.php");
?>