<?
$MESS['SIMAI_COMPONENTS_NAME']      = 'SIMAI components';
$MESS["SIMAI_TEMPLATE_NAME"]        = "SIMAI Export to Yandex.Market";
$MESS["SIMAI_TEMPLATE_DESCRIPTION"] = "Export goods to Yandex.Market in YML format with trade offers support";
$MESS["SIMAI_EXPORT"]               = "SIMAI Export to Yandex.Market";