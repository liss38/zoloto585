<?
$MESS['SIMAI_COMPONENTS_NAME']      = 'Компоненты SIMAI';
$MESS["SIMAI_TEMPLATE_NAME"]        = "SIMAI Выгрузка в Яндекс.Маркет";
$MESS["SIMAI_EXPORT"]               = "SIMAI Выгрузка в Яндекс.Маркет";
$MESS["SIMAI_TEMPLATE_DESCRIPTION"] = "Выгрузка товаров в Яндекс.Маркет в формате YML c поддержкой товарных предложений";