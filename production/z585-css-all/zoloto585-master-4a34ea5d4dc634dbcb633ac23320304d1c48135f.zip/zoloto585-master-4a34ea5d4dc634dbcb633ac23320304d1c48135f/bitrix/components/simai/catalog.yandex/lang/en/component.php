<?
$MESS["SIMAI_MODULE_NOT_INSTALLED"]  = "Module \"SIMAI Export to Yandex.Market\" is not installed";
$MESS["SIMAI_REQUIRED_FIELDS_EMPTY"] = "Required fields is empty";
