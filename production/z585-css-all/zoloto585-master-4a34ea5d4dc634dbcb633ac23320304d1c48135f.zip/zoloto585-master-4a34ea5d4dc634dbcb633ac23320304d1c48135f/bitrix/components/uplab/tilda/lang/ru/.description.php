<?
$MESS['UPT_TITLE'] = "uplab.tilda";
$MESS['UPT_DESCR'] = "Настройки компонента uplab.tilda";
$MESS['UPT_NAME'] = "Uplab";
?>