<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();


$arComponentDescription = array(
	"NAME" => GetMessage("UPT_TITLE"),
	"DESCRIPTION" => GetMessage("UPT_DESCR"),
	"ICON" => "/images/.gif",
	"PATH" => array(
			"ID" => "uplab",
            "NAME" => GetMessage("UPT_NAME")

	),
);


?>