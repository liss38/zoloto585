<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");

if(!CModule::IncludeModule("uplab.tilda")){
    ShowError( GetMessage("CC_UPT_NOT_INSTALLED"));
}

if($arParams["STOP_CACHE"] == "Y"){
    $GLOBALS['APPLICATION']->RestartBuffer(); 
    print CUplabTilda::get_full_html_pages($arParams["PAGE"]);
    die();
}

print CUplabTilda::get_html_project($arParams["PROJECT"],$arParams["PAGE"]) .CUplabTilda::$TildaOnPageConst;
?>