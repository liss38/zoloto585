<?
$MESS["UPT_SELECT_PROJECT"] = "Выберите проект";
$MESS["UPT_SELECT_PAGE"] = "Выберите страницу";
$MESS["UPT_STOP_CACHE"] = "Не выводить шаблон сайта";
$MESS["UPT_TITLE"] = "Uplab.Tilda";
$MESS["UPT_DESCR"] = "Модуль интеграции с сервисом Tilda.ws";
$MESS["UPT_NAME"] = "Uplab.Tilda";
$MESS["UPT_CLEAR_CACHE"] = 'Очистить кеш';
$MESS["UPT_CLEAR"] = 'Очистить';
$MESS['UPT_PROJECTS_UPDATE'] = 'Синхронизировать';
?>