<?
$MESS ['CC_UPT_NOT_INSTALLED'] = "Uplab.Tilda not installed";
?>