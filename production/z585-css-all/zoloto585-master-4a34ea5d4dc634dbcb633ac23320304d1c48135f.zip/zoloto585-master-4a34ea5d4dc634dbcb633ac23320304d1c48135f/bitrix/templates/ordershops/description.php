<?
$arTemplate = array (
  'NAME' => 'ordershops',
  'DESCRIPTION' => '',
  'SORT' => '',
  'TYPE' => '',
);
?>