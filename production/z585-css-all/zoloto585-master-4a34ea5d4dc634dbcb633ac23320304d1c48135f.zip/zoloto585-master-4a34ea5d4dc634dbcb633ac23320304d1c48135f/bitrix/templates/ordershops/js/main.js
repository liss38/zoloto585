var timer = null;
var timerRefresh = null;
var readyOrders = [];

function showRefresh() {
    $.fancybox({
        'width': '40%',
        'height': '40%',
        'autoScale': true,
        'transitionIn': 'fade',
        'transitionOut': 'fade',
        'type': 'ajax',
        'href': 'iblock.php?code=refreshButton',
        'closeBtn': false,
        'closeClick': false,
        helpers: {
            overlay: {closeClick: false},
            opacity: 0.8, // or the opacity you want
            css: {'background-color': '#ff0000'} // or your preferred hex color value
        }
    });
}

function findFancyBox() {
    if ($('.fancybox-skin :visible').size()) {
        clearTimeout(timerRefresh);
        timerRefresh = null;
    } else {
        if (timerRefresh == null && !$(".mainContainer").length) {
            timerRefresh = setTimeout("showRefresh()", 1000 * 60 * 5);
        }
    }
}

setInterval("findFancyBox()", 2000);


//GET PARAMETER FROM URL QUERY
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

/*Функция обновления статуса заказа : меняет статус и отображает alert bootstrap*/
function updateOrder(id, status, comment, substatus) {
    var sText = "Выдача";
    if (status == 'C')sText = "Отмена";
    var text = "Заказу номер " + id + " изменен статус на '" + sText + "'";
    if (comment) {
        if (status == 'C') {
            text += ", комментарий: '" + comment + "'";
        } else {
            text += ", подстатус: '" + comment + "'";
        }
    }

    $(".alertText").html(text);
    for (var i = 0; i < readyOrders.length; i++) {
        if (readyOrders[i] == id)return;
    }
    //if (readyOrders.contains(id))return;

    readyOrders.push(id);
    $.get("/ordershops/ajax.php", {
        act: "change_order_status",
        id: id,
        status: status,
        substatus: substatus,
        comment: comment
    }, function (data) {
        /*
         var size1=$(".newButton span").html();
         var size2=$(".readyButton span").html();
         $(".newButton span").html(size1-1);
         $(".readyButton span").html(size2+1);
         */
        //alert(data);
        $(".alertMain").show();
        $(".fancybox-close").click();
        $("tr.order" + id).fadeOut(400).addClass('reallyHidden');
        location.reload();
    });
}


function buy_order(order, mode, changeStatus, reload) {
    var status = 'F';
    var checkNum = $(".checkNum" + order).val();
    var comment = '';
    switch (mode) {
        case 1:
            comment = "Заказ продан, номер кассового чека: " + checkNum;
            if (!checkNum) {
                alert('Не указан номер кассового чека.');
                return;
            }
            break;
        case 2:
            comment = "Купил другой товар, номер кассового чека: " + checkNum;
            if (!checkNum) {
                alert('Не указан номер кассового чека.');
                return;
            }
            break;
        case 3:
            comment = "Клиент отказался от покупки";
            status = 'C';
            break;
    }
    $(".alertText").html(comment);
    $.get("/ordershops/ajax.php", {
        act: "buy_order",
        order: order,
        status: status,
        comment: comment,
        changeStatus: changeStatus
    }, function (data) {
        if(data.trim() == '1' || reload==1){
            location.reload();
        }
        $(".alertMain").show();
        $(".fancybox-close").click();
        $("tr.order" + order).fadeOut(400);
    });
}


//alert(11111);

$(document).ready(function () {

    setTimeout("$('.refresh_container').show();", 5000);

    if ($(".newList tr").size() > 1) {
        $('.newButton span').html($(".newList tr").size() - 1);
        if ($(".newList .lostOrder").size()) {
            $('.lostButton span').html($(".newList .lostOrder").size());
            $('.error_header').show();
            $('.error_header span').html($(".newList .lostOrder").size());
        }
    }
    if ($(".readyList tr").size() > 1) {
        $('.readyButton span').html($(".readyList tr").size() - 1);
    }

    if ($(".refuseList tr").size() > 1) {
        $('.refuseButton span').html($(".refuseList tr").size() - 1);
    }

    //alert(order);

    //alert(2);

    //$('.refreshButton').click();


    $(".questionsButton").fancybox({type: 'ajax', width: 1200, ajax: {type: "GET"}});
    $(".learnButton").fancybox({type: 'ajax', width: 1200, ajax: {type: "GET"},});
    var elems = $("a.statusLink");
    for (var i = 0; i < elems.size(); i++) {
        var elem = elems.eq(i);
        var data = elem.attr("data-id");
        var obj = eval("window.ord" + data);
        elem.fancybox({
            type: 'ajax',
            width: 1200,
            ajax: {
                type: "GET",
                data: obj
            },
        });
    }

    var order = getParameterByName("order");
    if (order != null) {
        $(".statusLink" + order).click();
    }

    elems = $("a.finishLink");
    for (var i = 0; i < elems.size(); i++) {
        var elem = elems.eq(i);
        var orderNum = /(\d+)/.exec(elem.attr('class'));
        var changeStatus = elem.hasClass("changeStatus") ? 1 : 0;
        var reload = elem.hasClass("reload") ? 1 : 0;
        elem.fancybox({
            type: 'ajax',
            width: 1200,
            ajax: {
                type: "GET",
                data: {order: orderNum[1], changeStatus: changeStatus, reload: reload}
            },
        });
    }


    elems = $("a.canselLink");
    for (var i = 0; i < elems.size(); i++) {
        var elem = elems.eq(i);
        var orderNum = /(\d+)/.exec(elem.attr('class'));
        var changeStatus = elem.hasClass("changeStatus") ? 1 : 0;
        var reload = elem.hasClass("reload") ? 1 : 0;
        elem.fancybox({
            type: 'ajax',
            width: 1200,
            ajax: {
                type: "GET",
                data: {order: orderNum[1], changeStatus: changeStatus, reload: reload}
            },
        });
    }

    //alert(12345);
    var trList = $(".order");
    if (trList.size()) {
        $(".tableOrderList").show();
    } else {
        $(".noOrder").show();
    }

    elems = $('.activeStatusButton');
    if (!elems.size()) {
        $(".statusLink button").attr("disabled", "disabled");
    }

    if ($(".refuseList tr").size() > 1) {
        $('.refuseButton').click();
    } else {
        $('.newButton').click();
    }
});

$('.newButton').click(function () {
    if ($(".refuseList tr").size() > 1) {
        $('#myModal').modal('toggle');

        return;
    }
    $('.oList').hide();
    $('.noOrder').hide();
    $(".navi__button").removeClass("navi__button--active");
    $(this).addClass("navi__button--active");
    if ($(".newList tr").size() > 1) {
        $('.newList tr.order').show();
        //$('.newList tr.lostOrder').show();
        $('.newList').show();
    } else {
        $('.noOrder').show();
    }
    $('.orders__header').html('Заказы требующие обработки');
})

$('.lostButton').click(function () {
    if ($(".refuseList tr").size() > 1) {
        $('#myModal').modal('toggle');

        return;
    }
    $('.oList').hide();
    $('.noOrder').hide();
    $(".navi__button").removeClass("navi__button--active");
    $(this).addClass("navi__button--active");
    if ($(".newList tr").size() > 1) {
        $('.newList tr.order').hide();
        $('.newList tr.lostOrder').show();
        $('.newList').show();
    } else {
        $('.noOrder').show();
    }
    $('.orders__header').html('Заказы требующие обработки');
})

$('.readyButton').click(function () {
    if ($(".refuseList tr").size() > 1) {
        $('#myModal').modal('toggle');

        //alert("Сначала нужно обработать заказы в статусе 'Отказ'.");
        return;
    }
    $('.oList').hide();
    $('.noOrder').hide();
    $(".navi__button").removeClass("navi__button--active");
    $(this).addClass("navi__button--active");
    if ($(".readyList tr").size() > 1) {
        $('.readyList').show();
    } else {
        $('.noOrder').show();
    }
    $('.orders__header').html('Заказы ожидающие клиентов');

})


$('.refuseButton').click(function () {
    $('.oList').hide();
    $('.noOrder').hide();
    $(".navi__button").removeClass("navi__button--active");
    $(this).addClass("navi__button--active");
    if ($(".refuseList tr").size() > 1) {
        $('.refuseList').show();
    } else {
        $('.noOrder').show();
    }
    $('.orders__header').html('Эти заказы были сделаны более 3 дней назад.  <br /> <br /><font color="#cc0000">Укажите, выкупили ли их клиенты</font>' +
        '<br /><br /> <span style="font-size: 18px">После установки статусов всем заказам вы сможете продолжить работу с личным кабинетом.</span> <br />   <br /> ' +
        '<span style="font-size: 16px">(Если клиент купил заказ, нажмите "Выполнен".  <br /> Если клиент купил что-то другое, или отказался от покупки нажмите "Отмена". )</span>');

})

/****************************************************************************************************************************************************************/

function showNotFoundForm(orderId) {
    //alert(1);
    $.fancybox({
        'width': '40%',
        'height': '40%',
        'autoScale': true,
        'transitionIn': 'fade',
        'transitionOut': 'fade',
        'type': 'ajax',
        'href': 'notFoundForm.php?order=' + orderId,
        'closeBtn': true,
        //'closeClick'  : true,
        helpers: {
            //overlay : {closeClick: true} ,
            opacity: 0.8, // or the opacity you want
            css: {'background-color': '#ff0000'} // or your preferred hex color value
        }
    });
}

function lostOrder(orderId, lost) {
    //alert(orderId);
    if (lost) {
        var lostText = $("#caseLost" + orderId).val();
        if (lostText.length < 3) {
            alert("Напишите пожалуйста причину, по которой товар пропал");
            return;
        }
        updateOrder(orderId, "C","нет в наличии: "+ lostText, 'CReqNotAvailable');
    } else {
        updateOrder(orderId, "W", "товар найден в магазине", '');
    }
}

function showOrderList(title,list){
    $('.modal-header h3').html(title);
    $.get("ajax_table.php",{orders:list},function(data){
        $('.modal-body').html(data);
        $('#myModal').modal();
        //alert(data);
    })
}





