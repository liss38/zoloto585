<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();?>
<?require_once($_SERVER["DOCUMENT_ROOT"]."/ordershops/classes/COrderShops.php");?>
<!doctype html>
<html>
<head>
	<title>Заказы по магазинам</title>
	<?
	$assets = \Bitrix\Main\Page\Asset::getInstance();

	$assets->addCss(SITE_TEMPLATE_PATH . "/css/bootstrap.min.css");
	$assets->addCss(SITE_TEMPLATE_PATH . "/css/jquery.fancybox.css");
	$assets->addCss(SITE_TEMPLATE_PATH . "/css/main.css");

	$assets->addJs(SITE_TEMPLATE_PATH . "/js/jquery-1.10.2.min.js");
	$assets->addJs(SITE_TEMPLATE_PATH . "/js/jquery.fancybox.js");
	$assets->addJs(SITE_TEMPLATE_PATH . "/js/main.js");
	$assets->addJs(SITE_TEMPLATE_PATH . "/js/bootstrap.min.js");
	?>

	<?$APPLICATION->ShowHead();?>
</head>
<body>
<div id="wrap">