        </div>
        <script type='text/javascript'>
            var liveTex = true,
                liveTexID = 121551,
                liveTex_object = true;
            var pagesForInclude = ['/ordershops/'];
            var isDisabled = function(pages) {
                var currentPage = document.location.href;
                var accum = true;
                pages.forEach(function(e) {
                    if (currentPage.indexOf(e) !== -1)
                    { accum = false; }
                });
                return accum;
            };
            var LiveTex = {
                onLiveTexReady: function() {
                    LiveTex.hideLabel();
                    if(isDisabled(pagesForInclude) < 1)
                    { LiveTex.showLabel(); }
                }
            };
            (function()
                { var lt = document.createElement('script'); lt.type = 'text/javascript'; lt.async = true; lt.src = '//cs15.livetex.ru/js/client.js'; var sc = document.getElementsByTagName('script')[0]; if (sc) sc.parentNode.insertBefore(lt, sc); else document.documentElement.firstChild.appendChild(lt); }
            )();
        </script>
    </body>
</html>