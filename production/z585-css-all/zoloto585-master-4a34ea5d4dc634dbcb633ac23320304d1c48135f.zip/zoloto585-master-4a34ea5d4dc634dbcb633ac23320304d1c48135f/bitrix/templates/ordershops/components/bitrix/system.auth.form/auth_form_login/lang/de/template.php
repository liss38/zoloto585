<?
$MESS["AUTH_FORGOT_PASSWORD_2"] = "Passwort vergessen?";
$MESS["AUTH_A_INTERNAL"] = "Interne Anmeldung";
$MESS["AUTH_A_LIVEID"] = "Live ID";
$MESS["AUTH_LIVEID_LOGIN"] = "Log In";
$MESS["AUTH_LOGIN_BUTTON"] = "Anmelden";
$MESS["AUTH_LOGIN"] = "Login";
$MESS["AUTH_LOGOUT_BUTTON"] = "Logout";
$MESS["AUTH_PROFILE"] = "Mein Profil";
$MESS["AUTH_A_OPENID"] = "OpenID";
$MESS["AUTH_OPENID"] = "OpenID";
$MESS["AUTH_PASSWORD"] = "Passwort";
$MESS["AUTH_REGISTER"] = "Registrieren";
$MESS["AUTH_REMEMBER_ME"] = "Passwort merken";
$MESS["AUTH_CAPTCHA_PROMT"] = "CAPTCHA Code";
$MESS["AUTH_REMEMBER_SHORT"] = "Passwort merken";
$MESS["socserv_as_user_form"] = "Login als:";
$MESS["AUTH_SECURE_NOTE"] = "Das Passwort wird verschlüsselt, bevor es versendet wird. So wird das Passwort während der Übertragung nicht offen angezeigt.";
$MESS["AUTH_NONSECURE_NOTE"] = "Das Passwort wird in offener Form versendet. Aktivieren Sie JavaScript  in Ihrem Web-Browser, um das Passwort vor dem Versenden zu verschlüsseln.";
$MESS["auth_form_comp_otp"] = "Einmalpasswort:";
$MESS["auth_form_comp_otp_remember_title"] = "Einmalpasswort auf diesem Computer speichern";
$MESS["auth_form_comp_otp_remember"] = "Passwort speichern";
$MESS["auth_form_comp_auth"] = "Einloggen";
?>