<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>
	<div class="ordershops__auth-help">
		<p>Логин это ваша почта до символа "@" Например (78-01365)</p>
		<p>Пароль соответствует вашему паролю от компьютера</p>
	</div>

<form class="ordershops__auth" name="system_auth_form<?= $arResult["RND"] ?>" method="post" target="_top" action="<?= $arResult["AUTH_URL"] ?>">
    <input type="hidden" name="backurl" value="/ordershops/loginform.php">		
    <input type="hidden" name="AUTH_FORM" value="Y">		
    <input type="hidden" name="TYPE" value="AUTH">		
    
    
		<div class="ordershops__auth-row">
			<input name="USER_LOGIN" id="ordershops-login" type="text" class="ordershops__login" placeholder="Логин" autocomplete="off">
		</div>

		<div class="ordershops__auth-row">
			<input name="USER_PASSWORD" id="ordershops-password" type="password" class="ordershops__pssword" placeholder="Пароль">
		</div>


 
    <?php
    if ($arResult['SHOW_ERRORS'] == 'Y' && $arResult['ERROR']) {
       echo "<div class='ordershops__auth-warning'>Неправильно указаны данные авторизации.</div>";
    }
    ?>
  
    <input type="submit" class="ordershops__button" value="Войти">
</form>