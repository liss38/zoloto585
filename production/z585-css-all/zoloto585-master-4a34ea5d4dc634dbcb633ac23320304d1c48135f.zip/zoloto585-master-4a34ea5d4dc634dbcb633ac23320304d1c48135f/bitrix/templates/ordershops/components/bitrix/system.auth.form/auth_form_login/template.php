<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
?>
<?
global $USER;
if ($USER->IsAuthorized()){
    LocalRedirect('/my-account/profile.php');
}else{
?>
<form class='ordershops__auth' id="form_login_phone" class="login_form" name="system_auth_form<?=$arResult['RND']?>" method="post" target="_top" action="#"  data-ajax-href="/my-account/auth.php">
	<input type="hidden" name="mode" value="login_phone" />
	<?if (strlen($arParams["BACKURL"]) > 0 || strlen($arResult["BACKURL"]) > 0):?>
		<input type="hidden" name="backurl" value="<?=($arParams["BACKURL"] ? $arParams["BACKURL"] : $arResult["BACKURL"])?>" />
	<?endif?>
	<div class="line_inp">
        <div class="inp">
            <span for="">Телефон<sup>*</sup></span>
            <span class="error"></span>
				<input type="text" name="USER_PHONE" id="phone" maxlength="255" required placeholder="">
        </div>
	</div>
	<div class="line_inp">
        <div class="inp">
            <span for="">Пароль<sup>*</sup></span>
            <span class="error"></span>
			<input type="text" name="USER_PASSWORD" maxlength="255">
		</div>
	</div>
	<div class="line_inp links">
        <a href="register.php">Зарегистрироваться</a>
    </div>
	<div class="line_inp">
		<input type="submit" name="Login" value="Войти" class="btn btn_small btn_yellow" />
	</div>
</form>

<form id="form_login_emaile" class="login_form" name="system_auth_form<?=$arResult['RND']?>" method="post" target="_top" action="#"  data-ajax-href="/my-account/auth.php">
	<input type="hidden" name="mode" value="login_email" />
	<?if (strlen($arParams["BACKURL"]) > 0 || strlen($arResult["BACKURL"]) > 0):?>
		<input type="hidden" name="backurl" value="<?=($arParams["BACKURL"] ? $arParams["BACKURL"] : $arResult["BACKURL"])?>" />
	<?endif?>
	<div class="line_inp">
        <div class="inp">
            <span for="">Email<sup>*</sup></span>
            <span class="error"></span>
				<input type="text" name="USER_EMAIL" id="email" maxlength="255" required placeholder="">
        </div>
	</div>
	<div class="line_inp">
        <div class="inp">
            <span for="">Пароль<sup>*</sup></span>
            <span class="error"></span>
			<input type="text" name="USER_PASSWORD" maxlength="255">
		</div>
	</div>
	<div class="line_inp links">
        <a href="register.php">Зарегистрироваться</a>
    </div>
	<div class="line_inp">
		<input type="submit" name="Login" value="Войти" class="btn btn_small btn_yellow" />
	</div>
</form>
<form id="form_login_bk" class="login_form" name="system_auth_form<?=$arResult['RND']?>" method="post" target="_top" action="#"  data-ajax-href="/my-account/auth.php">
	<input type="hidden" name="mode" value="login_bk" />
	<?if (strlen($arParams["BACKURL"]) > 0 || strlen($arResult["BACKURL"]) > 0):?>
		<input type="hidden" name="backurl" value="<?=($arParams["BACKURL"] ? $arParams["BACKURL"] : $arResult["BACKURL"])?>" />
	<?endif?>
	<div class="line_inp">
        <div class="inp">
            <span for="">Номер бонусной карты<sup>*</sup></span>
            <span class="error"></span>
				<input type="text" name="USER_NUM_CARD" id="phone" maxlength="255" required placeholder="">
        </div>
	</div>
	<div class="line_inp">
        <div class="inp">
            <span for="">Пароль<sup>*</sup></span>
            <span class="error"></span>
			<input type="text" name="USER_PASSWORD" maxlength="255">
		</div>
	</div>
	<div class="line_inp links">
        <a href="register.php">Зарегистрироваться</a>
    </div>
	<div class="line_inp">
		<input type="submit" name="Login" value="Войти" class="btn btn_small btn_yellow" />
	</div>
</form>
<?
	}
?>