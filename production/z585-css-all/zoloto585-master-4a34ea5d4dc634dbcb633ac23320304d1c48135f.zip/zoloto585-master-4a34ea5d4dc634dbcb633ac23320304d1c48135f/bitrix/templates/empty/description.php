<?
$arTemplate = array (
  'NAME' => 'пустой шаблон',
  'DESCRIPTION' => '',
  'SORT' => '',
  'TYPE' => '',
);
?>