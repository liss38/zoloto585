<?
$arTemplate = array (
  'NAME' => 'Уведомления, заказы',
  'DESCRIPTION' => 'Уведомления о заказах',
  'SORT' => 1,
  'TYPE' => 'mail',
);
?>