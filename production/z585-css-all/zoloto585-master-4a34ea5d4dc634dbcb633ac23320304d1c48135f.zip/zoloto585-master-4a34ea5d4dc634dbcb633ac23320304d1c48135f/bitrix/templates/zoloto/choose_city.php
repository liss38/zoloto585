<?
$APPLICATION->SetAdditionalCSS(SITE_TEMPLATE_PATH .'/css/top-geo.css?v1');
$APPLICATION->SetAdditionalCSS(SITE_TEMPLATE_PATH .'/css/top-geo_responsive.css');
$APPLICATION->SetAdditionalCSS(SITE_TEMPLATE_PATH .'/css/cities-list.css?v1');

function format_by_count($count, $form1, $form2, $form3)
{
	$count = abs($count) % 100;
	$lcount = $count % 10;
	if ($count >= 11 && $count <= 19) return($form3);
	if ($lcount >= 2 && $lcount <= 4) return($form2);
	if ($lcount == 1) return($form1);
	return $form3;
}

$listCity = Zoloto585Store::getCities();
$cityCount = count($listCity);

$listResult = [];
foreach($listCity as $k => $value) {
	$firstLetter = substr($value, 0, 1);
	$listResult[$firstLetter][] = $value;
}

$dynamicArea = new \Bitrix\Main\Page\FrameStatic("zoloto585_city_select");
$dynamicArea->startDynamicArea();
?>
	<div class="header-top__item  top-geo" id="top-geo-wrap">
		<a id="choose-city" class="top-geo__button"><span><?=(!empty($_COOKIE["city"])) ? $_COOKIE["city"]:'Город не выбран'?></span></a>
		<div class="top-geo-modal">
			<div class="top-geo-modal__inner">
				<div class="top-geo-modal__close">X</div>

				<form class="form  top-geo-form">
					<div class="top-geo-form__header">Выбор города</div>
					<div class="top-geo-form__total">Всего <?=$cityCount?> <?=format_by_count($cityCount,"город","города","городов")?></div>

					<div class="top-geo-form__chosen-city">
						<div class="top-geo-form__chosen-city-inner">
							<div class="top-geo-form__chosen-city-label">Выбранный город:</div>
							<div class="top-geo-form__chosen-city-result"><?=(!empty($_COOKIE["city"])) ? $_COOKIE["city"]:'Город не выбран'?></div>
						</div>
					</div>

					<div class="top-geo-form__search / js-top-geo-form__search">
						<input type="text" placeholder="Поиск города">
					</div>

					<div class="top-geo-form__pop-cities">
						<div class="top-geo-form__pop-cities-inner">
							<a href="#">Санкт-Петербург</a>
							<a href="#">Москва</a>
							<a href="#">Екатеринбург</a>
							<a href="#">Самара</a>
							<a href="#">Тюмень</a>
							<a href="#">Пермь</a>
							<a href="#">Казань</a>
						</div>
					</div>

					<div class="top-geo-form__cities-wrapper">
						<div class="cities-list / js-top-geo-form__cities">
							<? foreach($listResult as $firstLetter => $groupList) { ?>
								<div class="cities-list__heading"><?=$firstLetter?></div>
								<ul class="cities-list__group">
									<? foreach($groupList as $cityName) { ?>
										<li class="cities-list__item">
											<a href="#" class="cities-list__link" data-city><?=$cityName?></a>
										</li>
									<? } ?>
								</ul>
							<? } ?>
						</div>
					</div>
				</form>

			</div>
		</div>
	</div>

	<script>
		//
		// Scrollpane
		//
		$('.js-top-geo-form__cities').jScrollPane({
			autoReinitialise : true,
			verticalDragMinHeight: 50,
		});
		
		function chooseCity() {
			var city = $.cookie('city');
			if(!!!city){
				ymaps.ready(function(){
					city = ymaps.geolocation.city;

					if (!$('.top-geo a.cities-list__link:contains("'+city+'")').length) {
						city = 'Санкт-Петербург';
					}

					$('.top-geo a.cities-list__link:contains("'+city+'")').trigger("click");
				});
			}
		};
		chooseCity();
	</script>

<? $dynamicArea->finishDynamicArea(); ?>