<?
$MESS["IBLOCK_CSC_TAB_COMMENTS"] = "Комментарии";
$MESS["IBLOCK_CSC_TAB_VK"] = "Вконтакте";
$MESS["IBLOCK_CSC_NO_DATA"] = "В настройках компонента не выбран ни один тип комментариев";
$MESS["IBLOCK_CSC_COMMENTS_LOADING"] = "Загрузка комментариев...";
?>