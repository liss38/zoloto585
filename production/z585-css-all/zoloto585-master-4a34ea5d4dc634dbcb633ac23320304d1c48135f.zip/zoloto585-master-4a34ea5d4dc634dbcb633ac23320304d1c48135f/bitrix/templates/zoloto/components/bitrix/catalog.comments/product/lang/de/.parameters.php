<?
$MESS["CP_BCC_TPL_THEME_SITE"] = "Farbschema der Website benutzen (für bitrix.eshop)";
$MESS["CP_BCC_TPL_THEME_BLUE"] = "Blau (standardmäßig)";
$MESS["CP_BCC_TPL_THEME_GREEN"] = "Grün";
$MESS["CP_BCC_TPL_THEME_RED"] = "rot";
$MESS["CP_BCC_TPL_THEME_WOOD"] = "Holz";
$MESS["CP_BCC_TPL_THEME_YELLOW"] = "Gelb";
$MESS["CP_BCC_TPL_THEME_BLACK"] = "dunkel";
$MESS["CP_BCC_TPL_TEMPLATE_THEME"] = "Farbschema";
$MESS["TEMPLATE_THEME_TIP"] = "Bestimmt die Farben der Website-Ansicht. Standardmäßig wird Blau verwendet.";
?>