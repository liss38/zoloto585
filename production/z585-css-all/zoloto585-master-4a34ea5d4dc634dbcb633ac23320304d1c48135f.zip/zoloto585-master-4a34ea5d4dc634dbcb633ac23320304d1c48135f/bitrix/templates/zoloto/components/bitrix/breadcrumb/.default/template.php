<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
if(empty($arResult))
	return "";

$bread = array(array("TITLE" => "Каталог", "LINK" => "/catalog/all/all/"));
array_splice($arResult, 1, 0, $bread);
$num_items = count($arResult);
for($index = 0, $itemSize = $num_items; $index < $itemSize; $index++)
{
	$title = htmlspecialcharsex($arResult[$index]["TITLE"]);
	$pieces_url  = $arResult[$index]["LINK"];
	$pieces_url = explode("/", $pieces_url);
	if($arResult[$index]["LINK"]!='/' && $pieces_url[3]==$pieces_url[2]) $arResult[$index]["LINK"]='/'.$pieces_url[1].'/'.$pieces_url[2].'/';

	if($arResult[$index]["LINK"] <> "" && $index != $itemSize-1)
		$strReturn .= '<a href="'.$arResult[$index]["LINK"].'" title="'.$title.'">'.$title.'</a><span> / </span>';
	else
		$strReturn .= $title;
}
return $strReturn;
?>
