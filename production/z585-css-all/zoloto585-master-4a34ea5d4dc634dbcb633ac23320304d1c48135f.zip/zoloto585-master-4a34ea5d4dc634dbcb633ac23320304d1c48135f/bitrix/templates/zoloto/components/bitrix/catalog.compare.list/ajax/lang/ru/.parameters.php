<?
$MESS["CP_BCCL_TPL_PARAM_TITLE_POSITION_FIXED"] = "Отображать список сравнения поверх страницы";
$MESS["CP_BCCL_TPL_PARAM_TITLE_POSITION"] = "Положение на странице";
$MESS["CP_BCCL_TPL_PARAM_POSITION_TOP_LEFT"] = "вверху слева";
$MESS["CP_BCCL_TPL_PARAM_POSITION_TOP_RIGHT"] = "вверху справа";
$MESS["CP_BCCL_TPL_PARAM_POSITION_BOTTOM_LEFT"] = "внизу слева";
$MESS["CP_BCCL_TPL_PARAM_POSITION_BOTTOM_RIGHT"] = "внизу справа";
?>