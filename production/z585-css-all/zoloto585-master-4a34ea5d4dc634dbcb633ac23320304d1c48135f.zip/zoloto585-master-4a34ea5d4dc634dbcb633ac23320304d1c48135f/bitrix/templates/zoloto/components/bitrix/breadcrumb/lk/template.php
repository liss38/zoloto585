<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
if(empty($arResult))
	return "";



$num_items = count($arResult);
$strReturn .= '<div class="ucab-breadcrumbs">';
for($index = 0, $itemSize = $num_items; $index < $itemSize; $index++)
{
	$title = htmlspecialcharsex($arResult[$index]["TITLE"]);
	$pieces_url  = $arResult[$index]["LINK"];
	$pieces_url = explode("/", $pieces_url);
	if($arResult[$index]["LINK"]!='/' && $pieces_url[3]==$pieces_url[2]) $arResult[$index]["LINK"]='/'.$pieces_url[1].'/'.$pieces_url[2].'/';

	if($arResult[$index]["LINK"] <> "" && $index != $itemSize-1)
		$strReturn .= '<a class="ucab-breadcrumbs__item" href="'.$arResult[$index]["LINK"].'" title="'.$title.'">'.$title.'</a> ';
	else
		$strReturn .= '<a class="ucab-breadcrumbs__item ucab-breadcrumbs__item--active" href="'.$arResult[$index]["LINK"].'" title="'.$title.'">'.$title.'</a> ';

}
return $strReturn."</div>";
?>

