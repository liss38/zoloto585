<?
$MESS["IBLOCK_CSC_TAB_COMMENTS"] = "Коментарі";
$MESS["IBLOCK_CSC_TAB_VK"] = "Вконтакте";
$MESS["IBLOCK_CSC_NO_DATA"] = "У налаштуваннях компоненту не обраний жоден тип коментарів";
$MESS["IBLOCK_CSC_COMMENTS_LOADING"] = "Завантаження коментарів...";
?>