<?
$MESS["CATALOG_COMPARE_ELEMENTS"] = "Compare item list";
$MESS["CATALOG_DELETE"] = "Remove";
$MESS["CP_BCCL_TPL_MESS_COMPARE_COUNT"] = "Items in comparison chart:";
$MESS["CP_BCCL_TPL_MESS_COMPARE_PAGE"] = "Compare";
?>