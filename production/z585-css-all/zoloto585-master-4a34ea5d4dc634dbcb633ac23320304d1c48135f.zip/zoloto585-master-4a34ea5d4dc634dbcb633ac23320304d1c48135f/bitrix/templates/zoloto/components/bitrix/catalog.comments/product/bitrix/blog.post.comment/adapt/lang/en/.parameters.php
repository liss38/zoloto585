<?
$MESS ['B_SEO_USER'] = "Prevent search spiders and bots from following link to user profile";
?>