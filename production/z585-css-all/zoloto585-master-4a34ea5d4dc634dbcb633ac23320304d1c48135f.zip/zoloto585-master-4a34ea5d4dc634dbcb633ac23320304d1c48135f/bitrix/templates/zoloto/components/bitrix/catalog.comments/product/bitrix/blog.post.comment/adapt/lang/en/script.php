<?
$MESS ['BPC_TEXT_ENTER_URL'] = "Enter the full address (URL)";
$MESS ['BPC_TEXT_ENTER_URL_NAME'] = "Enter the text to be shown as a hyperlink";
$MESS ['BPC_TEXT_ENTER_IMAGE'] = "Enter the full image address (URL)";
$MESS ['BPC_LIST_PROMPT'] = "Enter the list item. Click 'Cancel' or type space to complete the list";
$MESS ['BPC_ERROR_NO_URL'] = "Please enter the address (URL)";
$MESS ['BPC_ERROR_NO_TITLE'] = "Please enter the title";
?>