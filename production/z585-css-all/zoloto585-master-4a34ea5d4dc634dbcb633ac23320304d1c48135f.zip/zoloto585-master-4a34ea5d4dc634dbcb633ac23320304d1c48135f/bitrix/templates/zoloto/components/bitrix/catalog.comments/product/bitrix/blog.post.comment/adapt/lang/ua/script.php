<?
$MESS["BPC_TEXT_ENTER_URL"] = "Введіть повну адресу (URL)";
$MESS["BPC_TEXT_ENTER_URL_NAME"] = "Введіть назву сайту";
$MESS["BPC_TEXT_ENTER_IMAGE"] = "Введіть повну адресу (URL) зображення";
$MESS["BPC_LIST_PROMPT"] = "Введіть пункт списку. Натисніть Скасувати або залиште пробіл для завершення списку";
$MESS["BPC_ERROR_NO_URL"] = "Ви повинні ввести адресу (URL)";
$MESS["BPC_ERROR_NO_TITLE"] = "Ви повинні ввести назву";
?>