<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var CBitrixComponentTemplate $this */
/** @var array $arParams */
/** @var array $arResult */
/** @global CDatabase $DB */
/** @global CMain $APPLICATION */

$frame = $this->createFrame()->begin("");

$templateData = array(
	'TEMPLATE_THEME' => $this->GetFolder().'/themes/'.$arParams['TEMPLATE_THEME'].'/style.css',
	'TEMPLATE_CLASS' => 'bx_'.$arParams['TEMPLATE_THEME']
);

$injectId = $arParams['UNIQ_COMPONENT_ID'];

if (isset($arResult['REQUEST_ITEMS']))
{
	// code to receive recommendations from the cloud
	CJSCore::Init(array('ajax'));

	// component parameters
	$signer = new \Bitrix\Main\Security\Sign\Signer;
	$signedParameters = $signer->sign(
		base64_encode(serialize($arResult['_ORIGINAL_PARAMS'])),
		'bx.bd.products.recommendation'
	);
	$signedTemplate = $signer->sign($arResult['RCM_TEMPLATE'], 'bx.bd.products.recommendation');

	?>

	<span id="<?=$injectId?>"></span>

	<script type="text/javascript">
		BX.ready(function(){
			bx_rcm_get_from_cloud(
				'<?=CUtil::JSEscape($injectId)?>',
				<?=CUtil::PhpToJSObject($arResult['RCM_PARAMS'])?>,
				{
					'parameters':'<?=CUtil::JSEscape($signedParameters)?>',
					'template': '<?=CUtil::JSEscape($signedTemplate)?>',
					'site_id': '<?=CUtil::JSEscape(SITE_ID)?>',
					'rcm': 'yes'
				}
			);
		});
	</script>
	<?
	$frame->end();
	return;

	// \ end of the code to receive recommendations from the cloud
}


// regular template then
// if customized template, for better js performance don't forget to frame content with <span id="{$injectId}_items">...</span> 

if (!empty($arResult['ITEMS']))
{
	?>

	<span id="<?=$injectId?>_items">
	
	<div class="bigdata-recommendations">
	<div class="wrp clearfix">
		<h2>Персональные рекомендации</h2>
	</div>

	<?
	$productIDs = [];
	foreach ($arResult['ITEMS'] as $item) {
		$productIDs[] = $item['ID'];
	}	

	global $arrFilterPersonalRecommended;
	$arrFilterPersonalRecommended = array(
		'ID' => $productIDs
	);

	$APPLICATION->IncludeComponent('bitrix:catalog.section', '', array (
	  'ZOLOTO585_HIDE_H1' => 'Y',
	  'GTM_TYPE' => Zoloto585Ecommerce::TYPE_PERSONAL_RECOMMENDATIONS,
	  'IBLOCK_TYPE' => 'catalog',
	  'IBLOCK_ID' => '4',
	  'ELEMENT_SORT_FIELD' => 'SORT',
	  'ELEMENT_SORT_ORDER' => 'asc',
	  'ELEMENT_SORT_FIELD2' => 'SORT',
	  'ELEMENT_SORT_ORDER2' => 'desc',
	  'PROPERTY_CODE' => 
	  array (
	  	'SPECIAL_PRICE'
	  ),
	  'META_KEYWORDS' => '-',
	  'META_DESCRIPTION' => '-',
	  'BROWSER_TITLE' => '-',
	  'INCLUDE_SUBSECTIONS' => 'Y',
	  'BASKET_URL' => '/personal/cart/',
	  'ACTION_VARIABLE' => 'action',
	  'PRODUCT_ID_VARIABLE' => 'id',
	  'SECTION_ID_VARIABLE' => 'SECTION_ID',
	  'PRODUCT_QUANTITY_VARIABLE' => '',
	  'PRODUCT_PROPS_VARIABLE' => 'prop',
	  'FILTER_NAME' => 'arrFilterPersonalRecommended',
	  'CACHE_TYPE' => 'A',
	  'CACHE_TIME' => '86400',
	  'CACHE_FILTER' => 'Y',
	  'CACHE_GROUPS' => 'N',
	  'SET_TITLE' => 'N',
	  'SET_STATUS_404' => 'Y',
	  'DISPLAY_COMPARE' => 'N',
	  'PAGE_ELEMENT_COUNT' => $arParams['PAGE_ELEMENT_COUNT'],
	  'LINE_ELEMENT_COUNT' => '4',
	  'PRICE_CODE' => 
	  array (
	    0 => 'base_price',
	    1 => 'rozn_price',
	    2 => 'stock_price',
	    3 => 'minimal_price',
		4 => 'Internet_price'
	  ),
	  'USE_PRICE_COUNT' => 'N',
	  'SHOW_PRICE_COUNT' => '1',
	  'SHOW_ALL_WO_SECTION' => 'Y',
	  'PRICE_VAT_INCLUDE' => 'Y',
	  'USE_PRODUCT_QUANTITY' => 'Y',
	  'ADD_PROPERTIES_TO_BASKET' => 'Y',
	  'PARTIAL_PRODUCT_PROPERTIES' => 'N',
	  'PRODUCT_PROPERTIES' => array (),
	  'DISPLAY_TOP_PAGER' => 'N',
	  'DISPLAY_BOTTOM_PAGER' => 'N',
	  'PAGER_TITLE' => 'Товары',
	  'PAGER_SHOW_ALWAYS' => 'N',
	  'PAGER_TEMPLATE' => '.default',
	  'PAGER_DESC_NUMBERING' => 'N',
	  'PAGER_DESC_NUMBERING_CACHE_TIME' => '36000',
	  'PAGER_SHOW_ALL' => 'N',
	  'OFFERS_CART_PROPERTIES' => array(),
	  'OFFERS_FIELD_CODE' => array('ID'),
	  'OFFERS_PROPERTY_CODE' => array ('SPECIAL_PRICE'),
	  'OFFERS_SORT_FIELD' => 'SORT',
	  'OFFERS_SORT_ORDER' => 'asc',
	  'OFFERS_SORT_FIELD2' => 'ID',
	  'OFFERS_SORT_ORDER2' => 'asc',
	  'OFFERS_LIMIT' => '100',
	  'SECTION_URL' => '/catalog/#SECTION_CODE_PATH#/',
	  'DETAIL_URL' => '/catalog/#SECTION_CODE_PATH#/#ELEMENT_ID#/',
	  'CONVERT_CURRENCY' => 'Y',
	  'CURRENCY_ID' => 'RUB',
	  'HIDE_NOT_AVAILABLE' => 'N',
	  'LABEL_PROP' => '-',
	  'ADD_PICT_PROP' => '-',
	  'PRODUCT_DISPLAY_MODE' => 'N',
	  'OFFER_ADD_PICT_PROP' => '-',
	  'OFFER_TREE_PROPS' => 
	  array (
	    0 => 'SIZE_RING_PEND',
	    1 => 'SIZE_CB',
	  ),
	  'PRODUCT_SUBSCRIPTION' => NULL,
	  'SHOW_DISCOUNT_PERCENT' => 'N',
	  'SHOW_OLD_PRICE' => 'N',
	  'MESS_BTN_BUY' => 'Купить',
	  'MESS_BTN_ADD_TO_BASKET' => 'В корзину',
	  'MESS_BTN_SUBSCRIBE' => NULL,
	  'MESS_BTN_DETAIL' => 'Подробнее',
	  'MESS_NOT_AVAILABLE' => 'Нет в наличии',
	  'TEMPLATE_THEME' => 'blue',
	  'ADD_SECTIONS_CHAIN' => 'N',
	  'ADD_TO_BASKET_ACTION' => 'ADD',
	  'SHOW_CLOSE_POPUP' => 'N',
	  'COMPARE_PATH' => '/catalog/',
	),
	$this->_component
	);
	?>

	</div>

	</span>
<?
}

$frame->end();