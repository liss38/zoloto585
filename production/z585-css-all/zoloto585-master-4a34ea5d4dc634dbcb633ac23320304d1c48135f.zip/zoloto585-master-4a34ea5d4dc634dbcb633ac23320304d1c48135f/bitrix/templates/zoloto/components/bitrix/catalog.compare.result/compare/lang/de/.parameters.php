<?
$MESS["CP_BCC_TPL_THEME_SITE"] = "Website-Farbschema benutzen (für bitrix.eshop)";
$MESS["CP_BCC_TPL_THEME_BLUE"] = "blau (Standardschema)";
$MESS["CP_BCC_TPL_THEME_GREEN"] = "grün";
$MESS["CP_BCC_TPL_THEME_RED"] = "rot";
$MESS["CP_BCC_TPL_THEME_WOOD"] = "holz";
$MESS["CP_BCC_TPL_THEME_YELLOW"] = "gelb";
$MESS["CP_BCC_TPL_THEME_BLACK"] = "dunkel";
$MESS["CP_BCC_TPL_TEMPLATE_THEME"] = "Farbschema";
?>