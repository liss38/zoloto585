<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
$frame = $this->createFrame()->begin("");?>
<div id="slider" class="slider-carousel">	
<?foreach($arResult["BANNERS"] as $k => $banner):?>
			<div class="item <?if($k==0) echo 'active';?>">
			<?=$banner?>
		</div>
<?endforeach;?>		
</div>
<?
$frame->end();
?>