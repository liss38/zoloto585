<?
$MESS["SALE_ACCOUNT_TITLE"] = "My Account";
$MESS["SALE_ACCOUNT"] = "Account status";
?>