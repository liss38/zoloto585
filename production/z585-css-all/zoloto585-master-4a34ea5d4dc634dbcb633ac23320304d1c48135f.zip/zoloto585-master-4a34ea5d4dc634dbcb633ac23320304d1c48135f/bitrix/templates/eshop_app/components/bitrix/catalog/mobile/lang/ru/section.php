<?
$MESS["MB_PULLDOWN_PULL"] = "Потяните, чтобы обновить";
$MESS["MB_PULLDOWN_DOWN"] = "Отпустите, чтобы обновить";
$MESS["MB_PULLDOWN_LOADING"] = "Обновление данных...";
$MESS["MB_ALERT_TITLE"] = "Ошибка";
$MESS["MD_BARCODE_EMPTY"] = "К сожалению, данный товар не найден";
?>