<?
$MESS ['SADC_DOCALC'] = 'Рассчитать стоимость';
$MESS ['SALE_SADC_RESULT'] = 'Оценочная стоимость';
$MESS ['SALE_SADC_TRANSIT'] = 'Срок доставки (дней)';
?>