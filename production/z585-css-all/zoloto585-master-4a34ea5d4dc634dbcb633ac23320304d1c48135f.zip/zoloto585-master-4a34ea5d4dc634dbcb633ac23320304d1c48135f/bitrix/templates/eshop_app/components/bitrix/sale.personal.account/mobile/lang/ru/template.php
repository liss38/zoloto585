<?
$MESS["SALE_ACCOUNT_TITLE"] = "Мой счет";
$MESS["SALE_ACCOUNT"] = "Состояние счета";
?>