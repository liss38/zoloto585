<?
$MESS["M_TEMPLATE_NAME"] = "E-Shop Mobile App";
$MESS["M_TEMPLATE_DESC"] = "E-Shop mobile app template";
?>