<?
$MESS["MB_PULLDOWN_PULL"] = "Потяните, чтобы обновить";
$MESS["MB_PULLDOWN_DOWN"] = "Отпустите, чтобы обновить";
$MESS["MB_PULLDOWN_LOADING"] = "Обновление данных...";
$MESS["MB_CART"] = "Корзина";
?>