<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load/yandex_util.php");
?>