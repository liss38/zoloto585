<?
//<title>Froogle</title>
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load/froogle_run.php");
?>