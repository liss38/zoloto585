<?
//<title>Export CSV</title>
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load/csv_run.php");
?>