<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/vsfr.merchant/load/yandex_detail.php");
?>