<?
//<title>CommerceML MySql Fast - BETA VERS</title>
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load_import/commerceml_g_run.php");
?>