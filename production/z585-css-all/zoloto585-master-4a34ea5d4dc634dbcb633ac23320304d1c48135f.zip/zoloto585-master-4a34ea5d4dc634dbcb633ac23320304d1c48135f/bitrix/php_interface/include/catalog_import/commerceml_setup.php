<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/catalog/load_import/commerceml_setup.php");
?>