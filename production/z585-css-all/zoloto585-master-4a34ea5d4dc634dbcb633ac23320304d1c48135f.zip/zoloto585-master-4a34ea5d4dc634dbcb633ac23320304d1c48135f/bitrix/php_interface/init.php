<?php

/*
 * 404page.php- 404 на ненайденные элементы каталога
 * senSms.php- функция для отправки sms
 * clearCache.php- Сброс кэша для ТП
 */
include dirname(__FILE__)."/functions/global/404page.php";
include dirname(__FILE__)."/functions/global/sendSms.php";
include dirname(__FILE__)."/functions/global/clearCache.php";

/** личный кабинет - обработчики событий */
include dirname(__FILE__)."/functions/cabinet/cabinet_handler.php";

/*
 * Функции ordershops, интерфейса бронирования:
 * helper_ordershops.php- вспомогательные функции
 *
 * booking_event_function.php-функции оповещения о создании закзов,
 * измнения статусов заказов,
 * вызывается при удачном бронировании в карточке товара,
 * при измнении статуса заказа,
 * при создании заказа в админке
 *
 * OnSaleStatusOrder-обработчик события создания/измнения статуса заказа
 * onlyStatusChange- обработчик, содержащий функцию OnSaleStatusOrder с параметром "толкьо измненить статус"
 */
include dirname(__FILE__)."/functions/booking/helper_ordershops.php";
include dirname(__FILE__)."/functions/booking/booking_event_function.php";


/*
 * Функции использующиеся в res_modif карточки товара
 * Получение типа торговых предложений - если кольца, подвесы, конго- используем для отличия по размерам свойство SIZE_RING_PEND,
 * если цепи, браслеты - используем свойство SIZE_CB
 * getSizePropsOffers-получение размеров, если они есть
 * cmp_by_price- функция сортировки по размеру и цене
 *
 */
include dirname(__FILE__)."/functions/public/element_card.php";


/* добавление классов
 * Отправка напоминающего СМС в 11 часов клиенту
 * CsvImporter -класс импорта из csv
 * UserMainImportEngine- класс по импорту из SAP
 * MyIblockChange- класс записи измнений в файл для urlrewrite_my.php из инфоблока "Посадочные url каталога"
*/
define("LOG_FILENAME", $_SERVER["DOCUMENT_ROOT"]."/import/catalog_stores_prices/logs/log.txt");
CModule::AddAutoloadClasses(
    '',
    array(
        'GarbageStorage' => '/bitrix/php_interface/classes/catalog_stores_prices/class/GarbageStorage.php',
        'CsvImporter' => '/bitrix/php_interface/classes/catalog_stores_prices/class/CsvImporter.php',
        'UserMainImportEngine' => '/bitrix/php_interface/classes/catalog_stores_prices/class/UserMainImportEngine.php',
        'MyIblockChange' =>'/bitrix/php_interface/classes/MyIblockChange.php',
        'GetDoneOrders' =>'/bitrix/php_interface/classes/GetDoneOrders.php',
        'Zoloto585Logger' =>'/bitrix/php_interface/classes/Zoloto585Logger.php',
        'Zoloto_Breadcrumbs' =>'/bitrix/php_interface/classes/Zoloto_Breadcrumbs.php',
        'Zoloto585Ecommerce' =>'/bitrix/php_interface/classes/Zoloto585Ecommerce.php',
        'Zoloto585ExceptionMailer' =>'/bitrix/php_interface/classes/Zoloto585ExceptionMailer.php',
        'Zoloto585Config' => '/bitrix/php_interface/classes/Zoloto585Config.php',
        'Zoloto585Store' =>'/bitrix/php_interface/classes/Zoloto585Store.php',
        'ShopSchedule' =>'/bitrix/php_interface/classes/ShopSchedule.php',
        'smsCron' =>'/bitrix/php_interface/classes/SmsCron.php',
        'favorites' =>'/bitrix/php_interface/classes/Favorites.php',
        'OrdersSend' =>'/bitrix/php_interface/classes/OrdersSend.php',
        'BoxCom' =>'/bitrix/php_interface/classes/BoxCom.php',
        'ExpertSender' =>'/bitrix/php_interface/classes/ExpertSender.php',
        'Zoloto585Redis' =>'/bitrix/php_interface/classes/Zoloto585Redis.php',
        'Zoloto585Kafka'=> '/bitrix/php_interface/classes/Zoloto585Kafka.php'
    )
);

/** Модуль идентификации пользователей */
if (\Bitrix\Main\Loader::includeModule('zoloto585.user_identity')) {
	CZoloto585UserIdentity::identifyByLink();
}

/* вызов методов функций для АГЕНТОВ Битрикс
 * updateOffersPrices-обновление цен
 * importStockProductsDELTA- прогрузка остатков
 * importStoreWarehouses- импорт складов из сап
 * deactivateCatalogItems- деактивация карточек с нулевыми ценами
 * sendSmsCron -напоминания о забытых заказах клиентам
 * GetDoneOrders- обновление статусов заказов на Выполнен по данным из DWH
*/

function updateOffersPrices(){
	$trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
	file_put_contents($_SERVER['DOCUMENT_ROOT'] . '/uo_log.txt', print_r($trace, true), FILE_APPEND);
	Zoloto585Logger::logMethodStart();
    $import = new UserMainImportEngine(5);
    $import->updateOffersPrice(5000);
    Zoloto585Logger::logMethodFinish();
    return "updateOffersPrices();";
}

function importStockProductsDELTA(){
    Zoloto585Logger::logMethodStart();
    $import = new UserMainImportEngine(5);
    $import->importStockProducts("DELTA",10000);
    Zoloto585Logger::logMethodFinish();
    return "importStockProductsDELTA();";
}

function importStockProductsALL(){
    Zoloto585Logger::logMethodStart();
    $import = new UserMainImportEngine(5);
    $import->importStockProducts("ALL",2500);
    $now  = new DateTime;
    $texttoadmin="Полная прогрузка остатков на сайте завершена $now->format('d-m-Y H:i:s')";
    sendSms("+79045115566",$texttoadmin);
    Zoloto585Logger::logMethodFinish();
    return "importStockProductsALL();";
}
function importStoreWarehouses(){
    Zoloto585Logger::logMethodStart();
    $import = new UserMainImportEngine(5);
    $import->importStoreWarehouses();
    Zoloto585Logger::logMethodFinish();
    return "importStoreWarehouses();";
}
function deactivateCatalogItems(){
    Zoloto585Logger::logMethodStart();
    $import = new UserMainImportEngine(5);
    $import->deactivateCatalogItems(10000);
    Zoloto585Logger::logMethodFinish();
    return "deactivateCatalogItems();";
}
function sendSmsCron(){
    $s = new smsCron();
    $s->sendOrderList();
    return "sendSmsCron();";
}
function OrdersSend(){
	$s = new OrdersSend();
	$s -> send();
	return "OrdersSend();";
}
/**
 * Обновление статусов заказов на Выполнен по данным из DWH
 * Запускается раз в час
 */
function GetDoneOrdersByDay(){
    $date = new DateTime();
    $ms = new GetDoneOrders();
    $ms->setStatusByDate($date);
    /**
     * Запускается раз в час
     * Поэтому возможна ситуация, когда последний раз запустилось в 23:10 и следующий раз запустится в 00:10
     * И заказы с 23:10 до 00:00 не будут обработаны
     */
    $hourNow = (int)$date->format('H');
    if ($hourNow < 1) {
    	$date->modify('-1 day');
        $ms->setStatusByDate($date);
    }
    $ms->makeOrderDate();
    return "GetDoneOrdersByDay();";
}

function LogToMail(){
    Zoloto585Logger::sendFunctionCallLogToEmail();
    return "LogToMail();";
}


/* обработчики событий
 * OnAfterIBlockElementAdd,OnAfterIBlockElementUpdate - обработчики событий для синхронизации файла psevdo_page.php и инфоблока "Посадочные url каталога" (ID 30)
 * OnSaleStatusOrder- обработчик событий измненяи статусов заказов
 * OnBeforeStoreProductAdd,OnStoreProductAdd,OnBeforeStoreProductUpdate,OnBeforeStoreProductDelete,OnStoreProductUpdate,OnCatalogStoreUpdate - Обработчик изменения остатков Тп
 */

AddEventHandler('sale', 'OnSaleStatusOrder', 'saleStatusChange');

AddEventHandler ( "iblock", "OnAfterIBlockElementAdd", Array (
    "MyIblockChange",
    "OnIblockChangeHandler"
) );
AddEventHandler ( "iblock", "OnAfterIBlockElementUpdate", Array (
    "MyIblockChange",
    "OnIblockChangeHandler"
) );


AddEventHandler ( "catalog", "OnBeforeStoreProductAdd", "OnBeforeStoreProductAdd");
AddEventHandler ( "catalog", "OnStoreProductAdd", "OnStoreProductUpdate");
AddEventHandler ( "catalog", "OnBeforeStoreProductUpdate", "OnStoreProductUpdate");
AddEventHandler ( "catalog", "OnBeforeStoreProductDelete", "OnStoreProductUpdate");
AddEventHandler ( "catalog", "OnStoreProductUpdate", "OnStoreProductUpdate");
AddEventHandler ( "catalog", "OnCatalogStoreUpdate", "OnCatalogStoreUpdate");



/*Личный кабинет*/
AddEventHandler("main", "OnBeforeUserLogin","OnBeforeUserLoginHandler");
AddEventHandler("main", "OnBeforeUserUpdate", "checkOldPassword");
?>
