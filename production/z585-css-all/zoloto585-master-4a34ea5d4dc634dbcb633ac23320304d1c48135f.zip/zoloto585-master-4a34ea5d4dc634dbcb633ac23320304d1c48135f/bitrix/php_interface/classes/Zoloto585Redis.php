<?

/**
 * Class Zoloto585Redis
 * Создает объект Redis и возвращает его.
 * Предотврощает повторное соединение с Redis
 */
class Zoloto585Redis
{
	protected static $REDIS_HOST = '10.15.200.2';
	protected static $REDIS_PASSWORD = 'Qwerty123$';

	protected static $redis;

	private function __construct() {
	}

	public static function connect() {
		if (self::$redis === null) {
			$redis = new Redis();
			try
			{
				if (!$redis->connect(self::$REDIS_HOST)) throw new Exception("Redis. Сервер не найден");
				if (!$redis->auth(self::$REDIS_PASSWORD)) throw new Exception("Redis. Не удалось авторизоваться.");
				self::$redis = $redis;
			}
			catch (Exception $e)
			{
				Zoloto585Logger::logException($e);
				self::$redis = false;
			}
		}

		return self::$redis;
	}
}