<?
/**
 * Добавляет хлебные крошки для посадочных урл каталога
 * т.е. таких страниц, которых реально не существует в каталоге
 * Эти страницы формируются в /bitrix/my_urlrewrite.php
 */
class Zoloto_Breadcrumbs
{
	public static function addBreadcrumbs()
	{
		global $APPLICATION;

		$breadcrumbs = self::getBreadcrumbs();
				
		if (!empty($breadcrumbs)) {			
			foreach ($breadcrumbs as $bItem) {
				$APPLICATION->AddChainItem($bItem['Title'], $bItem['Link']);
			}		
		}		
	}

	private static function getBreadcrumbs()
	{		
		$arBreadcrumbs = [];

		$pseudoUrl = $_SERVER['REDIRECT_URL'];
		$realUrl = $_SERVER['REQUEST_URI'];
		
		//Это не страница, сформированная с помощью фильтров
		if ($pseudoUrl == $realUrl) {
			return false;
		}
		
		$arPseudoPages = include($_SERVER['DOCUMENT_ROOT'] . '/include/psevdo_page.php');
		if (!is_array($arPseudoPages) || empty($arPseudoPages)) {
			return false;
		}

		$pseudoUrlParts = explode('/', $pseudoUrl);
		$realUrlParts = explode('/', $realUrl);
		$diff = array_diff($pseudoUrlParts, $realUrlParts);

		$urlToSearch = $realUrl;		
		foreach ($diff as $diffPart) {
			$urlToSearch .= $diffPart . '/';
			if (array_key_exists($urlToSearch, $arPseudoPages)) {
				$pseudoPageInfo = $arPseudoPages[$urlToSearch];
				$arBreadcrumbs[] = array('Title' => $pseudoPageInfo['H1'], 'Link' => $pseudoPageInfo['URL_PSEVDO']);				
			} else {
				$arSect = self::getSectionByCode($diffPart);
				
				if ($arSect) {					
					$arBreadcrumbs[] = array('Title' => $arSect['NAME'], 'Link' => $arSect['SECTION_PAGE_URL']);
				}
			}
		}

		return $arBreadcrumbs;	
	}

	private static function getSectionByCode($code)
	{
		if (empty($code)) {
			return false;
		}

		$allSections = self::getAllSections();

		if (isset($allSections[$code])) {
			return $allSections[$code];
		}

		return false;
	}	

	private static function getAllSections()
	{
		$сache = Bitrix\Main\Data\Cache::createInstance(); 
		
		if ($сache->initCache(86400, 'AllSections', '/zoloto585/iblock/section')) { 

			$result = $сache->getVars(); 
			$allSections = $result['AllSections'];

		} else if ($сache->startDataCache()) { 		
			
			\Bitrix\Main\Loader::includeModule('iblock');

			$allSections = [];

			$dbSect = \CIBlockSection::GetList(
				array(),
				array('IBLOCK_ID' => 4),
				false,					
				array('ID', 'IBLOCK_ID', 'NAME', 'CODE', 'SECTION_PAGE_URL')
			);
			
			while ($arSect = $dbSect->GetNext()) {
				$allSections[$arSect['CODE']] = array(
					'ID' => $arSect['ID'],
					'NAME' => $arSect['NAME'],
					'SECTION_PAGE_URL' => $arSect['SECTION_PAGE_URL']
				);
			}

			$сache->endDataCache(array('AllSections' => $allSections)); 
		} 

		return $allSections;
	}
}
?>