<?
use Bitrix\Main\Diag\FileExceptionHandlerLog;
use Bitrix\Main\Diag\ExceptionHandlerFormatter;
use Bitrix\Main\Config\Configuration;

class Zoloto585Logger extends FileExceptionHandlerLog
{	
	const TYPE_ERROR = 'error';
	const TYPE_INFO  = 'info';

	const METHOD_TYPE_START = 'start';
	const METHOD_TYPE_FINISH = '_end_';

	/**
	 * Лог файл фиксирующий вызовы методов
	 * Необходим, чтобы убедится, что метод отработал до конца
	 */
	const FUNCTION_LOG_FILE = '/upload/function-call.log';

	private static $instance = null;

	public static function getInstance()
	{
		if (self::$instance == null) {
			self::$instance = new self;
		}
		return self::$instance;
	}

	/**
	 * Запись в лог информации о том, что начал выполнятся метод	
	 */
	public function logMethodStart()
	{
		self::logMethod(self::METHOD_TYPE_START);
	}

	/**
	 * Запись в лог информации о том, что метод выполнился	
	 */
	public function logMethodFinish()
	{
		self::logMethod(self::METHOD_TYPE_FINISH);	
	}

	/**
	 * Запись в лог информации о том, что метод начал выполнятся или выполнился
	 * Информация о том, какой метод вызыван берется из debug_backtrace
	 * @param string $type тип события (запущен/завершился)
	 * @return boolean
	 */
	private function logMethod($type)
	{
		$trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS);
		$date = date('d.m.Y H:i:s');
		
		//запишем относительный путь, чтобы лог не выглядел громоздко		
		$file = str_replace($_SERVER['DOCUMENT_ROOT'], '', $trace[1]['file']);
		$text = "{$trace[2]['function']} [{$type}] {$date} in file {$file}";
		file_put_contents($_SERVER['DOCUMENT_ROOT'] . self::FUNCTION_LOG_FILE, $text . PHP_EOL, FILE_APPEND);
	}
	
	public static function logError($message, $sendToEmail = true)
	{		
		self::log($message, self::TYPE_ERROR, $sendToEmail);
	}

	public static function logInfo($message, $sendToEmail = true)
	{
		self::log($message, self::TYPE_INFO, $sendToEmail);
	}

	/**
	 * Запись в лог и отправка на потчу информации об исключении
	 * @param  string  $exception   Исключение
	 * @param  boolean $sendToEmail Отправить информацию об ошибке на email администратора
	 * @return boolean
	 */
	public static function logException($exception, $sendToEmail = true)
	{		
		$text = ExceptionHandlerFormatter::format($exception);
		
		if ($sendToEmail) {			
			self::sendLogToEmail($text);
		}

		self::myWriteToLog($text);
	}

	/**
	 * Запись в лог и отправка на потчу информации
	 * @param  string  $message Информация для лога
	 * @param  boolean $sendToEmail Отправить информацию об ошибке на email администратора
	 * @return boolean
	 */
	private function log($message, $type, $sendToEmail)
	{
		$trace = debug_backtrace();			
		$srcFile = $trace[1]['file'];		
				
		$text = "[{$type}] #SEP# File: {$srcFile} #SEP# Message: {$message}";
		
		if ($sendToEmail) {
			$textForEmail = str_replace('#SEP#', '<br>', $text);
			self::sendLogToEmail($textForEmail);
		}

		$text = str_replace('#SEP#', "\r\n", $text);

		self::myWriteToLog($text);
	}

	/**
	 * Записать сообщение об ошибке в лог. Используется системный механизм записи.
	 * @param  string $text
	 * @return boolean
	 */
	public function myWriteToLog($text)
	{	
		$exceptionHandling = Configuration::getValue('exception_handling');
		$options = $exceptionHandling['log'];

		$logger = self::getInstance();

		$logger->initialize(
			isset($options["settings"]) && is_array($options["settings"]) ? $options["settings"] : array()
		);		

		$logger->writeToLog(date("Y-m-d H:i:s") . "\n"  . $text."\n");		
	}

	/**
	 * Отправить сообщение об ошибке на email согласно почтовому шаблону ZOLOTO_SITE_LOG
	 * @param  string $text
	 * @return boolean
	 */
	public function sendLogToEmail($text)
	{		
		global $USER;
		
		$arMailFields = array(
			'CONTENT' => $text
		);
		
		$ev = new CEvent;
		$res = $ev->Send('ZOLOTO_SITE_LOG', 's1', $arMailFields);		
		
		return $res;
	}

	/**
	 * Отправка содержимого файла лога вызова функций администратору и очистка файла лога
	 * @return boolean
	 */
	public function sendFunctionCallLogToEmail()
	{
		$logFilePath = $_SERVER['DOCUMENT_ROOT'] . self::FUNCTION_LOG_FILE;
		$logContent = file_get_contents($logFilePath);
		if (!empty($logContent)) {
			$logContent = str_replace(PHP_EOL, '<br>', $logContent);
			self::sendLogToEmail($logContent);
			file_put_contents($logFilePath, '');
		}
	}
}
?>