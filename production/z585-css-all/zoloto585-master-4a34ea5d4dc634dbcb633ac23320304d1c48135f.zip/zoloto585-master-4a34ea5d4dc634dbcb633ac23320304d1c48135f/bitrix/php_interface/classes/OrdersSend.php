<?php
use Bitrix\Main,
	Bitrix\Sale\Order,
	Bitrix\Sale\OrderTable,
	Bitrix\Main\Loader,
	Bitrix\Main\Mail\Event;

class OrdersSend{

	private $keyRest = Zoloto585Config::API_KEY;

	private $bpmUrlPutOrder = "http://91.240.95.203/0/rest/NrbIntegaration1C/PutOrder";
	private $bpmUrlPutOrderStatus = "http://91.240.95.203/0/rest/NrbIntegaration1C/PutOrderStatus";
	private $bpmUrlAuth = "http://91.240.95.203/ServiceModel/AuthService.svc/Login";
	private $bmpUser = "Bitrix";
	private $bmpPassword = "3fohnzpy";
	private $cookiePath;

	public function __construct() {
		Loader::IncludeModule('catalog');
		Loader::IncludeModule('sale');
		$this->cookiePath = $_SERVER["DOCUMENT_ROOT"]."/bitrix/cache/bmpcookie.txt";
	}

	/**
	 *  отправка данных
	 */
	public function send()
	{
		$arOrdersID = $this->getOrdersIDPrevDay();
		$arOrdersData = $this->prepareOrders($arOrdersID);

		if(count($arOrdersData)>0)
		{
			$this->sendRestData($arOrdersData);
			//$this->sendBPMData($arOrdersData);
			//Zoloto585Kafka::sendKafkaData($arOrdersData,"orders");
		}
	}

	/**
	 * повторная отрпавка проблемных заказов в BPM
	 * @param $arOrdersID - ID заказов
	 */
	public function bpmSendOrderRepeat($arOrdersID)
	{
		$arOrdersData = $this->prepareOrders($arOrdersID);

		if(count($arOrdersData)>0 && $this->bpmSendAuth())
		{
			$sErrorLog = "";

			foreach ($arOrdersData as $arOrder)
			{
				$arResultSend = $this->bpmSendPutOrder($arOrder);

				if ($arResultSend["ResultCode"] == "1") // такой заказ уже есть
					$arResultSend = $this->bpmSendPutOrderStatus($arOrder);


				if ($arResultSend["ResultCode"] != "0")
				{
					$sErrorLog .= "BPM. Проблема при отправки заказа ID={$arOrder["ID"]}. Текст ошибки: ".$arResultSend["ResultMessage"]."<br>".PHP_EOL;
				}
			}

			if (strlen($sErrorLog)>0)
				Zoloto585Logger::logError($sErrorLog);

		}

	}

	/**
	 * Выбираем измененные заказы за последнии сутки
	 */
	private function getOrdersIDPrevDay()
	{
		$date = new DateTime();

		//$date->setDate(2017, 2, 8);
		//$date->setTime(00,01);


		$prevDate = clone($date);
		$prevDate->modify("-1 day");

		$arOrders = OrderTable::getList(array(
			'select'  => ["ID"],
			'filter'  => ['>=DATE_UPDATE' => $prevDate->format('d.m.Y'),'<DATE_UPDATE' => $date->format('d.m.Y')],
			'order'   => ["ID"=>"ASC"],
		))->fetchAll();

		return $arOrders;
	}

	/**
	 * выборка доп. данных по заказам и их оформление в массив
	 * @param $arOrders
	 * @return array
	 */
	private function prepareOrders ($arOrders)
	{
		$arRestData = Array();
		$arBasketProduct = Array();
		$i=0;
		foreach($arOrders as $orderID)
		{
			$i++;
			$arData = Array();

			$order = Order::load($orderID);

			// получаем свойства заказа и сохраняем в массив CODE => VALUE
			$arOrderProps = Array();
			$propertyCollection =  $order->getPropertyCollection();
			foreach ($propertyCollection as $property)
				$arOrderProps[$property -> getField('CODE')] = $property->getValue();

			// получаем первый товар в корзине
			$basketItem = $order->getBasket()->getBasketItems()[0];
			if (empty($basketItem)) continue;

			//собираем id товаров, чтобы потом разом запросить их XML_ID
			$arBasketProduct[] = $basketItem->getProductId();

			//получаем примененные скидки и купоны
			$discountData = $order->getDiscount()->getApplyResult();

			$couponCode = "";
			//проходим все купоны заказа
			foreach($discountData["COUPON_LIST"] as $arCoupon)
			{
				//если купон был применен, то запоминаем его
				if ($arCoupon["APPLY"]=="Y")
				{
					$couponCode = $arCoupon["COUPON"];
				}
			}

			$discounts = "";
			//проходим все скидки заказа
			foreach($discountData["DISCOUNT_LIST"] as $arDiscount)
			{
				//если скидка была применена, то запоминаем ее
				if ($arDiscount["APPLY"]=="Y")
				{
					$discounts .= $arDiscount["NAME"].";";
				}
			}

			//заполняем поля
			$arData["DATE_CREATE"] = $order->getField('DATE_INSERT')->format("Y-m-d H:i:s");
			$arData["ID"] = $order->getID();
			$arData["STATUS"] = $order->getField('STATUS_ID');
			$arData["BASKET_SUM"] = $order->getPrice();
			$arData["DATE_CHANGE"] = $order->getField('DATE_UPDATE')->format("Y-m-d H:i:s");
			$arData["SHOP_XML_ID"] = trim($arOrderProps['XML_ID']);
			$arData["SHOP_ADDRESS"] = $arOrderProps['pickupshop'];;
			$arData["USER_PHONE"] = "7".clear_phone($arOrderProps['PHONE']);
			$arData["COMMENTS"] = $order->getField('COMMENTS');
			$arData["CITY"] = $arOrderProps['CITY'];
			$arData["BASKET_GOODS"] = "[".$basketItem->getProductId()."] ".$basketItem->getField('NAME');
			$arData["USER_CARD_NUMBER"] = ($arOrderProps["CARD"]!=0) ? $arOrderProps["CARD"] : "";
			$arData["PROMO_CODE"] = $arOrderProps["PROMO_CODE"];
			$arData["PRODUCT_NAME"] = $basketItem->getField('NAME');
			$arData["PRODUCT_CODE"] = $basketItem->getProductId();
			$arData["PRODUCT_PRICE"] = round($basketItem->getField('BASE_PRICE'));
			$arData["BASKET_CUPONS"] = $couponCode;
			$arData["PRODUCT_SALE_NAME"] = ($arData["BASKET_SUM"]<$arData["PRODUCT_PRICE"]) ? $arData["PRODUCT_PRICE"]-$arData["BASKET_SUM"] : 0;
			$arData["PRODUCT_SALE_SUM"] = ($arData["BASKET_SUM"]<$arData["PRODUCT_PRICE"] ? round(($arData["PRODUCT_PRICE"]-$arData["BASKET_SUM"])/$arData["PRODUCT_PRICE"],4)*100 : 0);
			$arData["BASKET_SALES"] = $discounts;

			$arRestData[]=$arData;
		}

		// получаем информацию о торговых предложениях
		if(count($arBasketProduct)>0)
		{
			$resSKU = CIBlockElement::GetList(
				Array(),
				Array("ID" => $arBasketProduct),
				false,
				false,
				array("ID","XML_ID")
			);

			while($ar=$resSKU->fetch())
			{
				$arSKU[$ar["ID"]] = $ar["XML_ID"];
			}
		}

		if(count($arRestData)>0)
		{
			//заполним XML_ID товара
			foreach($arRestData as &$arData)
			{
				$arData["PRODUCT_CODE_EXT"] = $arSKU[$arData["PRODUCT_CODE"]];
			}
		}

		return $arRestData;
	}

	/**
	 * отппавка заказов в rest
	 * @param $arData - массив для отправки
	 */
	private function sendRestData($arData)
	{
		$arResult = $this->sendCurlData($arData,'http://91.240.95.85/restapi/v1/ordertodwh/?api_key='.$this->keyRest);

		if(!$arResult["errorSend"])
		{
			$strErrors = "";

			foreach ($arResult["error_rows"] as $arError)
			{
				$strErrors.=$arError["ID"].": ".$arError["error"] ."\n";
			}

			if(!empty($strErrors))
			{
				$strErrors = "RestApi. Сервер вернул ошибку в резултате отправки данных. Ошибки:\n".$strErrors;
				Zoloto585Logger::logError($strErrors);
			}
		}
	}

	/**
	 * отправка данных в BMP
	 * @param $arData - массив для отправки
	 */
	private function sendBPMData($arData)
	{
		$arAddOrder = Array();
		$arUpdateOrder = Array();


		//сортируем заказы на новые и обновленные
		foreach ($arData as $order)
		{

			if (strtotime($order["DATE_CHANGE"])==strtotime($order["DATE_CREATE"]))
				$arAddOrder[] = $order;
			else
				$arUpdateOrder[] = $order;
		}

		if ($this->bpmSendAuth())
		{
			$sErrorLog = "";
			//отправляем новые заказы
			foreach ($arAddOrder as $arOrder)
			{
				$arResultSend = $this->bpmSendPutOrder($arOrder);

				if ($arResultSend["ResultCode"] != "0")
				{
					$sErrorLog .= "BPM. Проблема при отправки нового заказе ID={$arOrder["ID"]}. Текст ошибки: ".$arResultSend["ResultMessage"]."<br>".PHP_EOL;
				}
			}

			//обновляем заказы
			foreach ($arUpdateOrder as $arOrder)
			{
				$arResultSend = $this->bpmSendPutOrderStatus($arOrder);

				if ($arResultSend["ResultCode"] != "0")
				{
					$sErrorLog .= "BPM. Проблема при обновлении заказа ID={$arOrder["ID"]}. Текст ошибки: ".$arResultSend["ResultMessage"]."<br>".PHP_EOL;
				}
			}

			if (strlen($sErrorLog)>0)
				Zoloto585Logger::logError($sErrorLog);
		}
	}

	/**
	 * авторизация в BPM
	 * @return bool
	 */
	private function bpmSendAuth()
	{
		$arDataAuth = Array(
			"UserName" => $this->bmpUser,
			"UserPassword" => $this->bmpPassword
		);

		$arAuthResult = $this->curlSetCookie($arDataAuth, $this->bpmUrlAuth, $this->cookiePath);

		if ($arAuthResult["Code"] != "0" || $arAuthResult["errorSend"])
		{
			Zoloto585Logger::logError("BPM. Проблема авторизации на сервере. Текст ошибки: ".$arAuthResult["Message"]);
			return false;
		}

		return true;
	}

	/**
	 * запрос на создание нового заказа в BPM
	 * @param $arOrder - данные о заказе
	 * @return mixed
	 */
	private function bpmSendPutOrder($arOrder)
	{
		$data = array(
			"phoneNumber" => $arOrder["USER_PHONE"],
			"storeCode" => '3'.$arOrder["SHOP_XML_ID"],
			"orderCode" => $arOrder["ID"],
			"orderStatus" => $arOrder["STATUS"],
			"orderPositions" => Array(
				Array(
					"Outerkeys" => Array(
						Array(
							"@name" => "productSAPCode",
							"@entity" => "Product",
							"#text" => $arOrder["PRODUCT_CODE_EXT"]
						)
					),
					"Attributes" => Array(
						Array(
							"@name" => "position",
							"@type" => "Integer",
							"#text" => "1"
						),
						Array(
							"@name" => "quantity",
							"@type" => "Integer",
							"#text" => "1"
						),
						Array(
							"@name" => "price",
							"@type" => "Decimal",
							"#text" => $arOrder["PRODUCT_PRICE"]
						),
					)
				)
			)
		);

		return $this->sendCurlData($data,$this->bpmUrlPutOrder,$this->cookiePath);
	}

	/**
	 * запрос на обновление заказа в BPM
	 * @param $arOrder - данные о заказе
	 * @return mixed
	 */
	private function bpmSendPutOrderStatus($arOrder)
	{
		$data = array(
			"orderCode" => $arOrder["ID"],
			"orderStatus" => $arOrder["STATUS"],
			"modifiedOn" => date("c",strtotime($arOrder["DATE_CHANGE"])),
			"description" => $arOrder["COMMENTS"],
		);

		return $arResultSend = $this->sendCurlData($data, $this->bpmUrlPutOrderStatus, $this->cookiePath);
	}

	/**
	 * авторизация с сохранение cookie
	 * @param $arData - данные запроса
	 * @param $url - адрес сервиса
	 * @param $cookiePath - путь к файлы куки
	 * @return mixed
	 */
	private function curlSetCookie($arData, $url, $cookiePath)
	{
		$data_string = json_encode($arData);

		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_COOKIEJAR, $cookiePath);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				'Content-Type: application/json',
				'Content-Length: ' . strlen($data_string))
		);

		$result = curl_exec($ch);
		$status = curl_getinfo($ch);

		if (!in_array($status["http_code"],Array(200,201)))
		{
			Zoloto585Logger::logError("SendOrders. Сервер вернул ошибку в резултате отправки данных. Ответ сервера: ".print_r($status,true));
			$arResult["errorSend"] = true;
		}
		else
		{
			$arResult = json_decode($result,true);
			$arResult["errorSend"] = false;
		}

		return $arResult;
	}

	/**
	 * отправка запроса curl
	 * @param $arData - данные запроса
	 * @param $url - адрес
	 * @param bool $cookiePath - файл куки, если необходим
	 * @return mixed
	 */
	private function sendCurlData($arData, $url, $cookiePath=false)
	{

		$json_str = json_encode($arData);
		$ch = curl_init($url);
		curl_setopt ($ch, CURLOPT_TIMEOUT, 30); // максимальное время ожидания ответа 30 секунд
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $json_str);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		if ($cookiePath)
			curl_setopt($ch, CURLOPT_COOKIEFILE, $cookiePath);

		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				'Content-Type: application/json',
				'Content-Length: ' . strlen($json_str))
		);

		$result = curl_exec($ch);
		$status = curl_getinfo($ch);

		if (!in_array($status["http_code"],Array(200,201)))
		{
			Zoloto585Logger::logError("SendOrders. Сервер вернул ошибку в резултате отправки данных. Ответ сервера: ".print_r($status,true));
			$arResult["errorSend"] = true;
		}
		else
		{
			$arResult = json_decode($result,true);
			$arResult["errorSend"] = false;
		}

		return $arResult;

	}
}
?>