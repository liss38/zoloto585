<?
class BoxCom
{
	/**
	 * Настройки соединения FTP
	 */
	const BOX_FTP = 'ftp.box.com';
	const BOX_FTP_USER = 'Yashunin.Maksim@zoloto585.ru';
	const BOX_FTP_PASS = '__585GOLD';

	/**
	 *  папка с изображениями
	 */
	const BOX_FTP_DIR = "/photosforweb/";

	/**
	 *  папка с успешно прикрипленными изображениями
	 */
	const BOX_FTP_DIR_COMPLETE = "/photosforweb/complete/";

	/**
	 *  папка с изображениями к которым не был найден товар
	 */
	const BOX_FTP_DIR_NOT_FOUND = "/photosforweb/not_found/";

	/**
	 *  папка с повторными изображениями
	 */
	const BOX_FTP_DIR_REPEAT = "/photosforweb/repeat/";

	/**
	 *  временная папка с изображениями
	 */
	const BITRIX_TMP_DIR_IMAGE = "/upload/boxcom/";

	/**
	 * Инфоблоки каталога
	 */
	const IBLOCK_PRODUCT = 4;
	const IBLOCK_SKU = 29;

	/**
	 * почтовый шаблон для уведомлений
	 */
	const EVENT_TEMPLATE_ID = 80;

	/**
	 *  доступные расширения файлов
	 */
	private $arExt = Array("png","jpg");

	/**
	 *  текущее FTP соединение
	 */
	private $ftpCon;

	/**
	 *  массивы для хранения логов
	 */
	private $arLoad = Array();  // новые
	private $arNotFind = Array(); // не найдены
	private $arExist = Array(); // уже есть


	/**
	 *  это агент?
	 */
	private $bAgent = false;


	/**
	 * подключение по ftp, залогиневание, переключение в пассивный режим
	 * @return bool
	 */
	private function connect()
	{
		$conn_id = ftp_connect(self::BOX_FTP);

		if (ftp_login($conn_id, self::BOX_FTP_USER, self::BOX_FTP_PASS))
		{
			ftp_pasv($conn_id, true);
			$this->ftpCon = $conn_id;

			return true;
		}
		else
		{
			$this->sendError("Ошибка соединения по ftp");
		}

		return false;
	}

	/**
	 * закрытие FTP соединения
	 */
	private function disconnect()
	{
		ftp_close($this->ftpCon);
	}

	/**
	 * получаем список файлов из раздела FTP
	 *
	 * @param $dir - расздел из которого получаем файлы
	 * @return array - массив файлов
	 */
	private function getFtpFolderFiles($dir)
	{
		if (is_array($children = @ftp_rawlist($this->ftpCon, $dir)))
		{
			$items = array();

			foreach ($children as $child) {
				$chunks = preg_split("/\s+/", $child);
				list($item['rights'], $item['number'], $item['user'], $item['group'], $item['size'], $item['month'], $item['day'], $item['time']) = $chunks;
				$item['type'] = $chunks[0]{0} === 'd' ? 'directory' : 'file';
				array_splice($chunks, 0, 8);
				$item['name'] = implode(" ", $chunks);

				if($item['type']=="file")
					$items[] = $item;
			}

			return $items;
		}
	}

	/**
	 * фильтруем от лишних файлов и структурируем данные
	 *
	 * @param $arFiles - массив файлов полученный из ftp
	 * @return array - файлы нужных расширений разложенные по soap кодам
	 */
	private function filterFiles($arFiles)
	{
		$arProductFiles = Array();

		foreach ($arFiles as $key=>$arFile)
		{
			//расширение файла
			$ext = strtolower(pathinfo($arFile["name"], PATHINFO_EXTENSION));

			//если файл допустимый
			if(in_array($ext,$this->arExt))
			{
				//получаем имя файла
				$name = pathinfo($arFile["name"], PATHINFO_FILENAME);

				//чтобы узнать SOAP код, откидываем все кроме цифр
				$productID = preg_replace("/[^\d]/","",$name);

				if(!empty($productID))
				{
					//раскладываем файлы по soap кодам
					$productID="00000000".$productID;
					$arProductFiles[$productID][]=$arFile["name"];
				}
				else
				{
					$this->arNotFind[] = $arFile["name"];
				}
			}
			else
			{
				$this->arNotFind[] = $arFile["name"];
			}
		}

		return $arProductFiles;
	}

	/**
	 * ищем SKU по заданным soap кодам
	 *
	 * @param $arProductFiles - список файлов разбитых по soap кодам
	 * @return array - массив найденых предложений по XML_ID
	 */
	private function loadProductSKU($arProductFiles)
	{
		$arSku = Array();

		$rs = CIBlockElement::GetList(
			array(),
			array(
				"IBLOCK_ID" => self::IBLOCK_SKU,
				"=XML_ID" => array_keys($arProductFiles)
			),
			false,
			false,
			array("ID","XML_ID","PROPERTY_CML2_LINK")
		);

		//раскладываем по принципу SOAP_CODE => PRODUCT_ID (не SKU)
		while($ar = $rs->GetNext())
		{
			$arSku[$ar["XML_ID"]] = $ar["PROPERTY_CML2_LINK_VALUE"];
		}

		return $arSku;
	}

	/**
	 *
	 * Получаем список товаров для имеющихся SKU
	 * Выбираем фотографии
	 *
	 * @param $arSKU
	 * @return array
	 */
	private function loadProduct($arSKU)
	{
		$arProduct = Array();

		$rs = CIBlockElement::GetList(
			array(),
			array(
				"IBLOCK_ID" => self::IBLOCK_PRODUCT,
				"ID" => $arSKU
			),
			false,
			false,
			array("ID","NAME","DETAIL_PICTURE","PROPERTY_fotogallery")
		);

		while($ar = $rs->GetNext())
		{

			/**
			 *  Объединяем множественное свойство самостоятельно, так как выбрана система хранения свойств и товаров
			 *  в одном инфоблоке
			 */

			$arProduct[$ar["ID"]]["DETAIL_PICTURE"] = $ar["DETAIL_PICTURE"];
			$arProduct[$ar["ID"]]["ID"] = $ar["ID"];
			$arProduct[$ar["ID"]]["NAME"] = $ar["NAME"];

			if(!empty($ar["PROPERTY_FOTOGALLERY_VALUE"]))
				$arProduct[$ar["ID"]]["GALLERY"][] = $ar["PROPERTY_FOTOGALLERY_VALUE"];
		}

		return $arProduct;
	}

	/**
	 * закачиваем все файлы с box.com по ftp в временную папку
	 * @param $arProductFiles
	 *  @return bool
	 */
	private function downloadFiles($arProductFiles)
	{
		//проверяем наличие папки, если нет, то пытаемся создать
		if (!is_dir($_SERVER["DOCUMENT_ROOT"].self::BITRIX_TMP_DIR_IMAGE))
		{
			if(!mkdir($_SERVER["DOCUMENT_ROOT"].self::BITRIX_TMP_DIR_IMAGE, 0777))
			{
				$this->sendError("Не удалось создать папку ".$_SERVER["DOCUMENT_ROOT"].self::BITRIX_TMP_DIR_IMAGE);
				return false;
			}
		}

		$dir = $_SERVER["DOCUMENT_ROOT"].self::BITRIX_TMP_DIR_IMAGE;

		//закачиваем файлы
		foreach ($arProductFiles as $arFiles)
		{
			foreach ($arFiles as $file)
			{
				ftp_get($this->ftpCon, $dir.$file, self::BOX_FTP_DIR.$file, FTP_BINARY, 0);
			}
		}

		return true;
	}

	/**
	 *  очищает файлы из временной папки
	 */
	private function clearFiles()
	{
		if (is_dir($_SERVER["DOCUMENT_ROOT"].self::BITRIX_TMP_DIR_IMAGE))
		{
			foreach (glob($_SERVER["DOCUMENT_ROOT"].self::BITRIX_TMP_DIR_IMAGE.'/*') as $file)
			{
				unlink($file);
			}
		}
	}

	/**
	 *  прикрепляем файлы из временной папки к товарам
	 */
	private function addFile2Product($arProductFiles,$arProductSKU,$arProductList)
	{
		foreach ($arProductSKU as $skuID => $productID)
		{
			$arProduct = $arProductList[$productID];

			//обновляем детальную фотографию
			if (empty($arProduct["DETAIL_PICTURE"]) && !empty($arProductFiles[$skuID][0]))
			{
				$this->arLoad[$arProduct["ID"]]["DETAIL_PICTURE"] = $arProductFiles[$skuID][0];
				$this->arLoad[$arProduct["ID"]]["NAME"] = $arProduct["NAME"];

				$el = new CIBlockElement;
				$el->Update($arProduct["ID"], Array("DETAIL_PICTURE"=>CFile::MakeFileArray($_SERVER["DOCUMENT_ROOT"].self::BITRIX_TMP_DIR_IMAGE.$arProductFiles[$skuID][0])));
			}

			//обновляем фотогалерею
			if (empty($arProduct["GALLERY"]))
			{
				$arFilesSave = Array();
				foreach ($arProductFiles[$skuID] as $key=>$file)
				{
					$this->arLoad[$arProduct["ID"]]["GALLERY"][] = $arProductFiles[$skuID][$key];
					$this->arLoad[$arProduct["ID"]]["NAME"] = $arProduct["NAME"];
					$arFilesSave[]=CFile::MakeFileArray($_SERVER["DOCUMENT_ROOT"].self::BITRIX_TMP_DIR_IMAGE.$arProductFiles[$skuID][$key]);
				}

				CIBlockElement::SetPropertyValuesEx($arProduct["ID"], self::IBLOCK_PRODUCT, Array("fotogallery"=>$arFilesSave));
			}
		}
	}

	/**
	 *  функция перемещения обработанных файлов по папкам на стороне box.com
	 */
	private function moveFilesFtp()
	{
		// перемещаем не найденные
		foreach ($this->arNotFind as $file)
			$this->moveFileFtp(self::BOX_FTP_DIR.$file,self::BOX_FTP_DIR_NOT_FOUND.$file);

		// перемещаем конфлитные
		foreach ($this->arExist as $ar)
		{
			foreach ($ar as $arFile)
				$this->moveFileFtp(self::BOX_FTP_DIR.$arFile[0],self::BOX_FTP_DIR_REPEAT.$arFile[0]);
		}

		// перемещаем успешно загруженные
		foreach ($this->arLoad as $ar)
		{
			if (!empty($ar["GALLERY"]))
			{
				foreach ($ar["GALLERY"] as $file)
					$this->moveFileFtp(self::BOX_FTP_DIR.$file,self::BOX_FTP_DIR_COMPLETE.$file);
			}
			elseif(!empty($ar["DETAIL_PICTURE"]))
			{
				$this->moveFileFtp(self::BOX_FTP_DIR.$ar["DETAIL_PICTURE"],self::BOX_FTP_DIR_COMPLETE.$ar["DETAIL_PICTURE"]);
			}
		}
	}

	/**
	 *  вспомогашка, зачем?
	 *  на всяк случай
	 */
	private function moveFileFtp($from,$to)
	{
		return ftp_rename($this->ftpCon, $from, $to);
	}

	/**
	 * отправка лога работы на экран или в письмах
	 */
	private function getLog()
	{
		$logLoad = "<b>Карточки товаров с новыми фотографиями:</b><br>";

		$iblockID = self::IBLOCK_PRODUCT;

		//собираем успешно прикрепленные
		foreach ($this->arLoad as $id => $ar)
		{
			$logLoad .= "<a href='http://zoloto585.ru/bitrix/admin/iblock_element_edit.php?IBLOCK_ID={$iblockID}&type=catalog&ID={$id}'>{$ar["NAME"]}</a><br>";

			if(!empty($ar["DETAIL_PICTURE"]))
			{
				$logLoad.= "Детальная картинка: {$ar["DETAIL_PICTURE"]}<br>";
				$this->moveFileFtp(self::BOX_FTP_DIR.$ar["DETAIL_PICTURE"],self::BOX_FTP_DIR_COMPLETE.$ar["DETAIL_PICTURE"]);
			}

			if (!empty($ar["GALLERY"]))
			{
				$logLoad.= "Фотогалерея: ";
				foreach ($ar["GALLERY"] as $file)
					$logLoad.=$file."&nbsp;&nbsp;&nbsp;";

				$logLoad.="<br>";
			}
			echo "<br>";
		}

		$logError = "<b>Фотографии без карточек товара</b><br>";

		//собираем не найденные
		foreach ($this->arNotFind as $file)
			$logError .= $file."<br>";

		$logError .= "<br><b>Конфликт. У данных карточек товаров уже заданны фотографии</b><br>";

		//собираем конфликтные
		foreach ($this->arExist as $ar)
		{
			$logError .= "<a href='http://zoloto585.ru/bitrix/admin/iblock_element_edit.php?IBLOCK_ID={$iblockID}&type=catalog&ID={$ar[0][2]}'>{$ar[0][1]}</a><br>";

			foreach ($ar as $arFile)
				$logError .= $arFile[0]."<br>";

		}

		//если это не агент, выводим на экран
		if (!$this->bAgent)
		{
			echo $logLoad;
			echo "<br><br>";
			echo $logError;
		}


		CEvent::Send
		(
			"EMPTY",
			"s1",
			Array(
				"THEME" => "Отчет о загрузки фотографий c BOX.COM",
				"TEXT" => $logLoad."<br><br>".$logError
			),
			"N",
			self::EVENT_TEMPLATE_ID
		);


	}

	/**
	 * обработка ошибок после которых не возможно продолжение дальнейшей работы
	 * @param $error - текст ошибки
	 */
	private function sendError($error)
	{
		//если, не агент, то выводим на экран
		if (!$this->bAgent)
		{
			echo $error;
			die();
		}
		//если агент, отправляем всем, чтобы
		else
		{
			//одни не паниковали
			CEvent::Send
			(
				"EMPTY",
				"s1",
				Array(
					"THEME" => "Проблема при синхронизации с box.com",
					"TEXT" => $error
				),
				"N",
				self::EVENT_TEMPLATE_ID
			);

			//а другие исправляли
			Zoloto585Logger::logError("Проблема при синхронизации с box.com. Ошибка: ".$error);
		}
	}

	/**
	 * основной метод для работы
	 *
	 * @param bool $bAgent - true если это агент
	 * @param bool $moveFtpFiles - true если в конце необходимо перенести файлы по папкам на стороне box.com
	 */
	public function run($bAgent=false,$moveFtpFiles=false)
	{
		CModule::IncludeModule("iblock");

		$this->bAgent = $bAgent;

		//если успешно соединились
		if ($this->connect())
		{
			//получаем список файлов на box.com
			$arFiles = $this->getFtpFolderFiles(self::BOX_FTP_DIR);

			//если файлов нет
			if (count($arFiles) == 0)
			{
				//и это не агент
				if (!$this->bAgent)
				{
					//завершаем работу и выводим соотвествующие сообщение
					echo "В папке отсутсвуют файлы";
					exit;
				}
			}
			else
			{
				//фильтруем по расширениям и структурируем полученные файлы
				$arProductFiles = $this->filterFiles($arFiles);

				//если остались файлы после фильтрации, узнаем есть ли в битриксе sku c этими SOAP кодами
				if (count($arProductFiles)>0)
				{
					// получаем список SKU по кодам SOAP
					$arProductSKU = $this->loadProductSKU($arProductFiles);

					//все файлы по которым не нашлись SKU товары, убираем из массива файлов и отправляем в массив не найденных файлов
					foreach ($arProductFiles as $skuID => $arFiles)
					{
						if (empty($arProductSKU[$skuID]))
						{
							foreach ($arFiles as $file)
							{
								$this->arNotFind[] = $file;
							}

							unset($arProductFiles[$skuID]);
						}
					}
				}

				//если были найдены SKU по соап кодам
				$bSave = false;
				if (!empty($arProductSKU))
				{
					//то получим Деатальную фоторграфию и Свойства Фотогалерея из продукта, в которые входят эти SKU
					$arProductList = $this->loadProduct($arProductSKU);

					//проверим в каких продуктах уже заданы фотографии и исключим эти картинки из загрузки
					foreach ($arProductSKU as $skuID => $productID)
					{
						$arProduct = $arProductList[$productID];

						$bDetailEmpty = true;
						if (!empty($arProduct["DETAIL_PICTURE"]))
						{
							$bDetailEmpty = false;
						}

						if (!empty($arProduct["GALLERY"]))
						{
							foreach ($arProductFiles[$skuID] as $key=>$file)
							{
								if ($bDetailEmpty && $key==0)
									continue;

								$this->arExist[$arProduct["ID"]][] = Array($arProductFiles[$skuID][$key],$arProduct["NAME"],$arProduct["ID"]);
								unset($arProductFiles[$skuID][$key]);
							}
						}

						//есть ли файлы для сохранения
						if (count($arProductFiles[$skuID])>0) $bSave = true;
					}
				}

				$bLoadFileError = false;
				//если после всех фильтраций и проверок, еще остались файлы, то начинаем обработку файлов
				if ($bSave)
				{
					//если файлы успешно скачались
					if ($this->downloadFiles($arProductFiles))
					{
						//сохраняем в временную папку
						$this->addFile2Product($arProductFiles,$arProductSKU,$arProductList);

						//очищаем временную папку
						$this->clearFiles();
					}
					else
					{
						$bLoadFileError = true;
					}
				}

				//если загрузка файлов прошла успешно, то переносим файлы и отправляем лог
				if (!$bLoadFileError)
				{
					//если необходимо раскидвать файлы по папкам
					if($moveFtpFiles)
						$this->moveFilesFtp(); // то делаем это

					//шлем лог на экран или на почту
					$this->getLog();
				}

			}

			//закрываем ftp соединение
			$this->disconnect();
		}



	}
}