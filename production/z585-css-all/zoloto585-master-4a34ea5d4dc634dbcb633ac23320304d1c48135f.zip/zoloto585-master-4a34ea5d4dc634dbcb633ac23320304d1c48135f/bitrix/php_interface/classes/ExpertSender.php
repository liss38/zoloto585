<?
class ExpertSender
{
	const GENDER_W = 1;
	const GENDER_M = 2;
	const SOURCE_CARD_CRM = 1;
	const SUBSCRIBE_LIST_MAIN = 4;	

	private $API_KEY = "mBCDZCVxSn961RzVNR7F";
	private $arProp = Array(
		"BCNUMBER" => Array(5,"xs:string"),
		"BIRTHDATE" => Array(19,"xs:date"),
		"CITY" => Array(2,"xs:string"),
		"GENDER" => Array(7,"xs:string"),
		"SOURCE" => Array(4,"xs:string"),
	);
	public $errorCode;
	public $errorMessage;

	function __construct()
	{

	}

	public function subscribe($listID, $name, $email,$arProp=Array())
	{
		$subscribeTemplate = " 
		 <ApiRequest xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xs=\"http://www.w3.org/2001/XMLSchema\">
			<ApiKey>".$this->API_KEY."</ApiKey>
			<Data xsi:type=\"Subscriber\">
			   <Mode>AddAndUpdate</Mode>
			   <Force>true</Force>
			   <ListId>#LIST_ID#</ListId>
			   <Email>#EMAIL#</Email>
			   #NAME#
			   #PROPERTY#
			</Data>
		 </ApiRequest>";

		if (!empty($name) && !empty($email) && !empty($listID))
		{
			$propXml = "<Properties>";
			foreach ($arProp as $prop=>$value)
			{
				$propXml .= "
				<Property>
					<Id>".$this->arProp[$prop][0]."</Id>
					<Value xsi:type='".$this->arProp[$prop][1]."'>".$value."</Value>
				</Property>";
			}
			$propXml .= "</Properties>";


			if (strpos(trim($name)," ")!==false)
				$name = "<Name>$name</Name>";
			else
				$name = "<Firstname>$name</Firstname>";

			$request = str_replace(Array("#LIST_ID#","#NAME#","#EMAIL#","#PROPERTY#"),Array($listID,$name,$email,$propXml),$subscribeTemplate);
			$this->send($request);
		}
		else
		{
			$this->setError("400","Не полные данные");
		}
	}


	private function send($request)
	{
		$curl_options = array (
			CURLOPT_URL => 'https://api4.esv2.com/Api/Subscribers',
			CURLOPT_POST => true,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POSTFIELDS => ($request)
		);

		$curl = curl_init();
		curl_setopt_array($curl, $curl_options);

		$response = curl_exec($curl);
		$status = curl_getinfo($curl);

		if ($status["http_code"]!=201)
		{
			$obResponse = new SimpleXMLElement($response);
			$this->setError($obResponse->ErrorMessage->Code,$obResponse->ErrorMessage->Message);
		}

		curl_close($curl);
	}

	private function setError($code,$text)
	{
		$this->errorCode = $code;
		$this->errorMessage = $text;
	}
}