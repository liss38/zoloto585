<?php 

class GetDoneOrders {

    public function __construct() {
        CModule::IncludeModule('sale');
        CModule::IncludeModule('catalog');
    }

	//Получить данные по URL
    private function fetch($url) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");

        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }

	//Получить список заказов	
    private function getOrderList($date) {
        $url = "http://91.240.95.85/restapi/v1/softchecks/$date/?api_key=" . Zoloto585Config::API_KEY;
        $jsonData = trim($this->fetch($url));
        $json = json_decode($jsonData);
        return $json;
    }
	
	/**
	 * Обновить статус
	 * @param DateTime $date обновить статусы за этот день
	 */
    public function setStatusByDate($date)
    {

        $ordersToUpdate = self::getOrdersNotFStatus($date);
        $json = $this->getOrderList($date->format('dmY'));
        if(is_array($json)) {
            for ($i = 0; $i < sizeof($json); $i++) {
                $elem = $json[$i];
                if (in_array($elem->softcheck_number,$ordersToUpdate)) {
                    $fields = array("STATUS_ID" => 'F', 'DATE_STATUS' => $elem->datetime);
                    CSaleOrder::Update($elem->softcheck_number, $fields);
                }
            }
        }
       else Zoloto585Logger::logError($json->status);
    }
    
    /**
     * Получает список заказов с сайта, которые не находятся в статусе F
     * @param  DateTime $date Дата, на которую получаем заказы
     * @return array    идентификаторы зказов
     */
    public function getOrdersNotFStatus($date)
    {
        \Bitrix\Main\Loader::includeModule('sale');

        $dateTomorrow = clone($date);
        $datetake = clone($date);
        $dateTomorrow->modify('+1 day');
        $datetake->modify('-5 day');

        $dbOrders = CSaleOrder::GetList(
            [],
            [
                '!STATUS_ID' => 'F',
                '>=DATE_INSERT' => $datetake->format('d.m.Y'),
                 '<DATE_INSERT' => $dateTomorrow->format('d.m.Y')

            ],
            false,
            false,
            ['ID']
        );
        $orderIds = [];
        while ($arOrder = $dbOrders->Fetch()) {
            $orderIds[] = $arOrder['ID'];
        }

        return $orderIds;
    }

    //обновление статусов у заказов давностью более 3 дней
    public function makeOrderDate() {
        $orders = CSaleOrder::GetList(array("DATE_STATUS" => "DESC"), array("STATUS_ID" => "W"));
        while ($order = $orders->fetch()) {
            if($order['ID']==763)continue;
            $date = $order['DATE_STATUS'];
            $time = strtotime($date);
            $timeStart = strtotime(date("d.m.Y 00:00:00", $time));
            $timeEnd = $timeStart + 3600 * 24 * 4;
            if ($timeEnd < time()) {
                CSaleOrder::Update($order["ID"], array("STATUS_ID" => "R"));
            }
        }
    }

}

//example:
//$ms = new GetDoneOrders();
//$ms->setStatusByDate("10082016");



?>