<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
//$t=time();
$import = new UserMainImportEngine(5);


/* Импорт HL блоков */ //done
//$import->importHlBlock(500);

/* Импорт ТП блоков */ //обновление карточек товаров true-+ обновление, без параметра- на добавление
//$import->importOffersIBlockApi(10000, true);

/* Обновление свойств карточек товаров */
//$import->updateCatalogProperties(5000);

/* Обновление цен ТП */ //done
//$import->updateOffersPrice(10000);

/* Миграция старых торговых предложений и подвязка их к КТ */ //done
//$import->migrationOldOffersCatalog();

/* Импорт Карточек товаров */ //done
//$import->importCatalogBlock(10000);

/* Привязка к категориям товаров */ //done
//$import->setProductsToCategories(10000);

/* Удаление товаров без торговых предложений */ //done
//$import->delCatalogProductsWithoutOffers();

/* Импорт складов */ //done
//$import->importStoreWarehouses();

/* Обновление данных магазина по данным из AD (выгрузка из AD - в файле на удаленном сервере) */ //done
//$import->importStoreEmails();

/* обновление ГЕО координат для магазинов */
//$import->GetGEOStores();

/* Импорт всех остатков */
/*
	Метод принимает 2 параметра - тип загрузки и порции.
	Тип загрузки:
		1) ALL - загрузка всех остатков, включая и дельта остатки
		2) DELTA - загрузка только дельта остатков

*/ //done
$import->importStockProducts("DELTA",10000);

/* Деактивация торговых предложений и некоторых карточек товаров */
//$import->deactivateCatalogItems(10000);
//echo "<pre>" . print_r(time()-$t, 1) . "</pre>";

?>