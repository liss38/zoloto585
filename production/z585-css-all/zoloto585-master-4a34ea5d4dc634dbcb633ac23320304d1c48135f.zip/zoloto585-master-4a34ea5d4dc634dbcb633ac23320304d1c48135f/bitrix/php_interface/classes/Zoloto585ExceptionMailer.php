<?
/** Отправляем сообщения об ошибке на email разработчика */
class Zoloto585ExceptionMailer extends \Bitrix\Main\Diag\ExceptionHandlerLog
{
    public function initialize(array $options) {}

   	public function write($exception, $logType)
    {         	
       	$textFormatted = Bitrix\Main\Diag\ExceptionHandlerFormatter::format($exception);
       	Zoloto585Logger::logError($exception->getMessage());       	
    }
}
?>