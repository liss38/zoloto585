<?
class Zoloto585Config
{
	/**
	 * Ключ для доступа к апи
	 */
	const API_KEY = '52E47764-B722-4E8A-9BA8-DDA5B1500391';

	static function getImportConfig()
	{
		return Array(

			"data" => Array(
				"spravochniki" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/data/spravochniki.csv",
				"offers" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/data/material-kodi.csv"
			),
			"logs" => Array(
				"soap" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/soap.txt",
				"highload" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/highload.txt",
				"offers" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/offers.txt",
				"catalog" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/catalog.txt",
				"catalog_props" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/catalog_props.txt",
				"migration" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/migration.txt",
				"catalog_error_atachment" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/catalog_error_atachment.txt",
				"deactivate" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/deactivate.txt",
				"store" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/store_add_log.txt",
				"emailstores"=>$_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/stores_mails_import_log.txt", //добавить
				"stop_import_store_products"=>$_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/logs/stop_import_store_products.txt",
				"highload_store" => "IMPORTSTORELOG"
			),
			"matching_fields" => Array(
				"catalog" => Array(
					0 => Array("column_5"=>"PR.PROP_155"),
					1 => Array("column_6"=>"PR.PROP_156"),
					2 => Array("column_7"=>"PR.PROP_157"),
					3 => Array("column_8"=>"PR.PROP_158"),
					4 => Array("column_9"=>"PR.PROP_159"),
					5 => Array("column_10"=>"PR.PROP_160"),
					6 => Array("column_12"=>"PR.PROP_162"),
					7 => Array("column_13"=>"PR.PROP_163"),
					8 => Array("column_16"=>"PR.PROP_164"),
					9 => Array("column_17"=>"PR.PROP_165"),
					10 => Array("column_18"=>"PR.PROP_166"),
					11 => Array("column_19"=>"PR.PROP_167"),
					12 => Array("column_20"=>"PR.PROP_168"),
					13 => Array("column_21"=>"PR.PROP_169"),
					14 => Array("column_22"=>"PR.PROP_170"),
					15 => Array("column_23"=>"PR.PROP_171"),
					16 => Array("column_24"=>"PR.PROP_172"),
					17 => Array("column_25"=>"PR.PROP_173"),
					18 => Array("column_26"=>"PR.PROP_174"),
					19 => Array("column_27"=>"PR.PROP_175"),
					20 => Array("column_29"=>"PR.PROP_176"),
					21 => Array("column_30"=>"PR.PROP_177"),
					22 => Array("column_31"=>"PR.PROP_178"),
					23 => Array("column_32"=>"PR.PROP_179"),
					24 => Array("column_33"=>"PR.PROP_180"),
					25 => Array("column_28"=>"PR.PROP_181"),
					26 => Array("column_34"=>"PR.PROP_182"),
					27 => Array("column_35"=>"PR.PROP_183"),
					28 => Array("column_36"=>"PR.PROP_184"),
					29 => Array("column_37"=>"PR.PROP_185"),
					30 => Array("column_38"=>"PR.PROP_186"),
					31 => Array("column_39"=>"PR.PROP_187"),
					32 => Array("column_40"=>"PR.PROP_188"),
					33 => Array("column_41"=>"PR.PROP_189"),
					34 => Array("column_42"=>"PR.PROP_190"),
					35 => Array("column_43"=>"PR.PROP_191"),
					36 => Array("column_44"=>"PR.PROP_192"),
					37 => Array("column_45"=>"PR.PROP_193"),
					38 => Array("column_46"=>"PR.PROP_194"),
					39 => Array("column_47"=>"PR.PROP_195"),
					40 => Array("column_50"=>"PR.PROP_196"),
					41 => Array("column_51"=>"PR.PROP_197"),
					42 => Array("column_52"=>"PR.PROP_161")
				),
				"offers" => Array(
					0 => Array("column_0"=>"IE.XML_ID"),
					1 => Array("column_1"=>"IE.NAME"),
					2 => Array("column_2"=>"PR.PROP_151"),
					3 => Array("column_3"=>"PR.PROP_148"),
					4 => Array("column_14"=>"PR.PROP_150"),
					5 => Array("column_15"=>"PR.PROP_152"),
					6 => Array("column_48"=>"PR.PROP_153"),
					7 => Array("column_49"=>"PR.PROP_154"),
					8 => Array("column_53"=>"PR.PROP_206"),
					9 => Array("column_54"=>"PR.PROP_244")
				),
				"SAP_PROP" => 147,
				"CML2LINK_PROP" => 146,
				"SPECIALSTOCK" => 149
			),
			"IblockCatalog" => 4,
			"IblockOffersCatalogOLD" => 5,
			"percentage_match" => 50,
			"Pvkorg" => "G585",
			"priceType" => Array(
				"Zbir" => 1,
				"Vkp0" => 2,
				"Vka0" => 3,
				"Zmin" => 4,
				"Icena" => 5
			),
			"coeff_price" => 0.8,
			"productGroups" => Array(
				10105 => 282,
				10110 => 282,
				10115 => 282,
				10120 => 282,
				10125 => 282,
				10130 => 282,
				10135 => 282,
				10145 => 282,
				10150 => 282,
				10520 => 283,
				10530 => 283,
				10140=>284,
				101 => 284,
				105 => 284
			),
			"productGroupsUV" => Array(
				4 => 301,
				13 => 300,
				26 => 299,
				21 => 298,
				33 => 297,
				30 => 296,
				27 => 295,
				9 => 294,
				37 => 293,
				35 => 292,
				6 => 289,
				22 => 290,
				28 => 291,
				19 => 288,
				3 => 287,
				15 => 286
			),
			"UV"=>282,
			"soapOffersPrices" => Array(
				"wsdl" => "http://91.240.95.57:8017/sap/bc/srt/wsdl/srvc_001999D94A8F1EE582ED0EFFBD4585E3/wsdl11/allinone/standard/document?sap-client=600",
				"options" => Array(
					'login' => "WEBSERVICE",
					'password' => '123456',
					'location' => "http://91.240.95.57:8017/sap/bc/srt/rfc/sap/zws_get_prices_for_site/600/getpricesondate/getpricesondatebinding",
					'connection_timeout'=> ini_get("default_socket_timeout")
				)
			),
			"soapWarehouses" => Array(
				"wsdl" => "http://91.240.95.57:8017/sap/bc/srt/wsdl/flv_10000A101AD1/bndg_url/sap/bc/srt/rfc/sap/zws_get_active_stores/600/zsite_stores_out/zsite_stores_out?sap-client=600",
				"options" => Array(
					'login' => "WEBSERVICE",
					'password' => '123456',
					'location' => "http://91.240.95.57:8017/sap/bc/srt/rfc/sap/zws_get_active_stores/600/zsite_stores_out/zsite_stores_out",
					'connection_timeout'=> ini_get("default_socket_timeout")
				)
			),
			"SITE_ID" => "s1",
			"arFieldsCatalogProducts" => Array(
				"VAT_ID" => 0,
				"VAT_INCLUDED" => "N",
				"QUANTITY" => 0,
				"QUANTITY_RESERVED" => 0,
				"QUANTITY_TRACE" => "D",
				"PRICE_TYPE" => "S",
				"RECUR_SCHEME_TYPE" => "D",
				"WITHOUT_ORDER" => "N",
				"SELECT_BEST_PRICE" => "Y",
				"CAN_BUY_ZERO" => "D",
				"NEGATIVE_AMOUNT_TRACE" => "D",
				"BARCODE_MULTI" => "N",
				"SUBSCRIBE" => "D",
				"MEASURE" => 5,
				"RECUR_SCHEME_LENGTH" => 0,
				"TYPE" => 1
			),
			"ftpconnectStoresEmail" => Array(
				"login"=>"storelist",
				"password"=>"KyAKHDLr",
				"host"=>"ftp.zoloto585.spb.ru",
				"filepath"=>"storelist.csv "
			),
			"ftpconnectStoresProducts" => Array(
				"login"=>"GoodsRemainsForSite",
				"password"=>"Hn%4867yTG",
				"host"=>"ftp.zoloto585.spb.ru",
				"tmp" => $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/classes/catalog_stores_prices/tmp/"
			)

		);
	}

	static function getFavoriteConfig ()
	{
		return [
			'arCookie' => [
				'durationInDays' => 365,
				'name' => 'fav_id',
			],
		];
	}
}
?>