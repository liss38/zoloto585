<?
class smsCron {

    public $freq=86400;

    public function __construct(){
        CModule::IncludeModule('sale');
        CModule::IncludeModule('catalog');
    }

    function sms11($orderId){
		$oInfo = CSaleOrder::GetByID($orderId);
        $ordProps = CSaleOrderPropsValue::GetList(array(), array('ORDER_ID' => $orderId, "CODE" => "XML_ID"), false, false, array("VALUE"))->fetch();
        $rsStore = CCatalogStore::GetList(array(), array("XML_ID" => $ordProps['VALUE']), false, false, array('*'));
        $store = $rsStore->fetch();
        if(!$store)return;
		
        //Пока что считаем часовой пояс = МСК
        $hour_offset = getUserField("CAT_STORE", $store['ID'], "UF_GTM");
        $hour_offset = 3;

        $dStatus=$oInfo['DATE_STATUS'];

        $time=strtotime($dStatus)-3*3600+$hour_offset*3600;
        $day = date('N',$time);
        /*Не отправляем смс в случае, если заказ создан в пт или сб */
        if(($day==5)||($day==6))return;

        $dayOffset=1;

        /*Расчёт смещения по времени, можно также учитывать часовой пояс и через сколько дне отправлять */
        $timeTo= gmmktime(11, 00, 0, gmdate('m',$time), gmdate('d',$time), gmdate('Y',$time))-$hour_offset*3600*1 + 3600*24*$dayOffset;
		
        //Если разница между текущим временем и временем когда надо отправить смс меньше половины частоты агента - шлем СМС
        if(abs(time()-$timeTo)<=$this->freq/2){
            $db_props = CSaleOrderPropsValue::GetList(array(), array("ORDER_ID" => $orderId, "CODE" => "PHONE"));
            $phoneInfo = $db_props->Fetch();
            $phone = $phoneInfo['VALUE'];
            $text="Сегодня вы станете чуточку счастливее! Не забудьте забрать свой заказ №$orderId.";
           // sendSms("+79111268305", $text);
            sendSms($phone, $text);
        }
    }

    function sendOrderList(){
        $oList= CSaleOrder::GetList(array("ID" => "ASC"), array("STATUS_ID" => "W","DATE_STATUS_FROM"=>date("d.m.Y H:i:s",time()-3600*(96*1))));
        while($order=$oList->fetch()){
            $this->sms11($order['ID']);
        }
    }
}

?>