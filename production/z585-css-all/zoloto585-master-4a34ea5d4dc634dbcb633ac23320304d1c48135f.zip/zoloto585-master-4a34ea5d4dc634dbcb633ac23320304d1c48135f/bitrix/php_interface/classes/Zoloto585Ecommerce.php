<?
/**
 * init.php
 * шаблон catalog.section .default
 * catalog/custom/section.php - Добавил параметр
 * catalog/custom/bitrix/catalog.element/.default/result_modifier.php
 * catalog/custom/bitrix/catalog.element/.default/template.php
 * news\journal\bitrix\news.detail\.default\component_epilog.php
 * свойство заказа GTM_CLIENT_ID
 * saveClientID убедиться что ORDER_PROPS_ID = 23
 */

//TODO::код GTM перенести в самый низ, т.к. настройка модуля перемещает все скрипты вниз либо подключать его из этого класса

use Bitrix\Main\Page\Asset; 

class Zoloto585Ecommerce
{	
	/**
	 * Тип списка товаров - раздел каталога
	 */
	const TYPE_CATALOG_SECTION = 'Каталог';

	/**
	 * Тип списка товаров - товары на странице журнала
	 */
	const TYPE_JOURNAL_ITEM = 'Журнал';

	/**
	 * Тип списка товаров - персональные рекомендации
	 */
	const TYPE_PERSONAL_RECOMMENDATIONS = 'Персональные рекомендации';

	/**
	 * Тип списка товаров - c этим товаром рекомендуем
	 */
	const TYPE_PRODUCT_RECOMMENDATIONS = 'Похожие';

	/**
	 * Тип списка товаров - Вы смотрели
	 */
	const TYPE_CATALOG_VIEWED = 'Вы смотрели';

	/**
	 * Тип списка товаров - акционные
	 */
	const TYPE_ACTION = 'Акция';

	/**
	 * Вывод в консоль служебной информации
	 */
	const DEBUG_MODE_ON = true;

	/**
	 * Механизм отправки включен
	 */
	const ANALYTICS_ON = true;

	/**
	 * ID свойства заказа GTM_CLIENT_ID
	 */
	const ID_PROP_CLIENT_ID = 23;

	/**
	 * Инициализация системы отправки данных в google	 
	 */
	public static function init()
	{
		if (self::ANALYTICS_ON) {			
			
			self::saveClientID();
			
			//self::sendUserID();

			self::registerProductClickHandler();
			self::registerPromoClickHandler();
			self::registerBronClickHandler();
			self::registerBronStep1Handler();
			self::registerBronStep2Handler();
			self::registerOrderCompleteHandler();

			AddEventHandler('sale', 'OnBeforeOrderUpdate', array('Zoloto585Ecommerce', 'cancelOrder'));			

			global $APPLICATION;
			$APPLICATION->ShowViewContent('zoloto585_ecommerce_scripts');
		}
	}
	
	/**
	 * Сохраняет clientID. Запрос на сохранение делается через ajax. Параметры получает из запроса.
	 * @return boolean
	 */
	private static function saveClientID()
	{
		if ($_REQUEST['save_gtm_client_id'] == 'y') {
			$orderID = (int)$_REQUEST['order_id'];
			$clientID = $_REQUEST['client_id'];
			if ($orderID > 0 && !empty($clientID)) {
				\Bitrix\Main\Loader::includeModule('sale');

				$arFields = array(
					'ORDER_ID' => $orderID,
					'ORDER_PROPS_ID' => self::ID_PROP_CLIENT_ID,
					'NAME' => 'Google clientID',
					'CODE' => 'GTM_CLIENT_ID',
					'VALUE' => $clientID
				);

				$propValID = CSaleOrderPropsValue::Add($arFields);
				echo $propValID;
				die;
			}
		}
	}

	/**
	 * Регистрирует js обработчик клика по карточке товара
	 * @return boolean
	 */
	public static function registerProductClickHandler()
	{		
		$debug = self::DEBUG_MODE_ON;
		$jsCode = "<script type='text/javascript'>$(function(){
			$('.catalog-item-ecommerce').click(function(){
				var info = {
					'actionField': {'list': $(this).data('gtm-type')},
					'products': [{
					'name': $(this).data('name'),
					'id': $(this).data('id'),
					'category': $(this).data('cat-path')
					}]
				};
				if ({$debug}) console.log(info);
				dataLayer.push({
					'event': 'productClick',
					'ecommerce': {
						'click': info
					},
				});
			});
		});</script>";

		self::showCode($jsCode);
	}

	/**
	 * Регистрирует js обработчик клика по промо-объекту
	 * @return boolean
	 */
	public static function registerPromoClickHandler()
	{				
		$debug = self::DEBUG_MODE_ON;
		$jsCode = "<script type='text/javascript'>$(function(){
			$('.ecommerce-promo-item').click(function(){
				var info = {
					'id': $(this).data('ecommerce-id'),
					'name': $(this).data('name'),					
					'position': $(this).data('position'),
				};

				if ({$debug}) console.log(info);

				dataLayer.push({
					'event': 'promotionClick',
					'ecommerce': {
						'promoClick': {
							'promotions': [info]
						}
					},
				});
			});
		});</script>";

		self::showCode($jsCode);
	}

	/**
	 * Регистрирует js обработчик клика по кнопке бронирования
	 * @return boolean
	 */
	public static function registerBronClickHandler()
	{		
		$debug = self::DEBUG_MODE_ON;
		$jsProdInfo = self::getJsInfoForProductCard();
		$jsCode = "<script>$(function(){
			$('#pcard-store-button-list').on('click', '.pcard-store__reserve-button', function(){				
				dataLayer.push({
					'event': 'addToCart',
					'ecommerce': {
						'add': {
							'products': [{$jsProdInfo}]
						}
					}
				});				
			});			
		});</script>";

		self::showCode($jsCode);
	}


	/**
	 * Регистрирует обработчик первого шага бронирования - выбор магазина
	 * @return boolean
	 */
	public static function registerBronStep1Handler()
	{		
		$debug = self::DEBUG_MODE_ON;
		$stepCode = self::getJsCodeForBronStep(1);
		$jsCode = "
			<script>$(function(){
				
				$(document).on('click', function (event) {
					if($(event.target).hasClass('pcard-map-shop__button')) {
						if ({$debug}) console.log('step1');
						{$stepCode}						
					}		
				});

			});</script>
		";

		self::showCode($jsCode);
	}

	/**
	 * Регистрирует обработчик второго шага бронирования - смс подтверждения
	 * @return boolean
	 */
	public static function registerBronStep2Handler()
	{
		$stepCode = self::getJsCodeForBronStep(2);
		$debug = self::DEBUG_MODE_ON;
		$jsCode = "
			<script>$(function(){
				
				$(document).on('goldOrderStep2Complete', function (event) {					
					if ({$debug}) console.log('step2');					
					{$stepCode}					
				});

			});</script>
		";

		self::showCode($jsCode);				
	}

	public static function registerOrderCompleteHandler()
	{		
		$debug = self::DEBUG_MODE_ON;
		$productJs = self::getJsInfoForProductCard();
		$jsCode = "
		<script>
			$(document).on('goldOrderComplete', function (event, orderID, shopAddr) {					
				if ({$debug}) console.log('complete');
				var info = {
					'ecommerce': {
						'purchase': {
							'actionField': {
								'id': orderID,
								'revenue': $('.pcard-store-prices').not('.non').data('price'),
								'affiliation': shopAddr,
								'tax': '0',
								'shipping': '0'
							},

							'products': [{$productJs}]
						}
					},
					'event':  'e-commerce'
				};

				dataLayer.push(info);	

				if ({$debug}) console.log(info);

				//сохраним clientID в заказе
				var data = {
					'save_gtm_client_id': 'y',
					'order_id': orderID,
					'client_id': ga.getAll()[0].get('clientId')
				};
				console.log(data);
				$.post(window.location, data, function(data){
					console.log(data);
				});

				return true;
			});

		</script>
		";

		self::showCode($jsCode);
	}

	/**
	 * Регистрирует обработчик третьего шага бронирования - смс подтверждения
	 * @return boolean
	 */
	public static function registerBronStep3Handler()
	{
		$stepCode = self::getJsCodeForBronStep(3);
		$jsCode = "
			<script>$(function(){
				
				$(document).on('goldOrderComplete', function (event) {						
					{$stepCode}					
				});

			});</script>
		";

		self::showCode($jsCode);				
	}

	/**
	 * Получает js код для шага бронирования
	 * @param  Integer $step номер шага
	 * @return string
	 */
	private static function getJsCodeForBronStep($step)
	{
		$debug = self::DEBUG_MODE_ON;
		$productJs = self::getJsInfoForProductCard();
		$jsCode = "			
			var info = {
				'event': 'checkout',
				'ecommerce': {
					'checkout': {
						'actionField': {'step': {$step}},
						'products': [{$productJs}]
					}
				}
			};
			dataLayer.push(info);
			if ({$debug}) console.log(info);
			return true;
		";
		return $jsCode;
	}

	/**
	 * Отправляет ID пользователя
	 */
	public static function sendUserID()
	{
		$debug = self::DEBUG_MODE_ON;			
		$userId = CZoloto585UserIdentity::getCurrentUserId();
		if ($userId > 0) {
			$jsCode = "
				<script>
					var info = {'userID': '{$USER->GetID()}'};
					window.dataLayer = [info];
					if ({$debug}) console.log(info);
				</script>
			";		
			self::showCode($jsCode, true);		
		}
	}

	/**
	 * Выводит код для одного промо-объекта
	 * @return boolean
	 */
	public static function showSingleBannerCode($actionID, $actionName)
	{
		$jsCode = "
			<script>
			dataLayer = [{
			  'ecommerce': {
			    'promoView': {
			      'promotions': [
			       {
					  'id': '{$actionID}',
					  'name': '{$actionName}',					  
					  'position': 'Слот 1'
			       }]
			    }
			  }
			}];
			</script>
		";
		
		self::showCode($jsCode, true);
	}

	/**
	 * Выводит код для промо-объектов
	 * @param  string $actionID ID акции
	 * @param  array $arResult данные о промо-объектах полученные на выходе компонента news.list
	 * @return boolean
	 */
	public static function showActionCode($actionID, $arResult)
	{		
		$debug = self::DEBUG_MODE_ON;
		$jsCode = "
			<script>
				dataLayer = [{
					'ecommerce': {
					'promoView': {
						'promotions': [";
					
		$ind = 1;
		$cntItems = count($arResult['ITEMS']);
		foreach ($arResult['ITEMS'] as $arItem) {
			if ($arItem["DETAIL_PICTURE"] || $arItem['PROPERTIES']['youtube']['VALUE']) {
				$jsCode .= "{
				'id': '{$actionID}_{$arItem['ID']}',
				'name': '{$arItem['NAME']}',			
				'position': 'Слот {$ind}'
				}";

				if ($i < $cntItems) {
					$jsCode .= ", ";
				}

				$ind++;
			}
		}

		$jsCode .= "	]					
					}
				}
				}];
				if ({$debug}) console.log(dataLayer);
			</script>
		";

		self::showCode($jsCode, true);
	}
	

	/**
	 * Получает js код содержащий информацию о продукте в карточке товара
	 * @return string
	 */
	private function getJsInfoForProductCard()
	{
		$debug = self::DEBUG_MODE_ON;
		$trace = debug_backtrace();		
		$jsCode = "
			function() {
				var parent = $('#pcard-store-button-list');
				
				var variant = '';								
				if ($('.pcard-store-fitting-select__menu_default').length > 0) {
					var option = $('.pcard-store-fitting-select__menu_default').find('option:selected');

					if (option.length > 0) {
						variant = option.html().trim();
					}					
				}
				
				var prodInfo = {
					'name': parent.data('name'),
					'id': parent.data('id'),
					'price': $('.pcard-store-prices').not('.non').data('price'),
					'category': parent.data('cat-path'),
					'variant': variant,								
					'quantity': 1
				};
				
				if ({$debug}) {
					console.log('{$trace[1]['function']}');
					console.log(prodInfo);
				}

				return prodInfo;
			}()
		";

		return $jsCode;
	}

	/**
	 * Отображения кода отслеживания для списка товаров (раздел каталога, результаты поиска)
	 * @param  array $arResult Массив товаров полученный на выходе компонента catalog.section
	 * @return boolean
	 */
	public static function showProductListCode($arResult, $type, $add_event = false)
	{
		$debug = self::DEBUG_MODE_ON;

		$jsCode = '<script>
			window.dataLayer = window.dataLayer || [];
			var data = {"ecommerce": {"impressions":[]}};
		';

     	$index = 1;
		foreach ($arResult['ITEMS'] as $arItem) {
			$jsCode .= "data.ecommerce.impressions.push({'id': {$arItem['ID']}, 'list': '{$type}', 'position': {$index}});";
			$index++;
		}

		$jsCode .= "window.dataLayer.push(data);";
		$jsCode .= "if ({$debug}) console.log(dataLayer);";

		if($add_event)
			$jsCode .= "dataLayer.push( {'event': '$add_event'});";

		$jsCode .= '</script>';

		self::showCode($jsCode, true);
	}

	/**
	 * Отображения кода отслеживания для карточки товара
	 * @param  array $arResult Данные товары на выходе компонента catalog.element
	 * @return boolean
	 */
	public static function showProductDetailCode($arResult)
	{
		$catPath = self::getCategoryPath($arResult['IBLOCK_ID'], $arResult['IBLOCK_SECTION_ID']);

		$jsCode = "<script>";
		$jsCode .= "dataLayer = [{";
		$jsCode .= "'ecommerce': {";
		$jsCode .= "'detail': {";
		$jsCode .= "'products': [{";

     	$jsCode .= "'name': '{$arResult['NAME']}',";
     	$jsCode .= "'id': {$arResult['ID']},";
     	$jsCode .= "'category': '{$catPath}'";     	

		$jsCode .= "}]";
		$jsCode .= "}";
		$jsCode .= "}";
		$jsCode .= "}];";
		$jsCode .= "</script>";		

		self::showCode($jsCode, true);
	}

	

	/**
	 * Отмена заказа
	 * @param  integer $orderID  
	 * @param  string $arFields
	 * @return boolean           
	 */
	public static function cancelOrder($orderID, $arFields)
	{		
		global $USER;

		//Если заказ отменен - статус C
		if ($arFields['STATUS_ID'] == 'C') {
			$arExistOrder = CSaleOrder::GetByID($orderID);
			if ($arExistOrder['STATUS_ID'] != $arFields['STATUS_ID']) {				
				if (empty($arFields['COMMENTS'])) {
					$reason = urlencode('Не указана');
				} else {
					$reason = urlencode($arFields['COMMENTS']);
				}

				$arClientID = CSaleOrderPropsValue::GetList(
		            array(),
		            array(
		                    'ORDER_ID' => $orderID,
		                    'ORDER_PROPS_ID' => self::ID_PROP_CLIENT_ID
		                )
		        )->Fetch();

				if ($arClientID['VALUE']) {
					$url = "http://www.google-analytics.com/collect?v=1&tid=UA-24696049-1&cid={$arClientID['VALUE']}&t=event&ec=ecommerce&ea=refund&el={$reason}&ni=1&ti={$orderID}&pa=refund";
					file_get_contents($url);
				}
			}
		}
	}

	/**
	 * Выводит js код на сайт
	 * @param  string $jsCode js-код
	 * @param  boolean $skipMoving Не перемещать код в конец документа
	 * @return boolean
	 */
	private static function showCode($jsCode, $skipMoving = false)
	{		
		if (self::ANALYTICS_ON) {				
			if ($skipMoving) {
				$jsCode = str_replace('<script>', '<script data-skip-moving="true">', $jsCode);
			}
			echo $jsCode;						
		}
	}

	/**
	 * Получает путь от корня до категории
	 * @param  integer $iblockID ID инфоблока
	 * @param  integer $sectionID ID раздела
	 * @return array
	 */
	public static function getCategoryPath($iblockID, $sectionID)
	{
		if ((int)$iblockID == 0) {
			throw new InvalidArgumentException('ИД инфоблока должен быть числом');
		}
		if ((int)$sectionID == 0 && !(empty($sectionID))) {
			throw new InvalidArgumentException('ИД раздела должен быть числом, пришло '.$sectionID);
		}

		\Bitrix\Main\Loader::includeModule('iblock');

		$arPath = [];

		$dbPath = CIBlockSection::GetNavChain($iblockID, $sectionID, array('ID', 'NAME'));
		while ($arSection = $dbPath->Fetch()) {
			$arPath[] = $arSection['NAME'];
		}

		return implode(' / ', $arPath); 
	}
}
?>