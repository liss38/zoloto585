<?
class MyIblockChange {

    function OnIblockChangeHandler(&$arFields) {

        //Псевдостраницы
        if($arFields ["IBLOCK_ID"] == 30)
        {

            $res_psevdo_my = CIBlockElement::GetList(array(), array("IBLOCK_ID" => 30, "ACTIVE" => "Y"));
            while ($ob_psevdo_my = $res_psevdo_my->GetNextElement())
            {
                $arFields_psevdo_psevdo = $ob_psevdo_my->GetFields();
                $arFields_psevdo_psevdo["PROP"] = $ob_psevdo_my->GetProperties();
                $arFields_psevdo_psevdo["PROP"]["PREVIEW_TEXT"]["VALUE"] = $arFields_psevdo_psevdo["PREVIEW_TEXT"];
                $arFields_psevdo_psevdo["PROP"]["PREVIEW_PICTURE"]["VALUE"] = CFile::GetPath($arFields_psevdo_psevdo["PREVIEW_PICTURE"]);
                $psevdo_page_arr[] = $arFields_psevdo_psevdo;
            }
            if($psevdo_page_arr){
                $io = CBXVirtualIo::GetInstance();
                $fp = $io->RelativeToAbsolutePath("/include/psevdo_page.php");
                $f = $io->GetFile($fp);
                $enter = "\n";
                $tab = "\t";
                $fileData = "<?".$enter;
                $fileData .= 'return Array('.$enter;
                foreach($psevdo_page_arr as $psevdo_page)
                {
                    $allProperties = $enter.$tab.$tab."Array(";
                    foreach($psevdo_page["PROP"] as $key => $val){
                        $allProperties.=$enter.$tab.$tab.$tab."'".$key."' => '".(is_array($val["VALUE"])?htmlspecialchars($val["VALUE"]["TEXT"]):$val["VALUE"])."',";
                    }
                    $allProperties=substr($allProperties,0,strlen($allProperties)-1).$enter.$tab.$tab.")";
                    $fileData .= $tab."'".$psevdo_page["PROP"]["URL_PSEVDO"]["VALUE"]."' => ".$allProperties.",".$enter;
                }
                $fileData .= ');?>';
                $f->PutContents($fileData);
            }

        }
    }

}
?>