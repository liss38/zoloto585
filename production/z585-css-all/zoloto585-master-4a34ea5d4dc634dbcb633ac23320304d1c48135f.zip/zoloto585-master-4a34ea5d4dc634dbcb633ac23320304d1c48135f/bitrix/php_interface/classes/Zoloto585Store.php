<?
/**
 * Работа со складами (магазинами)
 */
class Zoloto585Store
{
	/**	
	 * Получает список всех городов, в которых есть магазины
	 * @return array
	 */
	public static function getCities()
	{
		$cities = [];

		$obCache = \Bitrix\Main\Data\Cache::createInstance();		
		if ($obCache->initCache(86400 * 7, 'cities', '/zoloto585/store/')) {
			$vars = $obCache->GetVars();
			$cities = $vars['cities'];
		} else if( $obCache->startDataCache()) {
			\Bitrix\Main\Loader::includeModule('catalog');			

			$dbStores = CCatalogStore::GetList(array('UF_CITY' => 'ASC'), array('ACTIVE' => 'Y'), false, false, array('UF_*'));
			while ($arStore = $dbStores->Fetch()) {
				$cityName = $arStore['UF_CITY'];
				$cities[$cityName] = $cityName;
			}

			$cities = array_values($cities);
			$obCache->endDataCache(array('cities' => $cities));
		}

		return $cities;
	}

	/**	
	 * Получает список всех магазинов
	 * @return array
	 */
	public static function getStores($arFilter = [])
	{
		$stores = [];

		if (!is_array($arFilter)) {
			$arFilter = [];
		}

		$cacheId = 'stores';
		foreach ($arFilter as $k=>$v) {
			$cacheId .= "|{$k}={$v}";
		}

		$obCache = \Bitrix\Main\Data\Cache::createInstance();		
		if ($obCache->initCache(86400 * 7, $cacheId, '/zoloto585/store/')) {
			$vars = $obCache->GetVars();
			$stores = $vars['stores'];
		} else if( $obCache->startDataCache()) {			
			\Bitrix\Main\Loader::includeModule('catalog');			

			$arFilter['ACTIVE'] = 'Y';
			$dbStores = CCatalogStore::GetList(array('UF_CITY' => 'ASC'), $arFilter, false, false, array('UF_*'));
			while ($arStore = $dbStores->Fetch()) {
				$arStore["DETAIL_URL"] = self::getUrlStore($arStore['UF_CITY'],$arStore['ADDRESS']);
				$stores[] = $arStore;
			}
						
			$obCache->endDataCache(array('stores' => $stores));
		}

		return $stores;
	}

	/**
	 * генерирует символный код для ссылки магазина
	 * @param $string
	 * @return string
	 */
	static function str2url($string)
	{
		$converter = array(
			'а' => 'a',   'б' => 'b',   'в' => 'v',
			'г' => 'g',   'д' => 'd',   'е' => 'e',
			'ё' => 'e',   'ж' => 'zh',  'з' => 'z',
			'и' => 'i',   'й' => 'y',   'к' => 'k',
			'л' => 'l',   'м' => 'm',   'н' => 'n',
			'о' => 'o',   'п' => 'p',   'р' => 'r',
			'с' => 's',   'т' => 't',   'у' => 'u',
			'ф' => 'f',   'х' => 'h',   'ц' => 'c',
			'ч' => 'ch',  'ш' => 'sh',  'щ' => 'sch',
			'ь' => '\'',  'ы' => 'y',   'ъ' => '\'',
			'э' => 'e',   'ю' => 'yu',  'я' => 'ya',

			'А' => 'A',   'Б' => 'B',   'В' => 'V',
			'Г' => 'G',   'Д' => 'D',   'Е' => 'E',
			'Ё' => 'E',   'Ж' => 'Zh',  'З' => 'Z',
			'И' => 'I',   'Й' => 'Y',   'К' => 'K',
			'Л' => 'L',   'М' => 'M',   'Н' => 'N',
			'О' => 'O',   'П' => 'P',   'Р' => 'R',
			'С' => 'S',   'Т' => 'T',   'У' => 'U',
			'Ф' => 'F',   'Х' => 'H',   'Ц' => 'C',
			'Ч' => 'Ch',  'Ш' => 'Sh',  'Щ' => 'Sch',
			'Ь' => '\'',  'Ы' => 'Y',   'Ъ' => '\'',
			'Э' => 'E',   'Ю' => 'Yu',  'Я' => 'Ya',
		);

		$str = strtr($string, $converter);

		// в нижний регистр
		$str = strtolower($str);
		// заменям все ненужное нам на "-"
		$str = preg_replace('~[^-a-z0-9_]+~u', '-', $str);
		// удаляем начальные и конечные '-'
		$str = trim($str, "-");
		return $str;
	}

	/**
	 * Возвращает ссылку на магазин по его названию и адресу
	 * @param $city
	 * @param $address
	 * @return string
	 */
	static function getUrlStore($city,$address)
	{
		return "/about/address/".self::str2url($city)."/".self::str2url($address)."/";
	}
}
?>