<?php
use Bitrix\Main,
    Bitrix\Sale\Order,
    Bitrix\Sale\OrderTable,
    Bitrix\Main\Loader;

class Zoloto585Kafka{

    const KAFKA_URL_SERVER = 'stage.zoloto585.ru';

    public function __construct() {
        Loader::IncludeModule('catalog');
        Loader::IncludeModule('sale');
    }

    /**
     * @param $arData - массив для отправки
     */
    public function sendKafkaData($arData,$topicname)
    {
        $conf = new \RdKafka\Conf();
       /* $conf->setDrMsgCb(function($rk, $message) {
            echo $message->err;
        });*/


        $writek = new \RdKafka\Producer($conf);
        $writek->addBrokers(self::KAFKA_URL_SERVER.':9092');


        $topicConf = new \RdKafka\TopicConf();
        $topicConf->set("message.timeout.ms",100);

        $topic = $writek->newTopic($topicname, $topicConf);
        $topic->produce(RD_KAFKA_PARTITION_UA, 0,json_encode($arData));

        $writek->poll(100);
        while($writek->getOutQLen()) $writek->poll(100);

    }

    public function GetKafkaData($topicname)
    {
        $conf = new \RdKafka\Conf();
        $getk = new \RdKafka\Consumer($conf);
        $getk->addBrokers(self::KAFKA_URL_SERVER);

        $topic = $getk->newTopic($topicname);
        $topic->consumeStart(0, RD_KAFKA_OFFSET_BEGINNING);

        $data=array();

        while (true) {
            // The first argument is the partition (again).
            // The second argument is the timeout.
            $msg = $topic->consume(0,100);
            if ($msg->err){
                echo $msg->errstr(), "\n";
                break;
            } else {
               if(!empty($msg->payload)) $data[$msg->offset] = $msg->payload;
            }
        }
        var_dump($data);
    }

}


?>