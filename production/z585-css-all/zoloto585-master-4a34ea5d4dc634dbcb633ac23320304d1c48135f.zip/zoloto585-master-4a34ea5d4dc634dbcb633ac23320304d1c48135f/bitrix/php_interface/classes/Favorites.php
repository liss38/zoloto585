<?
/**
 * contains everything you need for favorites manipulating
 * made by iteamo.net (Тертых Алексей)
 */
class favorites {
// -----------------------------------------------------------------------------
public static $arSettings;
//
private $arItemIds = null;
private static $objInstance = null;
private $currentUserId = 0;
private $favID;  
// -----------------------------------------------------------------------------
public static function init() {
  if(is_null(self::$objInstance)) {
    self::$objInstance = new self();
  }
  return self::$objInstance;
}
// -----------------------------------------------------------------------------
private function __construct() {
  global $USER;
  $this->objUser = $USER;

  self::$arSettings = Zoloto585Config::getFavoriteConfig();
  //
  if ($this->objUser->IsAuthorized) {
    $this->currentUserId = $this->objUser->GetID();
  }
  //
  $this->favID = $_COOKIE[self::$arSettings['arCookie']['name']];
  $this->arItemIds = $this->get();
}
private function __clone() {}
// -----------------------------------------------------------------------------
/**
 *
 */
public function add($itemId = 0) {
  $this->arItemIds[$itemId] = $itemId;
  $this->save();
}
/**
 *
 */
public function delete($itemId = 0) {
  unset($this->arItemIds[$itemId]);
  $this->save();
}
/**
 *
 */
public function get() {
  if (is_null($this->arItemIds)) {
    $this->arItemIds = self::getFromRedis();
    if ($this->currentUserId) {
      $this->arItemIds = self::merge($this->arItemIds, self::getFromUserField($this->currentUserId));
    }
  }
  //
  return $this->arItemIds;
}
/**
 *
 */
public function has($itemId = 0) {
  $result = in_array($itemId, $this->arItemIds);
  //
  return $result;
}
// -----------------------------------------------------------------------------
private function save() {
  $this->saveInRedis($this->arItemIds);
  if ($this->currentUserId) {
    $this->saveInUserField($this->currentUserId, $this->arItemIds);
  }
}
// -----------------------------------------------------------------------------
/**
 *
 */
private function saveInRedis($arItemIds = []) {
  if(empty($this->favID))
    $this->favID = md5(rand(0,1000000000000000));

  $durationInSeconds = 3600*24 * self::$arSettings['arCookie']['durationInDays'];

  if ($redis = Zoloto585Redis::connect())
    $redis->setEx('fav:'.$this->favID, $durationInSeconds, serialize(array_keys($arItemIds)));

  $result = setcookie(self::$arSettings['arCookie']['name'], $this->favID, time() + $durationInSeconds, '/');

  return $result;
}
/**
 *
 */
private static function saveInUserField($userId = 0, $arItemIds = []) {
  $arFields = Array(
  	'UF_FAVS' => serialize($arItemIds),
  );
  $result = $this->objUser->Update($userId, $arFields);
  //
  return $result;
}
/**
 *
 */
private function getFromRedis() {
  $arItemIds = [];

  if (!empty($this->favID) && $redis = Zoloto585Redis::connect()) {
      if($strItems = $redis->get('fav:'.$this->favID))
      {
        $arItems = unserialize($strItems);
        foreach($arItems as $product)
          $arItemIds[$product] = $product;
      }
  }

  return $arItemIds;
}
/**
 *
 */
private static function getFromUserField($userId = 0) {
  $arItemIds = [];
  //
  $rsUser = $this->objUser->GetByID($userId);
  if($arUser = $rsUser->Fetch()) {
    if (!empty($arUser['UF_FAVS'])) {
      $arItemIds = unserialize($arUser['UF_FAVS']);
    }
  }
  //
  return $arItemIds;
}
// -----------------------------------------------------------------------------
/**
 *
 */
private static function mergeUnique($arItems1 = [], $arItems2 = []) {
  $arResult = [];
  //
  $arResult = array_merge($arItems1, $arItems2);
  $arResult = array_unique($arResult);
  //
  return $arResult;
}
// -----------------------------------------------------------------------------
}