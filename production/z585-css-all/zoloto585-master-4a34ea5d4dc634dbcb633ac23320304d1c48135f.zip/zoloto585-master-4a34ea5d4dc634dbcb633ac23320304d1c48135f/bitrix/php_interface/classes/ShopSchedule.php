<?
class ShopSchedule
{
	    /**
	     * Форматирует время работы магазина для вывода
	     * Для яндекса - по дням пн 10:00-20:00, вт 10:00-20:00, ср 10:00-20:00..... либо ежедневно 10:00-20:00
	     * @param  string  $schedule     время в исходном формате (из сапа)
	     * @param  boolean $yandexFormat вернуть время для яндекса
	     * @return string                отформатированное время
	     */
	    public static function schedulePrepare($schedule, $yandexFormat = false)
	    {
		    $result="";
		    if ($schedule != "")
			    {
				    $arWorkDays = array();
				    $arDays = explode(";", $schedule);
				    foreach ($arDays as $day)
					    {
						    $arDay = explode(":", $day);
						    $arWorkDays[$arDay[0]] = self::scheduleGetTimePrepare($arDay[1]);
					    }					   
				    $arWorkDaysUnique=array_unique($arWorkDays);

				    if(count($arWorkDaysUnique)==1) {
					    $result=current($arWorkDaysUnique);					    
					    if ($yandexFormat) {
					    	$result = 'ежедневно ' . $result;
					    }
				    }
				    elseif(count($arWorkDaysUnique)>1)
				    {
					    if ($yandexFormat) {					    	
					    	foreach ($arWorkDays as $day => $time) {
					    		$result .= strtolower($day) . ' ' . $time . ', ';
					    	}
					    	$result = substr($result, 0, -2);					    	
					    } else {
					   		$c=0;
						    foreach($arWorkDaysUnique as $current=>$time)
							    {
								    $unique="";
								    foreach($arWorkDays as $day=>$res)
									    {
										    if($day!=$current && $time==$res)
											    {
												    $unique=$current."-".$day;
												    unset($arWorkDaysUnique[$current]);
												    unset($arWorkDaysUnique[$day]);
											    }
									    }
								    if($unique!="")
									    {
										    if ($c != 0)
											    {
												    $result .= ",<br /> ";
											    }
										    $c++;
										    $result .= $unique . ": " . $time;
									    }
							    }
						    if(!empty($arWorkDaysUnique))
							    {
								    foreach($arWorkDaysUnique as $current=>$time)
									    {
										    if($result!="")
											    $result .= ",<br /> ";
										    $result .= $current . ": " . $time;

									    }
							    }
					    }
					}
			    }
		    return $result;
	    }


    public static function scheduleGetTimePrepare($time)
	    {
		    $result = "";
		    $arTimes = explode(",", $time);
		    if ($arTimes[0] != "")
			    {
				    $result.=self::scheduleTimePrepare($arTimes[0]);
			    }
		    if ($arTimes[1] != "")
			    {
				    $result.=self::scheduleTimePrepare($arTimes[1],true);
			    }
		    return $result;
	    }

    public static function scheduleHmPrepare($time)
	    {
		    return substr($time, 0, 2) . ":" . substr($time, 2, 4);
	    }

    public static function scheduleTimePrepare($time, $last = false)
	    {
		    $result = "";
		    if ($time != "")
			    {
				    $arTime = explode("-", $time);

				    if ($arTime[0] != "" && $arTime[1] != "")
					    {
						    $result = self::scheduleHmPrepare($arTime[0]);
						    $result .= "-" . self::scheduleHmPrepare($arTime[1]);
						    if (!$last)
							    {
								    $result .= " ";
							    }

					    }
				    elseif ($arTime[0] != "")
					    {
						    $result = self::scheduleHmPrepare($arTime[0]);
						    if (!$last)
							    {
								    $result .= "-";
							    }
					    }
				    elseif ($arTime[1] != "")
					    {
						    $result = self::scheduleHmPrepare($arTime[1]);
					    }
			    }
		    return $result;
	    }
}
?>