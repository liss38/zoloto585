<?
function getSizePropsOffers($type)
{
    $sizePropOffers="";
    if (in_array($type,array(26,15,30)))
    {
        $sizePropOffers = "SIZE_RING_PEND";
    }
    if (in_array($type,array(9,3)))
    {
        $sizePropOffers = "SIZE_CB";
    }
    return $sizePropOffers;
}
/*
 * Сортировка торговых предложений по цене -чтобы при открытии карточки товара было выбрано торговое предложение с минимальной стоимостью
 * **/
function cmp_by_price($offer1, $offer2)
{
    global $min,$sizePropOffers,$minId;

    $a=floatval($offer1['DISPLAY_PROPERTIES'][$sizePropOffers]['DISPLAY_VALUE']);
    $b=floatval($offer2['DISPLAY_PROPERTIES'][$sizePropOffers]['DISPLAY_VALUE']);

    $price=$offer1["PRICES"]["Internet_price"]["DISCOUNT_VALUE"];

    if($price<$min)
    {
        $min=$price;
        $minId=$offer1["ID"];
    }

    if ($a == $b) {
        return 0;
    }
    return ($a < $b) ? -1 : 1;
}
?>