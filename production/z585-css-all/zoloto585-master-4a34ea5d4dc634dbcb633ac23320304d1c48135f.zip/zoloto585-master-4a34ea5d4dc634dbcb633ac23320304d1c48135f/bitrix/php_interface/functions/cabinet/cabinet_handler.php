<?php
/**
 * ЛИЧНЫЙ КАБИНЕТ
 * подмена телефона и карты Логином пользователя.
 * для почты не делаем так как логин совпадает с почтой.
 * используется совместно с шаблоном /bitrix/templates/zoloto/components/bitrix/system.auth.form/cabinet
 */
function OnBeforeUserLoginHandler(&$arFields)
{
	//если идет авторизация по телефону
	if ($_POST["TYPE_AUTH"] == "PHONE")
	{
		//ищем логин по телефону
		$rsUsers = CUser::GetList(
			$by = 'ID',
			$order = 'ASC',
			Array("PERSONAL_PHONE" => clear_phone($arFields["LOGIN"])),
			Array("FIELDS"=>Array("LOGIN"))
		);

		//если их нашелся всего 1
		if ($rsUsers->SelectedRowsCount()==1)
		{
			$arUser = $rsUsers->fetch();
			//то подменяем логин
			$arFields["LOGIN"] = $arUser["LOGIN"];
		}
		else
		{
			//а если их ноль и больше одного, то выдаем ошибку
			global $APPLICATION;
			$APPLICATION->throwException("#PHONE_ERROR#");
			return false;
		}
	}

	//заглушка для будущей подмены по карте
	if ($_POST["TYPE_AUTH"] == "CARD")
	{
		//ищем логин по номеру БК
		$rsUsers = CUser::GetList(
			$by = 'ID',
			$order = 'ASC',
			Array("UF_CARD" => $arFields["LOGIN"]),
			Array("FIELDS"=>Array("LOGIN"))
		);

		//если их нашелся всего 1
		if ($rsUsers->SelectedRowsCount()==1)
		{
			$arUser = $rsUsers->fetch();

			//то подменяем логин
			$arFields["LOGIN"] = $arUser["LOGIN"];
		}
		else
		{
			//а если их ноль и больше одного, то выдаем ошибку
			global $APPLICATION;
			$APPLICATION->throwException("#CARD_ERROR#");
			return false;
		}
	}
}

/**
 * ЛИЧНЫЙ КАБИНЕТ
 * проверка старого пароля
 */

function checkOldPassword(&$arFields)
{
	if ($_REQUEST["type"]=="pswd")
	{
		if (!empty($arFields["PASSWORD"]))
		{
			$hash = $_REQUEST["PSW_HASH"];
			$salt = substr($hash,0,8);

			if ($hash!==$salt.md5($salt.$_REQUEST["CUR_PASS"]))
			{
				global $APPLICATION;
				$APPLICATION->throwException("#PASSWORD_CUR_ERROR#");
				return false;
			}
		}
		else
		{
			global $APPLICATION;
			$APPLICATION->throwException("#PASSWORD_CUR_ERROR#");
			return false;
		}

	}
}