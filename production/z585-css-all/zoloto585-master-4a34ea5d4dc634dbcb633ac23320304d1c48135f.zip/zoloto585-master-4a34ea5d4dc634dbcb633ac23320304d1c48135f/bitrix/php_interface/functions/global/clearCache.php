<?

function clearCacheOfferById($offerId)
{
    $obCache = new CPHPCache();
    $arCachClear=array(
        "getOrderQuantByOfferId",
        "getStoresOffer",
        "getSroreCity",
        "getCityInfo",
    );
    foreach($arCachClear as $name)
    {
        $obCache->Clean(md5($offerId . $name), "/sale/order/");
    }

}

function OnStoreProductUpdate($ID,$arFields=false)
{
    if($arFields["PRODUCT_ID"]>0)
        clearCacheOfferById($arFields["PRODUCT_ID"]);
}
function OnBeforeStoreProductAdd($arFields)
{
    if($arFields["PRODUCT_ID"]>0)
        clearCacheOfferById($arFields["PRODUCT_ID"]);
}

function OnCatalogStoreUpdate($ID,$arFields)
{
	global $importStoreWarehouses;
	if(!$importStoreWarehouses)
		{
			CModule::IncludeModule("catalog");
			$rsStore = CCatalogStoreProduct::GetList(array(), array('STORE_ID' => $ID));
			while ($arStore = $rsStore->GetNext())
				{
					if ($arStore['AMOUNT'] > 0)
						{
							clearCacheOfferById($arStore["PRODUCT_ID"]);
						}
				}
		}
}
?>