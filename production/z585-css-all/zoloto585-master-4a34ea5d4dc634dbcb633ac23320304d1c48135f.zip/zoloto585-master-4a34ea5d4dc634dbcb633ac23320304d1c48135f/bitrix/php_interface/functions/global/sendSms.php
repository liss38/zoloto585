<?
function clear_phone($phone) {
	if (!$phone)
		return "";
	$ph = strtr($phone, array("+7" => 8, "-" => "", " " => "", "(" => "", ")" => ""));
	if (strlen($ph) > 10) {
		$ph = substr($ph, 1);
	}

	if (strlen($ph) > 10) {
		return "";
	}

	return $ph;
}

function sendSms($number, $text) {

	$number='7'.clear_phone($number);

	$params = array(
		'serviceId' => '50974',
		'pass' => 'AE2oJjjp',
		'source' => '585GOLD',
		'clientId' => $number,
		'message' => $text
	);

	$url = 'http://smsinfo.zagruzka.com/aggrweb?'.http_build_query($params);

	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)");

	$result = curl_exec($ch);
	$status = curl_getinfo($ch);

	$f=fopen("/home/bitrix/www/smslog/smslog.txt","a+");
	fwrite($f,date("Y.m.d H:i:s")." $number $text \r\n");
	fclose($f);
	curl_close($ch);
	return true;
}
?>