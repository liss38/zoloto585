<?php

//переписать функции дял интернет цены, если не нужны- удалить
//все функции прокомментировать!!!
function getProdSize($props) {
	$val = $props['PROPERTY_SIZE_RING_PEND_VALUE'];
    if(empty($val)||($val=="NULL"))$val = $props['PROPERTY_SIZE_CB_VALUE'];
    if($val=="NULL")return "";
	$val=strtr($val,array("N_"=>"","T"=>"."));
    return $val;
    $val = $props['PROPERTY_RING_SIZE_VALUE'];
    //return $val;
	if (!empty($val))
        return "$val";
    $val = $props['PROPERTY_LENGTH_CHAIN_VALUE'];
    if (!empty($val))
        return "$val";
    $val = $props['PROPERTY_LENGTH_BRACELET_VALUE'];
    if (!empty($val))
        return "$val";
    return "";
}


//Получить бирочную цену
function getBasePrice($prodId){
	$db_res = CPrice::GetList(array(), array('CATALOG_GROUP_ID'=>1,"PRODUCT_ID" => $prodId));
	while ($ar_res = $db_res->Fetch()){
		return floor($ar_res['PRICE']);
	}
	return "";
}

//Получить розничную или акционную цену
function getProductPrice($prodId){
	$db_res = CPrice::GetList(array(), array('@CATALOG_GROUP_ID'=>array(2,3),"PRODUCT_ID" => $prodId));
	$price_arr=array();
	while ($ar_res = $db_res->Fetch()){
		$price_arr[$ar_res['CATALOG_GROUP_ID']]=$ar_res['PRICE'];
	}
	$price = floor($price_arr[3])>0 ? $price_arr[3] :$price_arr[2];
	return floor($price);
}

//Получить цену по скидочной карте
function getCardPrice($prodId){
	$db_res = CPrice::GetList(array(), array('@CATALOG_GROUP_ID'=>array(2,3),"PRODUCT_ID" => $prodId));
	$price_arr=array();
	while ($ar_res = $db_res->Fetch()){
		$price_arr[$ar_res['CATALOG_GROUP_ID']]=$ar_res['PRICE'];
	}
    if(($price_arr[3])>0)return $price_arr[3];
	return floor($price_arr[2]*0.8);
}


//????
function getIdByCode($code, $iblock_id, $type) {
    if (CModule::IncludeModule("iblock")) {
        if ($type == 'IBLOCK_ELEMENT') {
            $arFilter = array("IBLOCK_ID" => $iblock_id, "CODE" => $code);
            $res = CIBlockElement::GetList(array(), $arFilter, false, array("nPageSize" => 1), array('ID'));
            $element = $res->Fetch();
            if ($res->SelectedRowsCount() != 1)
                return 'false';
            else
                return $element['ID'];
        }
        else if ($type == 'IBLOCK_SECTION') {
            $res = CIBlockSection::GetList(array(), array('IBLOCK_ID' => $iblock_id, 'CODE' => $code));
            $section = $res->Fetch();
            if ($res->SelectedRowsCount() != 1)
                return 'false';
            else
                return $section['ID'];
        }
        else {
            echo 'false';
            return;
        }
    }
}

//Создать картинку указанного размера
function resizeImages($ID,$width,$height, $type = BX_RESIZE_IMAGE_EXACT){
    $images = CFile::ResizeImageGet($ID,array("width" => $width, "height" => $height),$type,true);
    return $images;
}

//считывание значения пользовательского поля, применяю для получения города и часового пояса у склада
function getUserField($entity_id, $value_id, $uf_id) {
    $arUF = $GLOBALS["USER_FIELD_MANAGER"]->GetUserFields($entity_id, $value_id);
    $field = $arUF[$uf_id];
    $ret=$field['VALUE'];
    if ($ret == "")
        $ret= $field['SETTINGS']["DEFAULT_VALUE"];
    return $ret;
}

//проверка есть ли у объекта пользовательское поле
function hasUserField($entity_id, $value_id, $uf_id) {
    $arUF = $GLOBALS["USER_FIELD_MANAGER"]->GetUserFields($entity_id, $value_id);
    $field = $arUF[$uf_id]["VALUE"];
    return $field != "";
}
?>