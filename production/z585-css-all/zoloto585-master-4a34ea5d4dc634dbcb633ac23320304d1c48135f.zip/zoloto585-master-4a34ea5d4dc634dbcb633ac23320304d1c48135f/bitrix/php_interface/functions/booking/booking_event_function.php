<?
use Bitrix\Sale\Order,
	Bitrix\Main\Loader,
	Bitrix\Sale,
	Bitrix\Main\Mail\Event;

function saleStatusChange($id,$changeStatus=true)
{
	Loader::IncludeModule('catalog');
	Loader::IncludeModule('sale');

	// загружаем объект заказ
	$order = Order::load($id);

	// пропуск обработчика, если это необходимо
	if((($order->getField('STATUS_ID') != 'N')) && (!$changeStatus))
		return;

	//узнаем тип доставки, и если курьером(id=1) значит заказ в 1 клик.
	$deliveryID = $order-> getShipmentCollection()[0]->getDeliveryId();
	$bBuyOneClick = ($deliveryID==1) ? true : false;

	// получаем свойства заказа и сохраняем в массив CODE => VALUE
	$arOrderProps = Array();
	$propertyCollection =  $order->getPropertyCollection();
	foreach ($propertyCollection as $property)
		$arOrderProps[$property -> getField('CODE')] = $property->getValue();


	// проверяем есть ли телефон в заказе, если нет, то прерываем и делаем запись в log
	$phone = clear_phone($arOrderProps['PHONE']);
	if (!$phone) {
		Zoloto585Logger::logError("Попытка изменить статус заказа, в котором отсутсвует телефон id=".$order->getID());
		return;
	}

	if (!$bBuyOneClick)
	{
		// получаем склад по XML_ID
		$arStore = CCatalogStore::GetList(
			array(),
			array("ACTIVE" => "Y", "XML_ID" => $arOrderProps['XML_ID']),
			false,
			false,
			array('ID','EMAIL','ADDRESS', "UF_GTM")
		)->fetch();

		// если магазин не найден, то прерываем обработчик и делаем запись в лог.
		if (!$arStore) {
			Zoloto585Logger::logError("Попытка изменить статус заказа, в котором не найдем магазин id=".$order->getID());
			return;
		}
	}


	// получаем корзину
	$basket = $order->getBasket();

	// получаем первый товар в корзине
	$basketItem = $basket->getBasketItems()[0];

	// если в корзине нет товаров, то прерываем обработчик и делаем запись в лог.
	if (!$basketItem) {
		Zoloto585Logger::logError("Попытка изменить статус заказа, в котором нет ни одного товара id=".$order->getID());
		return;
	}

	// получаем ID торгового предложения
	$skuID = $basketItem->getProductId();

	// получаем информацию о родительском товаре
	$arProduct = CIBlockElement::GetList(
		array(),
		array(
			"IBLOCK_ID" => 4,
			array("ID" => CIBlockElement::SubQuery("PROPERTY_CML2_LINK", array("IBLOCK_ID" => 29, "ID" => $skuID))),
		),
		false,
		false,
		array("ID","NAME","PREVIEW_PICTURE","DETAIL_PICTURE")
	)->fetch();

	/**  Принят, ожидается оплата */
	if ($order->getField('STATUS_ID') == 'N')
	{
		// если заказ не создан с этим статусом, а переведен в него, то пропускаем обработчик
		if ($order->getField('DATE_UPDATE')->getTimestamp() != $order->getField('DATE_INSERT')->getTimestamp()) {
			return;
		}

		// получаем нужную информацию о торговом предложении
		$arSKU = CIBlockElement::GetList(
			Array(),
			Array("ID" => $skuID),
			false,
			false,
			array("ID", "PROPERTY_SIZE_RING_PEND",'PROPERTY_SHT_CODE', "PROPERTY_SIZE_CB", "PROPERTY_SUPPLIER_CODE",'PROPERTY_WEIGHT_WITH_INSERTS', "CATALOG_GROUP_1", "XML_ID")
		)->fetch();

		// получаем путь к картинке из родительского товар
		$imNum = !empty($arProduct['DETAIL_PICTURE']) ? $arProduct['DETAIL_PICTURE'] : $arProduct['PREVIEW_PICTURE'];
		$imSrc = "";
		if (!empty($imNum)) {
			$imInfo = CFile::ResizeImageGet($imNum, array('width' => 300, 'height' => 200), BX_RESIZE_IMAGE_PROPORTIONAL, true);
			$imSrc = "https://" . $_SERVER['SERVER_NAME'] .$imInfo['src'];
		}

		// задаем часовой пояс для расчетов
		$hour_offset = ($arStore["UF_GTM"] == "") ? 3 : $arStore["UF_GTM"];

		$hour_to = gmdate("H", $order->getField('DATE_INSERT')->getTimestamp() + 3600 * $hour_offset + 3600 / 2);
		$tto = $order->getField('DATE_INSERT')->getTimestamp() + 3600 * $hour_offset + 3600 / 2;

		//начало работы магазина
		$hourFromStore = 11;
		//конец работы магазина
		$hourToStore = 18;

		if (($hour_to >= $hourToStore) || ($hour_to < $hourFromStore)) {
			if ($hour_to >= $hourToStore) {
				$tto = gmmktime($hourToStore, 0, 0, gmdate('m'), gmdate('d'), gmdate('Y')) + ((24 - $hourToStore) + $hourFromStore) * 3600 + 1800;
			} else {
				$tto = gmmktime($hourFromStore, 30, 0, gmdate('m'), gmdate('d'), gmdate('Y'));
			}
		}

		$timeToStr = gmdate("Y-m-d H:i:s", $tto);
		if ($arStore["UF_GTM"] == "")
			$timeToStr.=" <i>(по московскому времени)</i>";

		// массив для отправки сообщения
		$send_array = array(
			"SALE_EMAIL" => "sale@zoloto585.ru",
			"SHOP_EMAIL" => $arStore['EMAIL'],
			"ORDER_ID" => $order->getID(),
			"SHOP" => $arStore['ADDRESS'],
			"NAME" => $arProduct['NAME'],
			"PRICE" => $order->getPrice()." руб.",
			"BASE_PRICE" => round($arSKU["CATALOG_PRICE_1"]) . " руб.",
			"TIME" => gmdate("Y-m-d H:i:s", $order->getField('DATE_INSERT')->getTimestamp() + $hour_offset * 3600),
			"TIME_TO" => $timeToStr,
			"SAP" => $arSKU['XML_ID'],
			"IMG_SRC" => $imSrc,
			'ORDER_QUESTION' => "https://".$_SERVER["SERVER_NAME"]."/ordershops/",
			'ORDER_NO1' => "https://".$_SERVER["SERVER_NAME"]."/api/order/statusupdate/" . $order->getID() . '?key=qwerty&status=C&comment=not available',
			'ORDER_NO2' => "https://".$_SERVER["SERVER_NAME"]."/api/order/statusupdate/" . $order->getID() . '?key=qwerty&status=C&comment=broken',
			'ORDER_YES' => "https://".$_SERVER["SERVER_NAME"]."/api/order/statusupdate/" . $order->getID() . '?key=qwerty&status=W',
			'HOST' => $_SERVER['SERVER_NAME'],
			'SIZE' => getProdSize($arSKU),
			"SKU" => $arSKU['PROPERTY_SUPPLIER_CODE_VALUE'],
			"SHT_CODE" => $arSKU['PROPERTY_SHT_CODE_VALUE'],
			"WEIGHT" => $arSKU['PROPERTY_WEIGHT_WITH_INSERTS_VALUE'],
			"PHONE" => "7".$phone,
			"USER_NAME" => $arOrderProps["FIO"],
			'ITEMLINK' => "javascript:void(0);",//"http://$_SERVER[SERVER_NAME]" . $elem['DETAIL_PAGE_URL']
		);

		
		if ($bBuyOneClick)
		{
			Event::Send(array(
				"EVENT_NAME" => "BUY_ONE_CLICK",
				"LID" => "s1",
				"C_FIELDS" => $send_array
			));

			$text = "Заказ №".$order->getID()." создан. В ближайшее время мы с Вами свяжемся для подтверждения заказа. 88005551585";
			sendSms($phone, $text);
		}
		else
		{

			Event::Send(array(
				"EVENT_NAME" => "STORE_NEW_ORDER",
				"LID" => "s1",
				"C_FIELDS" => $send_array
			));

			$text = "Заказ №".$order->getID()." создан. Пожалуйста, ожидайте подтверждения заказа. Оно придет по SMS в течении суток";
			sendSms($phone, $text);

			usleep(100000); //задержка 100 милисекунд, чтобы смс были друг за другом. КАЖИСЬ НЕ ПОМОГАЕТ

			$text = "Вам подарок! Скидка 300 руб. на любую следующую покупку от 3000 руб.! Код купона ".$order->getID();
			sendSms($phone, $text); // отправка купона по смс
		}

		clearCacheOfferById($skuID);
		return;
	}

	/**  Заказ есть в наличии */
	if ($order->getField('STATUS_ID') == 'W')
	{
		if ($bBuyOneClick)
			$text = "Ваш заказ №".$order->getID()." передан в службу доставки. Ожидайте, курьер свяжется с вами в ближайшее время.";
		else
			$text = "Ваше украшение «".$arProduct["NAME"]."» ожидает Вас в магазине «".$arStore["ADDRESS"]."» до " . gmdate("d.m.Y", time() + 3600 * 24 * 2 + 3600 * $arStore["UF_GTM"]) .
				". Заказ №".$order->getID().", стоимость ".$order->getPrice()." р., тел. 88005551585";

		sendSms($phone, $text);
		clearCacheOfferById($skuID);
		return;
	}

	/** Отмена или Отказ - Проверка купона для воставновления */
	if ($order->getField('STATUS_ID') == 'C' || $order->getField('STATUS_ID') == 'R')
	{
		$arCouponUpdateInfo = ["ACTIVE"=>"Y","DATE_APPLY"=>null];

		//проверяем есть ли купон сотрудника у заказа
		$arCoupon=\Bitrix\Sale\Internals\DiscountCouponTable::getList(Array(
			"select" => Array("ID"),
			"filter" => Array("DESCRIPTION"=>"ORDER".$order->getID())
		))->Fetch();

		//если есть, готовим массив для обновления купона сотрудника
		if(!empty($arCoupon["ID"]))
		{
			$discountData["COUPON_LIST"][0]["COUPON_ID"]=$arCoupon["ID"];
			$discountData["COUPON_LIST"][0]["DATA"]["TYPE"]=2;
			$discountData["COUPON_LIST"][0]["APPLY"]="Y";
			$discountData["COUPON_LIST"][0]["DATA"]["MODULE"]="sale";
			$arCouponUpdateInfo["DESCRIPTION"] = null;
		}
		//если нет, проверяем стандартные купоны
		else
		{
			$discountData = $order->getDiscount()->getApplyResult();
		}

		//акивируем купон
		if (count($discountData["COUPON_LIST"])>0)
		{
			foreach ($discountData["COUPON_LIST"] as $arCoupon)
			{
				if(in_array($arCoupon["DATA"]["TYPE"],Array(1,2)) && $arCoupon["APPLY"]=="Y")
				{
					if ($arCoupon["DATA"]["MODULE"]=="sale")
						Sale\Internals\DiscountCouponTable::update($arCoupon["COUPON_ID"], $arCouponUpdateInfo);
					else
						CCatalogDiscountCoupon::Update ($arCoupon["COUPON_ID"],["ACTIVE"=>"Y"]);
				}
			}
		}

	}

	/** Отмена */
	if ($order->getField('STATUS_ID') == 'C')
	{
		if(!$bBuyOneClick)
		{
			$text = "К сожалению, украшения ".$arProduct["NAME"]." нет в наличии в магазине «".$arStore["ADDRESS"]."». Попробуйте выбрать другой магазин на сайте";
			sendSms($phone, $text);
		}
		clearCacheOfferById($skuID);
		return;
	}

	/** Выполнен */
	if ($order->getField('STATUS_ID') == 'F')
	{
		$arCatalogDiscountsID = Array(11, 12, 13); //допустимые скидки на товар
		$arSaleDiscountsID = Array(1, 2, 3, 4, 5, 6); //допустимые скидки на корзину

		//получаем примененные скидки и купоны
		$discountData = $order->getDiscount()->getApplyResult();

		$bSendSms = false;

		//проходим все купоны заказа
		foreach($discountData["COUPON_LIST"] as $arCoupon)
		{
			//если купон был применен, то проверяем относится ли DISCOUNT_ID к id скидок учавствующих в акциях
			if ($arCoupon["APPLY"]=="Y")
			{
				if (in_array($arCoupon["DATA"]["DISCOUNT_ID"],$arCatalogDiscountsID) && $arCoupon["DATA"]["MODULE_ID"]=="catalog")
					$bSendSms = true;

				if (in_array($arCoupon["DATA"]["DISCOUNT_ID"],$arSaleDiscountsID) && $arCoupon["DATA"]["MODULE_ID"]=="sale")
					$bSendSms = true;
			}
		}

		//если условия акции были выполены, то отправляем код и сохраняем его в заказ
		if($bSendSms)
		{
			//генерируем промокод
			$promoCode = $order->getID()."ss".randString(19-strlen($order->getID()),Array("1234567890abcde"));

			$propertyCollection = $order->getPropertyCollection();

			//добавим в заказ ПРОМО КОД
			foreach ($propertyCollection as $property)
			{
				if($property->getField('CODE') == "PROMO_CODE")
				{
					$property->setValue($promoCode);
					break;
				}
			}

			$order->save();

			if(!$bBuyOneClick)
			{
				$text = "Спасибо за покупку! Зарегистрируйте чек на z585.su/kupon и выиграйте миллион! Ваш номер для регистрации " . $promoCode;
				sendSms($phone, $text);
			}
		}

		return;
	}

}

//вспомогательная функция вывода логов
function pr($var) {
	static $int=0;
	echo '<pre><b style="background: red;padding: 1px 5px;">'.$int.'</b> ';
	print_r($var);
	echo '</pre>';
	$int++;
}
/////-------------------------------------------------/////////
?>