<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();?><?
CHTTP::SetStatus("503 Service Unavailable");
?>
<html>
<head>
<title>503 Service Temporarily Unavailable</title>
</head>
<body>
<h1>Service Temporarily Unavailable</h1>
You have made too many requests per second.
</body></html>
<?die();?>