<?
require_once($_SERVER['DOCUMENT_ROOT']. "/bitrix/modules/main/include/prolog_before.php");
require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/templates/zoloto/Mobile_Detect.php');

$IBLOCK_ID = 12;
$APPLICATION->IncludeFile("iblock/slider.php", Array("IBLOCK_ID" => $IBLOCK_ID));
?>