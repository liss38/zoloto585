<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
CModule::IncludeModule("iblock");

global $USER;
$arGroups = $USER->GetUserGroupArray();

$sizeMax = (!empty($_GET["size"]))?$_GET["size"]:300;

if (in_array(1,$arGroups) || in_array(10,$arGroups))
{
	getProductWithBigImages($sizeMax);
}
else
{
	echo "отказано в доступе";
}

function getProductWithBigImages($sizeMax)
{

	function checkFileSize($id,$sizeMax)
	{

		if (!empty($id))
		{
			$arFileInfo =  CFile::GetFileArray($id);
			$size = $arFileInfo["FILE_SIZE"]/1024;

			if ($size>$sizeMax)
				return false;
		}

		return true;
	}

	//собираем все картинки
	$arResult = Array();
	$arSelect = Array("ID", "PREVIEW_PICTURE", "DETAIL_PICTURE","PROPERTY_fotogallery");
	$arFilter = Array("IBLOCK_ID"=>4);
	$res = CIBlockElement::GetList(Array("ID"=>"ASC"), $arFilter, false, false, $arSelect);
	while($arFields = $res->fetch())
	{
		$arResult[$arFields["ID"]]["PREVIEW_PICTURE"] = $arFields["PREVIEW_PICTURE"];
		$arResult[$arFields["ID"]]["DETAIL_PICTURE"] = $arFields["DETAIL_PICTURE"];
		$arResult[$arFields["ID"]]["GALLERY"][] = $arFields["PROPERTY_FOTOGALLERY_VALUE"];
	}


	//проверяем на размер
	$arLog = Array();
	foreach ($arResult as $id => $product)
	{

		if (!checkFileSize($product["PREVIEW_PICTURE"],$sizeMax))
			$arLog[$id]["PREVIEW_PICTURE"] = true;

		if (!checkFileSize($product["DETAIL_PICTURE"],$sizeMax))
			$arLog[$id]["DETAIL_PICTURE"] = true;



		if (is_array($product["GALLERY"]))
		{
			foreach ($product["GALLERY"] as $key=>$photoID)
			{
				if (!checkFileSize($photoID,$sizeMax))
					$arLog[$id]["GALLERY"] = true;

			}
		}
	}

	//формируем текст для вывода на экран и отправку на почту
	$count = count($arLog);
	$text = "<h3>Товары с картинками больше ".$sizeMax." кбайт (всего {$count})</h3>";

	foreach ($arLog as $id => $arPictures)
	{
		$text .= "<a href='http://zoloto585.ru/bitrix/admin/iblock_element_edit.php?IBLOCK_ID=4&type=catalog&ID={$id}'>{$id}</a>";

		if ($arPictures["PREVIEW_PICTURE"]) $text .= " -анонс ";
		if ($arPictures["DETAIL_PICTURE"]) $text .= " - детальная";
		if ($arPictures["GALLERY"]) $text .= " - фотогалерея";

		$text .= "</br>";
	}


	CEvent::Send
	(
		"EMPTY",
		"s1",
		Array(
			"THEME" => "Товары с картинками больше ".$sizeMax." кбайт",
			"TEXT" => $text
		),
		"N",
		80
	);

	echo $text;
}
